﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        lblTitulo = New Label()
        cbFecha = New ComboBox()
        tabla = New DataGridView()
        lblExcoger = New Label()
        Label1 = New Label()
        txtCiudad = New TextBox()
        PictureBox1 = New PictureBox()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        txtMaximos = New TextBox()
        txtMinimos = New TextBox()
        txtMedia = New TextBox()
        CType(tabla, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblTitulo
        ' 
        lblTitulo.AutoSize = True
        lblTitulo.BackColor = Color.Transparent
        lblTitulo.Font = New Font("MS Reference Sans Serif", 22.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblTitulo.Location = New Point(312, 35)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(455, 46)
        lblTitulo.TabIndex = 0
        lblTitulo.Text = "Previsión Meteorológica"
        ' 
        ' cbFecha
        ' 
        cbFecha.FormattingEnabled = True
        cbFecha.Location = New Point(436, 116)
        cbFecha.Name = "cbFecha"
        cbFecha.Size = New Size(151, 28)
        cbFecha.TabIndex = 1
        ' 
        ' tabla
        ' 
        tabla.AllowUserToAddRows = False
        tabla.AllowUserToDeleteRows = False
        tabla.AllowUserToResizeColumns = False
        tabla.AllowUserToResizeRows = False
        tabla.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        tabla.Location = New Point(139, 171)
        tabla.Name = "tabla"
        tabla.RowHeadersWidth = 51
        tabla.Size = New Size(889, 204)
        tabla.TabIndex = 2
        ' 
        ' lblExcoger
        ' 
        lblExcoger.AutoSize = True
        lblExcoger.BackColor = Color.Transparent
        lblExcoger.Font = New Font("MS Reference Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblExcoger.Location = New Point(270, 118)
        lblExcoger.Name = "lblExcoger"
        lblExcoger.Size = New Size(130, 26)
        lblExcoger.TabIndex = 3
        lblExcoger.Text = "Escoger Dia"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("MS Reference Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(139, 441)
        Label1.Name = "Label1"
        Label1.Size = New Size(282, 26)
        Label1.TabIndex = 4
        Label1.Text = "Buscar Por Nombre Ciudad"
        ' 
        ' txtCiudad
        ' 
        txtCiudad.Location = New Point(436, 443)
        txtCiudad.Name = "txtCiudad"
        txtCiudad.Size = New Size(173, 27)
        txtCiudad.TabIndex = 5
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(630, 426)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(95, 61)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 6
        PictureBox1.TabStop = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("MS Reference Sans Serif", 10.8F)
        Label2.Location = New Point(791, 406)
        Label2.Name = "Label2"
        Label2.Size = New Size(105, 23)
        Label2.TabIndex = 7
        Label2.Text = "T. Maxima"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("MS Reference Sans Serif", 10.8F)
        Label3.Location = New Point(794, 450)
        Label3.Name = "Label3"
        Label3.Size = New Size(99, 23)
        Label3.TabIndex = 8
        Label3.Text = "T. Mínima"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("MS Reference Sans Serif", 10.8F)
        Label4.Location = New Point(791, 495)
        Label4.Name = "Label4"
        Label4.Size = New Size(123, 23)
        Label4.TabIndex = 9
        Label4.Text = "T. Media Dia"
        ' 
        ' txtMaximos
        ' 
        txtMaximos.Location = New Point(926, 406)
        txtMaximos.Name = "txtMaximos"
        txtMaximos.Size = New Size(123, 27)
        txtMaximos.TabIndex = 10
        ' 
        ' txtMinimos
        ' 
        txtMinimos.Location = New Point(926, 450)
        txtMinimos.Name = "txtMinimos"
        txtMinimos.Size = New Size(121, 27)
        txtMinimos.TabIndex = 11
        ' 
        ' txtMedia
        ' 
        txtMedia.Location = New Point(926, 495)
        txtMedia.Name = "txtMedia"
        txtMedia.Size = New Size(123, 27)
        txtMedia.TabIndex = 12
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        ClientSize = New Size(1101, 635)
        Controls.Add(txtMedia)
        Controls.Add(txtMinimos)
        Controls.Add(txtMaximos)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(PictureBox1)
        Controls.Add(txtCiudad)
        Controls.Add(Label1)
        Controls.Add(lblExcoger)
        Controls.Add(tabla)
        Controls.Add(cbFecha)
        Controls.Add(lblTitulo)
        Name = "Form1"
        Text = "Form1"
        CType(tabla, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblTitulo As Label
    Friend WithEvents cbFecha As ComboBox
    Friend WithEvents tabla As DataGridView
    Friend WithEvents lblExcoger As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtCiudad As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtMaximos As TextBox
    Friend WithEvents txtMinimos As TextBox
    Friend WithEvents txtMedia As TextBox

End Class
