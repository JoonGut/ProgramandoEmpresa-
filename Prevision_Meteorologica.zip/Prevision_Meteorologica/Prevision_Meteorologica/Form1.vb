﻿Imports System.IO
Imports System.Net
Imports System.Net.Http
Imports System.Web
Imports System.Xml
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports Formatting = Newtonsoft.Json.Formatting
Imports System.Threading.Tasks
Imports Prevision_Meteorologica.Form1

Public Class Form1
    Private listaDatosTiempo As List(Of datosTiempo)

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
        Dim probar As New Probar()
        cargarTabla()
        formatoTabla()
        Me.BackgroundImageLayout = ImageLayout.Stretch
    End Sub

    'aqui no usamos api y descargamos directamente el xml de internet
    Public Class Probar
        Public Sub New()
            Try
                Dim url As String = "https://opendata.euskadi.eus/contenidos/prevision_tiempo/met_forecast/opendata/met_forecast.xml"
                Dim rutaXML As String = "PrevisionMeteorologicaOriginal.xml"
                Dim rutaJson As String = "PrevisionMeteorologica.json"

                DescargarXML(url, rutaXML)
                ConvertirXMLenJSON(rutaXML, rutaJson)
            Catch ex As FileNotFoundException
                MsgBox("Archivo NO ENCONTRADO: " & ex.Message())
            Catch ex As Exception
                MsgBox("ERROR: " & ex.Message())
            End Try
        End Sub

        Private Sub DescargarXML(url As String, ruta As String)
            Try
                Using client As New WebClient()
                    client.DownloadFile(url, ruta)
                End Using
            Catch ex As Exception
                MsgBox("ERROR: " & ex.Message())
            End Try
        End Sub

        Private Sub ConvertirXMLenJSON(rutaXML As String, rutaJson As String)
            Dim listaDatos As New List(Of datosTiempo)

            If Not File.Exists(rutaXML) Then
                MsgBox("Archivo NO ENCONTRADO")
                Return
            End If

            Try
                Dim doc As New XmlDocument()
                doc.Load(rutaXML)
                Dim dias As XmlNodeList = doc.GetElementsByTagName("forecast")

                'para cada dia
                For Each dia As XmlNode In dias
                    Dim fecha As String = dia.Attributes("forecastDate")?.Value
                    Dim viento As String = sacarviento(dia.SelectSingleNode("description")?.InnerText)

                    Dim ciudades As XmlNodeList = dia.SelectNodes("cityForecastDataList/cityForecastData")

                    'para cada ciudad
                    For Each ciudad As XmlNode In ciudades
                        Dim nombreCiudad As String = If(ciudad.Attributes("cityName")?.InnerText, "No disponible")
                        Dim maximas As String = If(ciudad.SelectSingleNode("tempMax")?.InnerText, "No disponible")
                        Dim minimos As String = If(ciudad.SelectSingleNode("tempMin")?.InnerText, "No disponible")
                        Dim descripcionAdicional As String = If(ciudad.SelectSingleNode("symbol/descriptions/es")?.InnerText, "No disponible")
                        Dim estadoTiempo As String = tipoTiempo(descripcionAdicional)

                        Dim datos = New datosTiempo With {
                            .fecha = fecha,
                            .nombreCiudad = nombreCiudad,
                            .maximas = maximas,
                            .minimos = minimos,
                            .estadoTiempo = estadoTiempo,
                            .descripcion = descripcionAdicional,
                            .viento = viento
                        }
                        listaDatos.Add(datos)
                    Next
                Next

                'serializar el json, linea OBLIGATORIO
                Dim jsonOutput As String = JsonConvert.SerializeObject(listaDatos, Formatting.Indented)
                File.WriteAllText(rutaJson, jsonOutput)

            Catch ex As Exception
                MsgBox("ERROR: " & ex.Message)
            End Try
        End Sub

        Private Function sacarviento(texto As String) As String
            If String.IsNullOrEmpty(texto) Then Return "No disponible"

            Dim textoSeparado() As String = texto.ToLower().Split(".")
            Dim textoNormal() As String = texto.Split(".")
            For i = 0 To textoSeparado.Count - 1
                If textoSeparado(i).Contains("viento") Then
                    Return textoNormal(i)
                End If
            Next
            Return texto
        End Function

        Private Function tipoTiempo(descripcion As String) As String
            If String.IsNullOrEmpty(descripcion) Then
                Return "NO HAY DATOS"
            End If

            Dim v As String = descripcion.Trim().ToLower()

            If v.Contains("soleado") Or v.Contains("despejado") Then
                Return "SOLEADO"
            ElseIf v.Contains("nublado") Or v.Contains("nuboso") Then
                Return "NUBLADO"
            ElseIf v.Contains("lluvia") Or v.Contains("chubascos") Or v.Contains("precipitación") Then
                Return "LLUVIOSO"
            ElseIf v.Contains("nieve") Or v.Contains("nevada") Then
                Return "NIEVE"
            Else
                Return "NO HAY DATOS"
            End If
        End Function
    End Class

    Private Sub cargarTabla()
        Dim rutaJson As String = "PrevisionMeteorologica.json"

        If File.Exists(rutaJson) Then
            Dim jsonText As String = File.ReadAllText(rutaJson)
            listaDatosTiempo = JsonConvert.DeserializeObject(Of List(Of datosTiempo))(jsonText)

            cbFecha.Items.Clear()

            Dim fecha As New List(Of String)()

            For Each dato As datosTiempo In listaDatosTiempo
                If Not fecha.Contains(dato.fecha) Then
                    fecha.Add(dato.fecha)
                End If
            Next

            For Each v In fecha
                cbFecha.Items.Add(v)
            Next

            If cbFecha.Items.Count > 0 Then
                cbFecha.SelectedIndex = 0
            End If
        Else
        End If
    End Sub

    Private Sub cbfecha_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbFecha.SelectedIndexChanged
        If cbFecha.SelectedItem Is Nothing Then Exit Sub

        Dim fechaSeleccionada As String = cbFecha.SelectedItem.ToString()
        Dim datosFiltrados As New List(Of datosTiempo)
        For Each dato As datosTiempo In listaDatosTiempo
            If dato.fecha = fechaSeleccionada Then
                datosFiltrados.Add(dato)
            End If
        Next

        If datosFiltrados.Count > 0 Then
            tabla.DataSource = Nothing
            tabla.Rows.Clear()
            tabla.DataSource = datosFiltrados
        End If

        formatoTabla()
    End Sub

    Private Sub formatoTabla()
        'solo introducaa columnas si no existen, sino salen duplicadas
        If Not tabla.Columns.Contains("fecha") Then
            tabla.Columns.Add("fecha", "Fecha")
        End If
        If Not tabla.Columns.Contains("nombreCiudad") Then
            tabla.Columns.Add("nombreCiudad", "Ciudad")
        End If
        If Not tabla.Columns.Contains("maximas") Then
            tabla.Columns.Add("maximas", "Maxima")
        End If
        If Not tabla.Columns.Contains("minimos") Then
            tabla.Columns.Add("minimos", "Minima")
        End If
        If Not tabla.Columns.Contains("estadoTiempo") Then
            tabla.Columns.Add("estadoTiempo", "Estado Tiempo")
        End If
        If Not tabla.Columns.Contains("descripcion") Then
            tabla.Columns.Add("descripcion", "Descripcion")
        End If
        If Not tabla.Columns.Contains("viento") Then
            tabla.Columns.Add("viento", "Viento")
        End If

        tabla.Columns(0).Width = tabla.Width * 0.15
        tabla.Columns(1).Width = tabla.Width * 0.18
        tabla.Columns(2).Width = tabla.Width * 0.11
        tabla.Columns(3).Width = tabla.Width * 0.1
        tabla.Columns(4).Width = tabla.Width * 0.18
        tabla.Columns(5).Width = tabla.Width * 0.22

        If tabla.Columns.Contains("viento") Then
            tabla.Columns("viento").Visible = False
        End If
    End Sub

    Private Async Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Dim city As String = txtCiudad.Text

        If Not String.IsNullOrEmpty(city) Then
            Dim weatherFetcher As New otro()
            Await weatherFetcher.ExecuteAsync(city)
        Else
            MsgBox("Por favor, ingrese una ciudad.")
        End If
    End Sub

    Public Class cargarXML
        Public Sub leerXML()
            Dim rutaXML As String = "TiempoXML.xml"

            If Not File.Exists(rutaXML) Then
                MsgBox("Archivo no encontrado")
                Return
            End If

            Try
                Dim doc As New XmlDocument()
                doc.Load(rutaXML)

                ' Obtener las temperaturas máxima y mínima como cadena de texto
                Dim tempMaxStr As String = doc.SelectSingleNode("//daily/temperature_2m_max").InnerText
                Dim tempMinStr As String = doc.SelectSingleNode("//daily/temperature_2m_min").InnerText

                ' Reemplazar coma por punto en caso de que sea necesario
                tempMaxStr = tempMaxStr.Replace(",", ".")
                tempMinStr = tempMinStr.Replace(",", ".")

                Dim temperaturaMaxima As Double = Convert.ToDouble(tempMaxStr) / 10
                Dim temperaturaMinima As Double = Convert.ToDouble(tempMinStr) / 10
                Dim temperaturaMedia As Double = mediaTemperatura(doc) / 10

                ' Mostrar los valores con un solo decimal
                Form1.txtMaximos.Text = temperaturaMaxima.ToString("F1") & "°C"
                Form1.txtMinimos.Text = temperaturaMinima.ToString("F1") & "°C"
                Form1.txtMedia.Text = temperaturaMedia.ToString("F1") & "°C"

            Catch ex As Exception
                MsgBox("Error al procesar el archivo: " & ex.Message)
            End Try
        End Sub


        'calculamos la media de todas las temperaturas del dia
        Private Function mediaTemperatura(doc As XmlDocument) As Double
            Dim temperaturas As XmlNodeList = doc.SelectNodes("//hourly/temperature_2m")
            Dim sumaTemperaturas As Double = 0
            Dim numHoras As Integer = temperaturas.Count

            For Each v As XmlNode In temperaturas
                sumaTemperaturas += Convert.ToDouble(v.InnerText)
            Next
            Return sumaTemperaturas / numHoras
        End Function
    End Class


End Class

'lo utilizamos para poder deserializar el Json
Public Class datosTiempo
    Public Property fecha As String
    Public Property nombreCiudad As String
    Public Property maximas As String
    Public Property minimos As String
    Public Property estadoTiempo As String
    Public Property descripcion As String
    Public Property viento As String
End Class

'usando la api
Public Class otro
    Public Async Function GetCoordinatesAsync(city As String) As Task(Of (Double, Double))
        Dim baseUrl As String = "https://api.opencagedata.com/geocode/v1/json"
        Dim apiKey As String = "3f63f62436a04d549dbc0a4b88efc0e9"
        Dim requestUrl As String = $"{baseUrl}?q={HttpUtility.UrlEncode(city)}&key={apiKey}"

        Using client As New HttpClient()
            Try
                Dim response As HttpResponseMessage = Await client.GetAsync(requestUrl)
                response.EnsureSuccessStatusCode()

                Dim responseContent As String = Await response.Content.ReadAsStringAsync()
                Dim geoData As JObject = JObject.Parse(responseContent)

                If geoData("total_results").ToString() = "0" Then
                    MsgBox($"Ciudad no encontrada: {city}")
                    Return (0, 0)
                End If

                Dim lat As Double = geoData("results")(0)("geometry")("lat")
                Dim lng As Double = geoData("results")(0)("geometry")("lng")
                Return (lat, lng)
            Catch ex As Exception
                MsgBox($"Error al obtener coordenadas: {ex.Message}")
                Return (0, 0)
            End Try
        End Using
    End Function

    Private Function ConvertJsonToXml(jsonString As String) As String
        Dim xmlDoc As New XmlDocument()
        xmlDoc.LoadXml(JsonConvert.DeserializeXmlNode(jsonString, "Root").OuterXml)
        Return xmlDoc.OuterXml
    End Function

    Public Async Function GetWeatherAsync(latitude As Double, longitude As Double) As Task
        If latitude = 0 OrElse longitude = 0 Then
            MsgBox("Coordenadas inválidas, no se puede obtener el clima.")
            Return
        End If

        Dim latitudeStr As String = latitude.ToString("0.0000000").Replace(",", ".")
        Dim longitudeStr As String = longitude.ToString("0.0000000").Replace(",", ".")

        Dim weatherUrl As String = $"https://api.open-meteo.com/v1/forecast?latitude={latitudeStr}&longitude={longitudeStr}&current=temperature_2m,apparent_temperature&hourly=temperature_2m,rain,snowfall&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=GMT&forecast_days=1"

        Using client As New HttpClient()
            Try
                Dim response As HttpResponseMessage = Await client.GetAsync(weatherUrl)
                response.EnsureSuccessStatusCode()

                Dim jsonResponse As String = Await response.Content.ReadAsStringAsync()
                Dim xmlData As String = ConvertJsonToXml(jsonResponse)

                Dim filePath As String = "TiempoXML.xml"
                Await File.WriteAllTextAsync(filePath, xmlData)

                Dim xmlLoader As New cargarXML()
                xmlLoader.leerXML()

                MsgBox("Datos meteorológicos guardados con éxito.")
            Catch ex As Exception
                MsgBox($"Error al obtener datos meteorológicos: {ex.Message}")
            End Try
        End Using
    End Function

    Public Async Function ExecuteAsync(city As String) As Task
        Dim coordinates As (Double, Double) = Await GetCoordinatesAsync(city)

        If coordinates.Item1 <> 0 AndAlso coordinates.Item2 <> 0 Then
            Await GetWeatherAsync(coordinates.Item1, coordinates.Item2)
        Else
            MsgBox("No se pueden obtener los datos meteorológicos sin coordenadas válidas.")
        End If
    End Function
End Class
