﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdministradorMenu
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AdministradorMenu))
        btModificarEmpleados = New Button()
        btModificarProductos = New Button()
        btVolver = New Button()
        btAniadir = New Button()
        btModificar = New Button()
        btOcultar = New Button()
        lblTitulo = New Label()
        btModificarFamilias = New Button()
        btInforme = New Button()
        PictureBox1 = New PictureBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' btModificarEmpleados
        ' 
        btModificarEmpleados.BackColor = SystemColors.ActiveCaption
        btModificarEmpleados.Cursor = Cursors.Hand
        btModificarEmpleados.Font = New Font("MS Reference Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btModificarEmpleados.Location = New Point(53, 160)
        btModificarEmpleados.Name = "btModificarEmpleados"
        btModificarEmpleados.Size = New Size(256, 145)
        btModificarEmpleados.TabIndex = 0
        btModificarEmpleados.Text = "Modificar Empleados"
        btModificarEmpleados.UseVisualStyleBackColor = False
        ' 
        ' btModificarProductos
        ' 
        btModificarProductos.BackColor = Color.CadetBlue
        btModificarProductos.Cursor = Cursors.Hand
        btModificarProductos.Font = New Font("MS Reference Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btModificarProductos.Location = New Point(348, 160)
        btModificarProductos.Name = "btModificarProductos"
        btModificarProductos.Size = New Size(256, 145)
        btModificarProductos.TabIndex = 1
        btModificarProductos.Text = "Modificar Productos"
        btModificarProductos.UseVisualStyleBackColor = False
        ' 
        ' btVolver
        ' 
        btVolver.BackColor = Color.IndianRed
        btVolver.Cursor = Cursors.Hand
        btVolver.Font = New Font("MS Reference Sans Serif", 11F)
        btVolver.Location = New Point(32, 594)
        btVolver.Name = "btVolver"
        btVolver.Size = New Size(137, 47)
        btVolver.TabIndex = 5
        btVolver.Text = "Volver"
        btVolver.UseVisualStyleBackColor = False
        ' 
        ' btAniadir
        ' 
        btAniadir.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(128))
        btAniadir.Cursor = Cursors.Hand
        btAniadir.Font = New Font("MS Reference Sans Serif", 15F)
        btAniadir.Location = New Point(168, 364)
        btAniadir.Name = "btAniadir"
        btAniadir.Size = New Size(394, 112)
        btAniadir.TabIndex = 6
        btAniadir.Text = "Añadir Empleado"
        btAniadir.UseVisualStyleBackColor = False
        btAniadir.Visible = False
        ' 
        ' btModificar
        ' 
        btModificar.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(128))
        btModificar.Cursor = Cursors.Hand
        btModificar.Font = New Font("MS Reference Sans Serif", 15F)
        btModificar.Location = New Point(683, 364)
        btModificar.Name = "btModificar"
        btModificar.Size = New Size(386, 112)
        btModificar.TabIndex = 7
        btModificar.Text = "Modificar Empleado"
        btModificar.UseVisualStyleBackColor = False
        btModificar.Visible = False
        ' 
        ' btOcultar
        ' 
        btOcultar.BackColor = Color.SaddleBrown
        btOcultar.Cursor = Cursors.Hand
        btOcultar.Font = New Font("MS Reference Sans Serif", 15F)
        btOcultar.Location = New Point(532, 508)
        btOcultar.Name = "btOcultar"
        btOcultar.Size = New Size(182, 86)
        btOcultar.TabIndex = 9
        btOcultar.Text = "Ocultar"
        btOcultar.UseVisualStyleBackColor = False
        btOcultar.Visible = False
        ' 
        ' lblTitulo
        ' 
        lblTitulo.AutoSize = True
        lblTitulo.Font = New Font("MS Reference Sans Serif", 26.8000011F, FontStyle.Bold)
        lblTitulo.Location = New Point(387, 41)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(495, 55)
        lblTitulo.TabIndex = 10
        lblTitulo.Text = "Menú Administrador"
        ' 
        ' btModificarFamilias
        ' 
        btModificarFamilias.BackColor = Color.CornflowerBlue
        btModificarFamilias.Cursor = Cursors.Hand
        btModificarFamilias.Font = New Font("MS Reference Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btModificarFamilias.Location = New Point(648, 160)
        btModificarFamilias.Name = "btModificarFamilias"
        btModificarFamilias.Size = New Size(256, 145)
        btModificarFamilias.TabIndex = 11
        btModificarFamilias.Text = "Modificar Familias"
        btModificarFamilias.UseVisualStyleBackColor = False
        ' 
        ' btInforme
        ' 
        btInforme.BackColor = SystemColors.AppWorkspace
        btInforme.Cursor = Cursors.Hand
        btInforme.Font = New Font("MS Reference Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btInforme.Location = New Point(950, 160)
        btInforme.Name = "btInforme"
        btInforme.Size = New Size(256, 145)
        btInforme.TabIndex = 12
        btInforme.Text = "Informe diario"
        btInforme.UseVisualStyleBackColor = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(1072, 41)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(115, 64)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 13
        PictureBox1.TabStop = False
        ' 
        ' AdministradorMenu
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1262, 673)
        Controls.Add(PictureBox1)
        Controls.Add(btInforme)
        Controls.Add(btModificarFamilias)
        Controls.Add(lblTitulo)
        Controls.Add(btOcultar)
        Controls.Add(btModificar)
        Controls.Add(btAniadir)
        Controls.Add(btVolver)
        Controls.Add(btModificarProductos)
        Controls.Add(btModificarEmpleados)
        Name = "AdministradorMenu"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Menu Administrador"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btModificarEmpleados As Button
    Friend WithEvents btModificarProductos As Button
    Friend WithEvents btVolver As Button
    Friend WithEvents btAniadir As Button
    Friend WithEvents btModificar As Button
    Friend WithEvents btOcultar As Button
    Friend WithEvents lblTitulo As Label
    Friend WithEvents btModificarFamilias As Button
    Friend WithEvents btInforme As Button
    Friend WithEvents PictureBox1 As PictureBox
End Class
