﻿Imports System.Data.SqlClient
Imports System.Globalization
Imports System.IO
Imports System.Security.Policy

Public Class AdministradorMenu

    Private Sub btVolver_Click(sender As Object, e As EventArgs) Handles btVolver.Click
        Dim formMain As New PantallaInicio()
        formMain.Show()
        Me.Close()
    End Sub

    Private Sub btModificarEmpleado_Click(sender As Object, e As EventArgs) Handles btModificarEmpleados.Click
        mostrarBotonesEmpleados()
    End Sub
    Private Sub btModificarProductos_Click(sender As Object, e As EventArgs) Handles btModificarProductos.Click
        mostrarBotonesArticulos()
    End Sub
    Private Sub btModificarFamilias_Click(sender As Object, e As EventArgs) Handles btModificarFamilias.Click
        mostrarBotonesFamilias()
    End Sub

    Private Sub btAniadir_Click(sender As Object, e As EventArgs) Handles btAniadir.Click
        If btAniadir.Text = "Añadir Empleado" Then
            Dim formAnadirEmpleado As New AnadirEmpleado()
            formAnadirEmpleado.Show()
            Me.Close()
        ElseIf btAniadir.Text = "Añadir Producto" Then
            Dim formAnadirProducto As New AnadirProducto()
            formAnadirProducto.Show()
            Me.Close()
        ElseIf btAniadir.Text = "Añadir Familia" Then
            Dim formAnadirFamilia As New AnadirFamilia()
            formAnadirFamilia.Show()
            Me.Close()
        End If
    End Sub

    Private Sub btModificar_Click(sender As Object, e As EventArgs) Handles btModificar.Click
        If btAniadir.Text = "Añadir Empleado" Then
            Dim formModificarEmpleado As New ModificarEmpleado()
            formModificarEmpleado.Show()
            Me.Close()
        ElseIf btAniadir.Text = "Añadir Producto" Then
            Dim formModificarArticulo As New ModificarArticulo()
            formModificarArticulo.Show()
            Me.Close()
        ElseIf btAniadir.Text = "Añadir Familia" Then
            Dim formModificarFamilia As New ModificarFamilia()
            formModificarFamilia.Show()
            Me.Close()
        End If
    End Sub

    Private Sub mostrarBotonesEmpleados()
        btAniadir.Text = "Añadir Empleado"
        btModificar.Text = "Modificar Empleados"
        If Not btAniadir.Visible Then
            btAniadir.Visible = True
            btModificar.Visible = True
            btOcultar.Visible = True
        End If
    End Sub
    Private Sub mostrarBotonesArticulos()
        btAniadir.Text = "Añadir Producto"
        btModificar.Text = "Modificar Productos"
        If Not btAniadir.Visible Then
            btAniadir.Visible = True
            btModificar.Visible = True
            btOcultar.Visible = True
        End If
    End Sub
    Private Sub mostrarBotonesFamilias()
        btAniadir.Text = "Añadir Familia"
        btModificar.Text = "Modificar Familias"
        If Not btAniadir.Visible Then
            btAniadir.Visible = True
            btModificar.Visible = True
            btOcultar.Visible = True
        End If
    End Sub

    Private Sub btOcultar_Click(sender As Object, e As EventArgs) Handles btOcultar.Click
        btAniadir.Visible = False
        btModificar.Visible = False
        btOcultar.Visible = False
    End Sub

    Private Sub btInforme_Click(sender As Object, e As EventArgs) Handles btInforme.Click
        Dim formInforme As New MostrarInforme()
        formInforme.Show()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        'Dim rutaArchivo As String = "Modificacion_de_Productos.txt"
        'Dim productos As New List(Of Tuple(Of String, Integer, Decimal))()

        'Try
        '    Dim lines As String() = File.ReadAllLines(rutaArchivo)
        '    For i As Integer = 0 To lines.Length - 1
        '        If lines(i).StartsWith("artículo:") Then
        '            Dim nombreArticulo As String = lines(i).Split(":")(1).Trim()
        '            Dim cantidadProducto As String = lines(i + 1).Trim()
        '            Dim precioProducto As String = lines(i + 2).Trim()
        '            Dim cantidad As Integer = CInt(cantidadProducto.Split(":")(1))
        '            Dim precio_unitario As Decimal = Decimal.Parse(precioProducto.Split(":")(1), CultureInfo.InvariantCulture)

        '            productos.Add(Tuple.Create(nombreArticulo, cantidad, precio_unitario))
        '            i += 2 'ya hemos cogido los datos de precio y cantidad que equivadlrian a las dos siguientes lienas
        '        End If
        '    Next
        'Catch ex As Exception
        '    MsgBox("Error al leer el archivo: ")
        'End Try

        'Const DATABASE_NAME = "Exides_Base_Datos"
        'Const DATABASE_SERVER = "PORTATIL_ASIER"
        'Const CONNECTION_STRING = "Data Source=" & DATABASE_SERVER & ";Initial Catalog=" & DATABASE_NAME & ";Integrated Security=True;MultipleActiveResultSets=True"

        'Using connection As New SqlConnection(CONNECTION_STRING)
        '    Try
        '        connection.Open()
        '        For Each item In productos
        '            Dim nombreArticulo As String = item.Item1
        '            Dim cantidad As Integer = item.Item2
        '            Dim precio_unitario As Decimal = item.Item3

        '            ' Si la cantidad es 0, no realizamos ninguna actualización para este artículo
        '            If cantidad = 0 Then
        '                Console.WriteLine($"No se actualiza {nombreArticulo} debido a que la cantidad es 0.")
        '                Continue For
        '            End If

        '            'guardamos el precio para comprobar si es menor y si es mayor
        '            Dim querySelect As String = "SELECT precio_venta FROM Articulos WHERE nombre_articulo = @nombreArticulo"
        '            Using commandSelect As New SqlCommand(querySelect, connection)
        '                commandSelect.Parameters.AddWithValue("@nombreArticulo", nombreArticulo)

        '                Using reader As SqlDataReader = commandSelect.ExecuteReader()
        '                    If reader.Read() Then
        '                        Dim dbPrecioVenta As Decimal = Convert.ToDecimal(reader("precio_venta"))

        '                        'si el precio es igual o no es superiror a 0.25 actualizamso el precio del os articulso
        '                        If precio_unitario - dbPrecioVenta >= 0.25D Then
        '                            Dim nuevoPrecio As Decimal

        '                            'al tener que actualizar el precio le sumamos lo minimo de ganancia
        '                            nuevoPrecio = Math.Round(precio_unitario + 0.25D, 2)

        '                            'una vez comprobado actualizamdo los precios
        '                            Dim queryUpdatePrecio As String = "UPDATE Articulos SET precio_venta = @nuevoPrecio WHERE nombre_articulo = @nombreArticulo"
        '                            Using commandUpdatePrecio As New SqlCommand(queryUpdatePrecio, connection)
        '                                commandUpdatePrecio.Parameters.AddWithValue("@nuevoPrecio", nuevoPrecio)
        '                                commandUpdatePrecio.Parameters.AddWithValue("@nombreArticulo", nombreArticulo)
        '                                commandUpdatePrecio.ExecuteNonQuery()
        '                            End Using
        '                        End If

        '                        'la actualizacion del propio stock
        '                        Dim queryStock As String = "UPDATE Articulos SET cantidad_stock = cantidad_stock + @cantidad WHERE nombre_articulo = @nombreArticulo"
        '                        Using commandUpdateStock As New SqlCommand(queryStock, connection)
        '                            commandUpdateStock.Parameters.AddWithValue("@cantidad", cantidad)
        '                            commandUpdateStock.Parameters.AddWithValue("@nombreArticulo", nombreArticulo)
        '                            commandUpdateStock.ExecuteNonQuery()
        '                        End Using
        '                    End If
        '                End Using
        '            End Using
        '        Next
        '        MsgBox("Los datos se actualizaron CON ÉXITO")
        '    Catch ex As Exception
        '        MsgBox("ERROR al actualizar precios o stock: " & ex.Message)
        '    End Try
        'End Using
        Dim frm As New MostrarTickets()
        frm.Show()
        Me.Close()

    End Sub
End Class