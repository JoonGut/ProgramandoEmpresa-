﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AnadirEmpleado
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblTitulo = New Label()
        btVolver = New Button()
        lblNombre = New Label()
        tbNombre = New TextBox()
        tbUsuario = New TextBox()
        lblUsuario = New Label()
        tbContrasenia = New TextBox()
        lblContrasenia = New Label()
        ComboRol = New ComboBox()
        lblPosicion = New Label()
        btRegistrar = New Button()
        lblSeparacion = New Label()
        SuspendLayout()
        ' 
        ' lblTitulo
        ' 
        lblTitulo.AutoSize = True
        lblTitulo.Font = New Font("MS Reference Sans Serif", 26.8000011F, FontStyle.Bold)
        lblTitulo.Location = New Point(342, 40)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(563, 55)
        lblTitulo.TabIndex = 1
        lblTitulo.Text = "Crear Nuevo Empleado"
        ' 
        ' btVolver
        ' 
        btVolver.BackColor = Color.IndianRed
        btVolver.Cursor = Cursors.Hand
        btVolver.Font = New Font("MS Reference Sans Serif", 11F)
        btVolver.Location = New Point(49, 589)
        btVolver.Name = "btVolver"
        btVolver.Size = New Size(137, 47)
        btVolver.TabIndex = 6
        btVolver.Text = "Volver"
        btVolver.UseVisualStyleBackColor = False
        ' 
        ' lblNombre
        ' 
        lblNombre.AutoSize = True
        lblNombre.Font = New Font("MS Reference Sans Serif", 15F)
        lblNombre.Location = New Point(385, 193)
        lblNombre.Name = "lblNombre"
        lblNombre.Size = New Size(114, 32)
        lblNombre.TabIndex = 7
        lblNombre.Text = "Nombre"
        ' 
        ' tbNombre
        ' 
        tbNombre.Font = New Font("MS Reference Sans Serif", 15F)
        tbNombre.Location = New Point(602, 190)
        tbNombre.Name = "tbNombre"
        tbNombre.Size = New Size(270, 38)
        tbNombre.TabIndex = 8
        ' 
        ' tbUsuario
        ' 
        tbUsuario.Font = New Font("MS Reference Sans Serif", 15F)
        tbUsuario.Location = New Point(602, 270)
        tbUsuario.Name = "tbUsuario"
        tbUsuario.Size = New Size(270, 38)
        tbUsuario.TabIndex = 10
        ' 
        ' lblUsuario
        ' 
        lblUsuario.AutoSize = True
        lblUsuario.Font = New Font("MS Reference Sans Serif", 15F)
        lblUsuario.Location = New Point(391, 273)
        lblUsuario.Name = "lblUsuario"
        lblUsuario.Size = New Size(108, 32)
        lblUsuario.TabIndex = 9
        lblUsuario.Text = "Usuario"
        ' 
        ' tbContrasenia
        ' 
        tbContrasenia.Font = New Font("MS Reference Sans Serif", 15F)
        tbContrasenia.Location = New Point(602, 354)
        tbContrasenia.Name = "tbContrasenia"
        tbContrasenia.Size = New Size(270, 38)
        tbContrasenia.TabIndex = 12
        ' 
        ' lblContrasenia
        ' 
        lblContrasenia.AutoSize = True
        lblContrasenia.Font = New Font("MS Reference Sans Serif", 15F)
        lblContrasenia.Location = New Point(342, 354)
        lblContrasenia.Name = "lblContrasenia"
        lblContrasenia.Size = New Size(157, 32)
        lblContrasenia.TabIndex = 11
        lblContrasenia.Text = "Contraseña"
        ' 
        ' ComboRol
        ' 
        ComboRol.Font = New Font("MS Reference Sans Serif", 15F)
        ComboRol.FormattingEnabled = True
        ComboRol.Items.AddRange(New Object() {"Cocinero", "Personal de Barra", "Camarero", "Gerente"})
        ComboRol.Location = New Point(602, 437)
        ComboRol.Name = "ComboRol"
        ComboRol.Size = New Size(270, 40)
        ComboRol.TabIndex = 13
        ' 
        ' lblPosicion
        ' 
        lblPosicion.AutoSize = True
        lblPosicion.Font = New Font("MS Reference Sans Serif", 15F)
        lblPosicion.Location = New Point(386, 440)
        lblPosicion.Name = "lblPosicion"
        lblPosicion.Size = New Size(113, 32)
        lblPosicion.TabIndex = 14
        lblPosicion.Text = "Posición"
        ' 
        ' btRegistrar
        ' 
        btRegistrar.BackColor = SystemColors.ActiveCaption
        btRegistrar.Cursor = Cursors.Hand
        btRegistrar.Font = New Font("MS Reference Sans Serif", 20F)
        btRegistrar.ForeColor = SystemColors.ControlText
        btRegistrar.Location = New Point(459, 547)
        btRegistrar.Name = "btRegistrar"
        btRegistrar.Size = New Size(277, 89)
        btRegistrar.TabIndex = 15
        btRegistrar.Text = "Registrar"
        btRegistrar.UseVisualStyleBackColor = False
        ' 
        ' lblSeparacion
        ' 
        lblSeparacion.AutoSize = True
        lblSeparacion.Font = New Font("MS Reference Sans Serif", 18.8000011F, FontStyle.Bold)
        lblSeparacion.Location = New Point(232, 114)
        lblSeparacion.Name = "lblSeparacion"
        lblSeparacion.Size = New Size(769, 40)
        lblSeparacion.TabIndex = 16
        lblSeparacion.Text = "-----------------------------------------------"
        ' 
        ' AnadirEmpleado
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1262, 673)
        Controls.Add(lblSeparacion)
        Controls.Add(btRegistrar)
        Controls.Add(lblPosicion)
        Controls.Add(ComboRol)
        Controls.Add(tbContrasenia)
        Controls.Add(lblContrasenia)
        Controls.Add(tbUsuario)
        Controls.Add(lblUsuario)
        Controls.Add(tbNombre)
        Controls.Add(lblNombre)
        Controls.Add(btVolver)
        Controls.Add(lblTitulo)
        Name = "AnadirEmpleado"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Añadir Empleado"
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents lblTitulo As Label
    Friend WithEvents btVolver As Button
    Friend WithEvents lblNombre As Label
    Friend WithEvents tbNombre As TextBox
    Friend WithEvents tbUsuario As TextBox
    Friend WithEvents lblUsuario As Label
    Friend WithEvents tbContrasenia As TextBox
    Friend WithEvents lblContrasenia As Label
    Friend WithEvents ComboRol As ComboBox
    Friend WithEvents lblPosicion As Label
    Friend WithEvents btRegistrar As Button
    Friend WithEvents lblSeparacion As Label
    Friend WithEvents NumericUpDown1 As NumericUpDown
End Class
