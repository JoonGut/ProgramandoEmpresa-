﻿Imports System.Data.SqlClient

Public Class AnadirEmpleado
    Private Sub btVolver_Click(sender As Object, e As EventArgs) Handles btVolver.Click
        Dim formAdministradorMenu As New AdministradorMenu
        formAdministradorMenu.Show()
        Close()
    End Sub

    Private Sub btRegistrar_Click(sender As Object, e As EventArgs) Handles btRegistrar.Click
        Dim nombre As String = tbNombre.Text
        If nombre = "" Then
            MessageBox.Show("Por favor escribe un nombre antes de continuar.", "Campos sin rellenar", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If
        Dim usuario As String = tbNombre.Text
        If usuario = "" Then
            MessageBox.Show("Por favor escribe un usuario antes de continuar.", "Campos sin rellenar", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If
        Dim contrasenia As String = tbContrasenia.Text
        If contrasenia = "" Then
            MessageBox.Show("Por favor escribe una contraseña antes de continuar.", "Campos sin rellenar", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If
        Dim posicion As String = ComboRol.Text
        Dim idRol As Integer
        If posicion = "Camarero" Then
            idRol = 2
        ElseIf posicion = "Gerente" Then
            idRol = 1
        ElseIf posicion = "Personal de Barra" Then
            idRol = 3
        ElseIf posicion = "Cocinero" Then
            idRol = 4
        Else
            MessageBox.Show("Por favor selecciona el rol antes de continuar.", "Campos sin rellenar", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If
        If usuarioSePuedeUsar(usuario) Then
            Dim query As String = "INSERT INTO Empleados (nombre, contrasenia, usuario, id_rol) VALUES (@nombre, @password, @usuario, @idRol)"
            Dim command As New SqlClient.SqlCommand(query, connection)
            command.Parameters.AddWithValue("@nombre", nombre)
            command.Parameters.AddWithValue("@password", contrasenia)
            command.Parameters.AddWithValue("@usuario", usuario)
            command.Parameters.AddWithValue("@idRol", idRol)

            Try
                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If
                command.ExecuteNonQuery()
                connection.Close()
                MessageBox.Show("El empleado se ha creado correctamente.", "Empleado creado", MessageBoxButtons.OK, MessageBoxIcon.Information)
                tbNombre.Text = ""
                tbUsuario.Text = ""
                tbContrasenia.Text = ""
                ComboRol.Text = ""
            Catch ex As Exception
                MsgBox("Error al añadir empleado: " & ex.Message)
            Finally
                If connection.State = ConnectionState.Open Then
                    connection.Close()
                End If
            End Try
        Else
            MessageBox.Show("El usuario ya está en uso.", "No se ha podido crear", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Function usuarioSePuedeUsar(usuarioComprobar)
        Dim query As String = "SELECT usuario from Empleados WHERE usuario = '" & usuarioComprobar & "'"
        Dim command As New SqlClient.SqlCommand(query, connection)
        Try
            If connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            Dim sePuedeUsarElUsuario As Boolean
            Dim hayRegistros As Object = command.ExecuteScalar()
            If hayRegistros Is Nothing Then
                sePuedeUsarElUsuario = True
            Else
                sePuedeUsarElUsuario = False
            End If
            Return sePuedeUsarElUsuario
        Catch ex As Exception
            MsgBox("Error al añadir empleado: " & ex.Message)
            Return False
        End Try
    End Function
End Class