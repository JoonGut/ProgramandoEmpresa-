﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AnadirFamilia
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel = New Panel()
        tbNombreFamilia = New TextBox()
        btCrearFamilia = New Button()
        lblNombreFamilia = New Label()
        lblSeparacion = New Label()
        lblTitulo = New Label()
        btVolver = New Button()
        Panel.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel
        ' 
        Panel.BackColor = SystemColors.ScrollBar
        Panel.Controls.Add(tbNombreFamilia)
        Panel.Controls.Add(btCrearFamilia)
        Panel.Controls.Add(lblNombreFamilia)
        Panel.Location = New Point(344, 183)
        Panel.Name = "Panel"
        Panel.Size = New Size(575, 338)
        Panel.TabIndex = 13
        ' 
        ' tbNombreFamilia
        ' 
        tbNombreFamilia.Font = New Font("MS Reference Sans Serif", 15F)
        tbNombreFamilia.Location = New Point(299, 83)
        tbNombreFamilia.Name = "tbNombreFamilia"
        tbNombreFamilia.Size = New Size(233, 38)
        tbNombreFamilia.TabIndex = 2
        ' 
        ' btCrearFamilia
        ' 
        btCrearFamilia.BackColor = SystemColors.ActiveCaption
        btCrearFamilia.Cursor = Cursors.Hand
        btCrearFamilia.Font = New Font("MS Reference Sans Serif", 18F, FontStyle.Bold)
        btCrearFamilia.Location = New Point(130, 202)
        btCrearFamilia.Name = "btCrearFamilia"
        btCrearFamilia.Size = New Size(288, 110)
        btCrearFamilia.TabIndex = 1
        btCrearFamilia.Text = "Crear"
        btCrearFamilia.UseVisualStyleBackColor = False
        ' 
        ' lblNombreFamilia
        ' 
        lblNombreFamilia.AutoSize = True
        lblNombreFamilia.Font = New Font("MS Reference Sans Serif", 15F)
        lblNombreFamilia.Location = New Point(37, 86)
        lblNombreFamilia.Name = "lblNombreFamilia"
        lblNombreFamilia.Size = New Size(209, 32)
        lblNombreFamilia.TabIndex = 0
        lblNombreFamilia.Text = "Nombre Familia"
        ' 
        ' lblSeparacion
        ' 
        lblSeparacion.AutoSize = True
        lblSeparacion.Font = New Font("MS Reference Sans Serif", 18.8000011F, FontStyle.Bold)
        lblSeparacion.Location = New Point(234, 111)
        lblSeparacion.Name = "lblSeparacion"
        lblSeparacion.Size = New Size(769, 40)
        lblSeparacion.TabIndex = 18
        lblSeparacion.Text = "-----------------------------------------------"
        ' 
        ' lblTitulo
        ' 
        lblTitulo.AutoSize = True
        lblTitulo.Font = New Font("MS Reference Sans Serif", 26.8000011F, FontStyle.Bold)
        lblTitulo.Location = New Point(375, 45)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(501, 55)
        lblTitulo.TabIndex = 17
        lblTitulo.Text = "Crear Nueva Familia"
        ' 
        ' btVolver
        ' 
        btVolver.BackColor = Color.IndianRed
        btVolver.Cursor = Cursors.Hand
        btVolver.Font = New Font("MS Reference Sans Serif", 11F)
        btVolver.Location = New Point(31, 602)
        btVolver.Name = "btVolver"
        btVolver.Size = New Size(137, 47)
        btVolver.TabIndex = 19
        btVolver.Text = "Volver"
        btVolver.UseVisualStyleBackColor = False
        ' 
        ' AnadirFamilia
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1262, 673)
        Controls.Add(btVolver)
        Controls.Add(lblSeparacion)
        Controls.Add(lblTitulo)
        Controls.Add(Panel)
        Name = "AnadirFamilia"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Añadir Familia"
        Panel.ResumeLayout(False)
        Panel.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Panel As Panel
    Friend WithEvents tbNombreFamilia As TextBox
    Friend WithEvents btCrearFamilia As Button
    Friend WithEvents lblNombreFamilia As Label
    Friend WithEvents lblSeparacion As Label
    Friend WithEvents lblTitulo As Label
    Friend WithEvents btVolver As Button
End Class
