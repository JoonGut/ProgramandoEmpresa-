﻿Imports System.Data.SqlClient

Public Class AnadirFamilia

    Private Sub btCrearFamilia_Click(sender As Object, e As EventArgs) Handles btCrearFamilia.Click
        Dim idFamilia As Integer = generarIdFamilia()
        Dim nombre As String
        nombre = tbNombreFamilia.Text
        Dim query = "INSERT INTO Familias (id_familia, nombre_familia) VALUES (@id, @nombre)"
        Dim command As New SqlCommand(query, connection)
        command.Parameters.AddWithValue("@id", idFamilia)
        command.Parameters.AddWithValue("@nombre", nombre)

        Try
            If connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            command.ExecuteNonQuery()
            connection.Close()
            MessageBox.Show("La familia se ha creado correctamente.", "Familia creada", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MsgBox("Error al añadir la familia: " & ex.Message)
        Finally
            If connection.State = ConnectionState.Open Then
                connection.Close()
            End If
        End Try
        tbNombreFamilia.Text = ""
    End Sub

    Private Function generarIdFamilia()
        Dim query As String = "SELECT MAX(id_familia) from Familias"
        Dim command As New SqlClient.SqlCommand(query, connection)
        Try
            If connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            Dim idAnterior As Integer = command.ExecuteScalar()
            Dim idReturn As Integer = idAnterior + 1
            Return idReturn
        Catch ex As Exception
            MsgBox("Error al añadir la familia: " & ex.Message)
            Return 0
        End Try
    End Function

    Private Sub btVolver_Click(sender As Object, e As EventArgs) Handles btVolver.Click
        Dim formAdministradorMenu As New AdministradorMenu
        formAdministradorMenu.Show()
        Close()
    End Sub

End Class