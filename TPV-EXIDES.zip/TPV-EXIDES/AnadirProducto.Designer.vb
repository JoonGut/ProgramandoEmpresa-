﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AnadirProducto
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblSeparacion = New Label()
        btRegistrar = New Button()
        lblIVA = New Label()
        lblStock = New Label()
        lblUsuario = New Label()
        tbNombre = New TextBox()
        lblNombre = New Label()
        btVolver = New Button()
        lblTitulo = New Label()
        NumericPrecio = New NumericUpDown()
        NumericStock = New NumericUpDown()
        NumericIVA = New NumericUpDown()
        lblFamilia = New Label()
        ComboFamilia = New ComboBox()
        tbURL = New TextBox()
        lblURL = New Label()
        PictureArticulo = New PictureBox()
        CType(NumericPrecio, ComponentModel.ISupportInitialize).BeginInit()
        CType(NumericStock, ComponentModel.ISupportInitialize).BeginInit()
        CType(NumericIVA, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureArticulo, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblSeparacion
        ' 
        lblSeparacion.AutoSize = True
        lblSeparacion.Font = New Font("MS Reference Sans Serif", 18.8000011F, FontStyle.Bold)
        lblSeparacion.Location = New Point(237, 112)
        lblSeparacion.Name = "lblSeparacion"
        lblSeparacion.Size = New Size(769, 40)
        lblSeparacion.TabIndex = 28
        lblSeparacion.Text = "-----------------------------------------------"
        ' 
        ' btRegistrar
        ' 
        btRegistrar.BackColor = SystemColors.ActiveCaption
        btRegistrar.Cursor = Cursors.Hand
        btRegistrar.Font = New Font("MS Reference Sans Serif", 20F)
        btRegistrar.ForeColor = SystemColors.ControlText
        btRegistrar.Location = New Point(464, 545)
        btRegistrar.Name = "btRegistrar"
        btRegistrar.Size = New Size(277, 89)
        btRegistrar.TabIndex = 27
        btRegistrar.Text = "Registrar"
        btRegistrar.UseVisualStyleBackColor = False
        ' 
        ' lblIVA
        ' 
        lblIVA.AutoSize = True
        lblIVA.Font = New Font("MS Reference Sans Serif", 15F)
        lblIVA.Location = New Point(223, 394)
        lblIVA.Name = "lblIVA"
        lblIVA.Size = New Size(94, 32)
        lblIVA.TabIndex = 26
        lblIVA.Text = "% IVA"
        ' 
        ' lblStock
        ' 
        lblStock.AutoSize = True
        lblStock.Font = New Font("MS Reference Sans Serif", 15F)
        lblStock.Location = New Point(233, 326)
        lblStock.Name = "lblStock"
        lblStock.Size = New Size(84, 32)
        lblStock.TabIndex = 23
        lblStock.Text = "Stock"
        ' 
        ' lblUsuario
        ' 
        lblUsuario.AutoSize = True
        lblUsuario.Font = New Font("MS Reference Sans Serif", 15F)
        lblUsuario.Location = New Point(228, 259)
        lblUsuario.Name = "lblUsuario"
        lblUsuario.Size = New Size(89, 32)
        lblUsuario.TabIndex = 21
        lblUsuario.Text = "Precio"
        ' 
        ' tbNombre
        ' 
        tbNombre.Font = New Font("MS Reference Sans Serif", 15F)
        tbNombre.Location = New Point(420, 191)
        tbNombre.Name = "tbNombre"
        tbNombre.Size = New Size(270, 38)
        tbNombre.TabIndex = 20
        ' 
        ' lblNombre
        ' 
        lblNombre.AutoSize = True
        lblNombre.Font = New Font("MS Reference Sans Serif", 15F)
        lblNombre.Location = New Point(100, 194)
        lblNombre.Name = "lblNombre"
        lblNombre.Size = New Size(217, 32)
        lblNombre.TabIndex = 19
        lblNombre.Text = "Nombre Articulo"
        ' 
        ' btVolver
        ' 
        btVolver.BackColor = Color.IndianRed
        btVolver.Cursor = Cursors.Hand
        btVolver.Font = New Font("MS Reference Sans Serif", 11F)
        btVolver.Location = New Point(54, 587)
        btVolver.Name = "btVolver"
        btVolver.Size = New Size(137, 47)
        btVolver.TabIndex = 18
        btVolver.Text = "Volver"
        btVolver.UseVisualStyleBackColor = False
        ' 
        ' lblTitulo
        ' 
        lblTitulo.AutoSize = True
        lblTitulo.Font = New Font("MS Reference Sans Serif", 26.8000011F, FontStyle.Bold)
        lblTitulo.Location = New Point(342, 38)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(539, 55)
        lblTitulo.TabIndex = 17
        lblTitulo.Text = "Crear Nuevo Producto"
        ' 
        ' NumericPrecio
        ' 
        NumericPrecio.DecimalPlaces = 2
        NumericPrecio.Font = New Font("MS Reference Sans Serif", 15F)
        NumericPrecio.Increment = New Decimal(New Integer() {5, 0, 0, 65536})
        NumericPrecio.Location = New Point(420, 257)
        NumericPrecio.Name = "NumericPrecio"
        NumericPrecio.Size = New Size(274, 38)
        NumericPrecio.TabIndex = 29
        NumericPrecio.Value = New Decimal(New Integer() {1, 0, 0, 0})
        ' 
        ' NumericStock
        ' 
        NumericStock.Font = New Font("MS Reference Sans Serif", 15F)
        NumericStock.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        NumericStock.Location = New Point(420, 324)
        NumericStock.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        NumericStock.Name = "NumericStock"
        NumericStock.Size = New Size(274, 38)
        NumericStock.TabIndex = 30
        NumericStock.Value = New Decimal(New Integer() {10, 0, 0, 0})
        ' 
        ' NumericIVA
        ' 
        NumericIVA.Font = New Font("MS Reference Sans Serif", 15F)
        NumericIVA.Location = New Point(420, 392)
        NumericIVA.Maximum = New Decimal(New Integer() {21, 0, 0, 0})
        NumericIVA.Name = "NumericIVA"
        NumericIVA.Size = New Size(274, 38)
        NumericIVA.TabIndex = 31
        NumericIVA.Value = New Decimal(New Integer() {21, 0, 0, 0})
        ' 
        ' lblFamilia
        ' 
        lblFamilia.AutoSize = True
        lblFamilia.Font = New Font("MS Reference Sans Serif", 15F)
        lblFamilia.Location = New Point(223, 464)
        lblFamilia.Name = "lblFamilia"
        lblFamilia.Size = New Size(100, 32)
        lblFamilia.TabIndex = 32
        lblFamilia.Text = "Familia"
        ' 
        ' ComboFamilia
        ' 
        ComboFamilia.Font = New Font("MS Reference Sans Serif", 15F)
        ComboFamilia.FormattingEnabled = True
        ComboFamilia.Location = New Point(420, 461)
        ComboFamilia.Name = "ComboFamilia"
        ComboFamilia.Size = New Size(274, 40)
        ComboFamilia.TabIndex = 33
        ' 
        ' tbURL
        ' 
        tbURL.Font = New Font("MS Reference Sans Serif", 15F)
        tbURL.Location = New Point(842, 461)
        tbURL.Name = "tbURL"
        tbURL.Size = New Size(348, 38)
        tbURL.TabIndex = 35
        ' 
        ' lblURL
        ' 
        lblURL.AutoSize = True
        lblURL.Font = New Font("MS Reference Sans Serif", 15F)
        lblURL.Location = New Point(925, 426)
        lblURL.Name = "lblURL"
        lblURL.Size = New Size(168, 32)
        lblURL.TabIndex = 34
        lblURL.Text = "URL Imagen"
        ' 
        ' PictureArticulo
        ' 
        PictureArticulo.Location = New Point(842, 178)
        PictureArticulo.Name = "PictureArticulo"
        PictureArticulo.Size = New Size(348, 213)
        PictureArticulo.TabIndex = 36
        PictureArticulo.TabStop = False
        ' 
        ' AnadirProducto
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1262, 673)
        Controls.Add(PictureArticulo)
        Controls.Add(tbURL)
        Controls.Add(lblURL)
        Controls.Add(ComboFamilia)
        Controls.Add(lblFamilia)
        Controls.Add(NumericIVA)
        Controls.Add(NumericStock)
        Controls.Add(NumericPrecio)
        Controls.Add(lblSeparacion)
        Controls.Add(btRegistrar)
        Controls.Add(lblIVA)
        Controls.Add(lblStock)
        Controls.Add(lblUsuario)
        Controls.Add(tbNombre)
        Controls.Add(lblNombre)
        Controls.Add(btVolver)
        Controls.Add(lblTitulo)
        Name = "AnadirProducto"
        StartPosition = FormStartPosition.CenterScreen
        Text = "AnadirProducto"
        CType(NumericPrecio, ComponentModel.ISupportInitialize).EndInit()
        CType(NumericStock, ComponentModel.ISupportInitialize).EndInit()
        CType(NumericIVA, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureArticulo, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblSeparacion As Label
    Friend WithEvents btRegistrar As Button
    Friend WithEvents lblIVA As Label
    Friend WithEvents tbContrasenia As TextBox
    Friend WithEvents lblStock As Label
    Friend WithEvents lblUsuario As Label
    Friend WithEvents tbNombre As TextBox
    Friend WithEvents lblNombre As Label
    Friend WithEvents btVolver As Button
    Friend WithEvents lblTitulo As Label
    Friend WithEvents NumericPrecio As NumericUpDown
    Friend WithEvents NumericStock As NumericUpDown
    Friend WithEvents NumericIVA As NumericUpDown
    Friend WithEvents lblFamilia As Label
    Friend WithEvents ComboFamilia As ComboBox
    Friend WithEvents tbURL As TextBox
    Friend WithEvents lblURL As Label
    Friend WithEvents PictureArticulo As PictureBox
End Class
