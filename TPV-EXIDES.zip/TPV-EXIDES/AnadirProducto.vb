﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Runtime.InteropServices.JavaScript.JSType
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports System.Net

Public Class AnadirProducto
    Dim idArticulo As Integer
    Dim nombre As String
    Dim stock As Integer
    Dim precio As Double
    Dim iva As Integer
    Dim idFamilia As Integer
    Dim urlImagen As String
    Dim nuevaFamilia As String

    Private Sub lblContrasenia_Click(sender As Object, e As EventArgs) Handles lblStock.Click
    End Sub

    Private Sub btRegistrar_Click(sender As Object, e As EventArgs) Handles btRegistrar.Click
        idArticulo = generarIdArticulo()
        If idArticulo = 0 Then
            MessageBox.Show("Algo no fue bien.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If
        nombre = tbNombre.Text
        precio = NumericPrecio.Text
        stock = NumericStock.Text
        iva = NumericIVA.Text
        urlImagen = tbURL.Text
        nuevaFamilia = ComboFamilia.Text
        idFamilia = getIdFamilia(nuevaFamilia)

        Dim query As String = "INSERT INTO Articulos (id_articulo, nombre_articulo, precio_venta, cantidad_stock, IVA, id_familia, url) VALUES (@id, @nombre, @precio, @stock, @iva, @idFamilia, @url)"
        Dim command As New SqlClient.SqlCommand(query, connection)
        command.Parameters.AddWithValue("@id", idArticulo)
        command.Parameters.AddWithValue("@nombre", nombre)
        command.Parameters.AddWithValue("@precio", precio)
        command.Parameters.AddWithValue("@stock", stock)
        command.Parameters.AddWithValue("@iva", iva)
        command.Parameters.AddWithValue("@idFamilia", idFamilia)
        command.Parameters.AddWithValue("@url", urlImagen)

        Try
            If connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            command.ExecuteNonQuery()
            connection.Close()
            MessageBox.Show("El articulo se ha creado correctamente.", "Articulo creado", MessageBoxButtons.OK, MessageBoxIcon.Information)
            tbNombre.Text = ""
            NumericPrecio.Text = "1"
            NumericStock.Text = "10"
            NumericIVA.Text = "21"
            tbURL.Text = ""
            ComboFamilia.Text = ""
        Catch ex As Exception
            MsgBox("Error al añadir el articulo: " & ex.Message)
        Finally
            If connection.State = ConnectionState.Open Then
                connection.Close()
            End If
        End Try

    End Sub

    Private Sub cargarURL()
        Try
            Dim request As System.Net.WebRequest = System.Net.WebRequest.Create(tbURL.Text)
            Dim response As System.Net.WebResponse = request.GetResponse()
            Dim stream As System.IO.Stream = response.GetResponseStream()
            Dim originalImage As Image = Image.FromStream(stream)
            Dim ratioX As Double = PictureArticulo.Width / originalImage.Width
            Dim ratioY As Double = PictureArticulo.Height / originalImage.Height
            Dim ratio As Double = Math.Min(ratioX, ratioY)
            Dim newWidth As Integer = CInt(originalImage.Width * ratio)
            Dim newHeight As Integer = CInt(originalImage.Height * ratio)
            Dim newImage As New Bitmap(newWidth, newHeight)
            Using g As Graphics = Graphics.FromImage(newImage)
                g.InterpolationMode = Drawing2D.InterpolationMode.HighQualityBicubic
                g.DrawImage(originalImage, 0, 0, newWidth, newHeight)
            End Using
            PictureArticulo.SizeMode = PictureBoxSizeMode.CenterImage
            PictureArticulo.Image = newImage
            originalImage.Dispose()
        Catch ex As Exception
            PictureArticulo.Image = Image.FromFile(Path.GetFullPath("src/error_icon.png"))
            PictureArticulo.SizeMode = PictureBoxSizeMode.CenterImage
        End Try
    End Sub

    Private Function generarIdArticulo()
        Dim query As String = "SELECT MAX(id_articulo) from Articulos"
        Dim command As New SqlClient.SqlCommand(query, connection)
        Try
            If connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            Dim idAnterior As Integer = command.ExecuteScalar()
            Dim idReturn As Integer = idAnterior + 1
            Return idReturn
        Catch ex As Exception
            MsgBox("Error al añadir empleado: " & ex.Message)
            Return 0
        End Try
    End Function

    Private Sub tbURL_TextChanged(sender As Object, e As EventArgs) Handles tbURL.TextChanged
        cargarURL()
    End Sub

    Private Sub btVolver_Click(sender As Object, e As EventArgs) Handles btVolver.Click
        Dim formAdministradorMenu As New AdministradorMenu()
        formAdministradorMenu.Show()
        Me.Close()
    End Sub

    Private Sub AnadirProducto_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboFamilia.Items.Clear()

        Dim query As String = "SELECT nombre_familia FROM Familias"
        Dim command As New SqlClient.SqlCommand(query, connection)

        If connection.State = ConnectionState.Closed Then
            connection.Open()
        End If

        Using reader As SqlClient.SqlDataReader = command.ExecuteReader()
            While reader.Read()
                ComboFamilia.Items.Add(reader("nombre_familia").ToString())
            End While
        End Using

        connection.Close()
    End Sub

    Private Function getIdFamilia(familiaNombre As String) As Integer
        Dim idFamilia As Integer = 0
        Dim query As String = "SELECT id_familia FROM Familias WHERE nombre_familia = @familiaNombre"
        Try
            Using command As New SqlClient.SqlCommand(query, connection)
                command.Parameters.AddWithValue("@familiaNombre", familiaNombre.Trim())
                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If
                Dim result = command.ExecuteScalar()
                If result IsNot Nothing Then
                    idFamilia = Convert.ToInt32(result)
                Else
                    MsgBox("No se encontró una familia con el nombre: " & familiaNombre, MsgBoxStyle.Information, "Familia no encontrada")
                End If
            End Using
        Catch ex As Exception
            MsgBox("Error al modificar el producto: " & ex.Message, MsgBoxStyle.Critical, "Error")
        Finally
            If connection.State = ConnectionState.Open Then
                connection.Close()
            End If
        End Try
        Return idFamilia
    End Function
End Class