﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CamareroMenu
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CamareroMenu))
        lblNombreCamarero = New Label()
        btNuevaComanda = New Button()
        PictureBox1 = New PictureBox()
        btVolver = New Button()
        btMisComandas = New Button()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblNombreCamarero
        ' 
        lblNombreCamarero.AutoSize = True
        lblNombreCamarero.Font = New Font("Segoe UI", 22F)
        lblNombreCamarero.ForeColor = Color.Teal
        lblNombreCamarero.Location = New Point(91, 35)
        lblNombreCamarero.Name = "lblNombreCamarero"
        lblNombreCamarero.Size = New Size(46, 50)
        lblNombreCamarero.TabIndex = 0
        lblNombreCamarero.Text = "..."
        ' 
        ' btNuevaComanda
        ' 
        btNuevaComanda.BackColor = Color.FromArgb(CByte(192), CByte(255), CByte(192))
        btNuevaComanda.Cursor = Cursors.Hand
        btNuevaComanda.Font = New Font("Segoe UI", 23F)
        btNuevaComanda.ForeColor = Color.DarkGreen
        btNuevaComanda.Location = New Point(350, 165)
        btNuevaComanda.Name = "btNuevaComanda"
        btNuevaComanda.Size = New Size(477, 272)
        btNuevaComanda.TabIndex = 1
        btNuevaComanda.Text = "Nueva Comanda"
        btNuevaComanda.UseVisualStyleBackColor = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(25, 23)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(60, 67)
        PictureBox1.TabIndex = 3
        PictureBox1.TabStop = False
        ' 
        ' btVolver
        ' 
        btVolver.BackColor = Color.LightCoral
        btVolver.Cursor = Cursors.Hand
        btVolver.Font = New Font("Segoe UI", 11F)
        btVolver.ForeColor = Color.DarkRed
        btVolver.Location = New Point(55, 564)
        btVolver.Name = "btVolver"
        btVolver.Size = New Size(184, 71)
        btVolver.TabIndex = 4
        btVolver.Text = "Cerrar Sesión"
        btVolver.UseVisualStyleBackColor = False
        ' 
        ' btMisComandas
        ' 
        btMisComandas.BackColor = SystemColors.ActiveCaption
        btMisComandas.Cursor = Cursors.Hand
        btMisComandas.Font = New Font("Segoe UI", 15F)
        btMisComandas.ForeColor = Color.FromArgb(CByte(0), CByte(0), CByte(192))
        btMisComandas.Location = New Point(894, 521)
        btMisComandas.Name = "btMisComandas"
        btMisComandas.Size = New Size(309, 114)
        btMisComandas.TabIndex = 5
        btMisComandas.Text = "Mis Comandas"
        btMisComandas.UseVisualStyleBackColor = False
        ' 
        ' CamareroMenu
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1262, 673)
        Controls.Add(btMisComandas)
        Controls.Add(btVolver)
        Controls.Add(PictureBox1)
        Controls.Add(btNuevaComanda)
        Controls.Add(lblNombreCamarero)
        Name = "CamareroMenu"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Menu Camarero"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblNombreCamarero As Label
    Friend WithEvents btNuevaComanda As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btVolver As Button
    Friend WithEvents btMisComandas As Button
End Class
