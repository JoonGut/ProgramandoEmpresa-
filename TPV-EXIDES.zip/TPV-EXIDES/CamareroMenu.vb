﻿Public Class CamareroMenu
    Dim nombreCamarero As String
    Public Sub New(nombre As String)
        InitializeComponent()
        nombreCamarero = nombre
        lblNombreCamarero.Text = "Buenos días, " + nombreCamarero
    End Sub
    Private Sub btVolver_Click(sender As Object, e As EventArgs) Handles btVolver.Click
        Dim formInicioCamarero As New InicioCamarero()
        formInicioCamarero.Show()
        Me.Close()
    End Sub
    Private Sub btNuevaComanda_Click(sender As Object, e As EventArgs) Handles btNuevaComanda.Click
        Dim formComanda As New NuevaComanda(nombreCamarero)
        formComanda.Show()
        Me.Close()
        'MsgBox(nombreCamarero)

    End Sub
    Private Sub btMisComandas_Click(sender As Object, e As EventArgs) Handles btMisComandas.Click
        Dim formComanda As New MostrarComandas(nombreCamarero)
        formComanda.Show()
        Me.Close()
    End Sub
End Class

