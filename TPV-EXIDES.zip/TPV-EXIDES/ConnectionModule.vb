﻿Imports System.Data.SqlClient

Module ConnectionModule
    'Variables para la conexion a la BBDD
    Const DATABASE_NAME = "Exides_Base_Datos"
    Const DATABASE_SERVER = "PORTATIL_ASIER"   'nombre del servidor
    Const CONNECTION_STRING = "Data Source=" & DATABASE_SERVER & ";Initial Catalog=" & DATABASE_NAME & ";Integrated Security=True"
    Public connection As New SqlConnection(CONNECTION_STRING)
End Module
