﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class InicioAdministrador
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblTitulo = New Label()
        Label2 = New Label()
        lblInfo = New Label()
        lblUsuario = New Label()
        tbUsuario = New TextBox()
        tbContrasenia = New TextBox()
        lblcontrasenia = New Label()
        btRegistrar = New Button()
        btVolver = New Button()
        CheckBox1 = New CheckBox()
        SuspendLayout()
        ' 
        ' lblTitulo
        ' 
        lblTitulo.Font = New Font("MS Reference Sans Serif", 26.8000011F, FontStyle.Bold)
        lblTitulo.Location = New Point(16, 32)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(1238, 55)
        lblTitulo.TabIndex = 8
        lblTitulo.Text = "Iniciar Sesión (Administrador)"
        lblTitulo.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label2
        ' 
        Label2.Font = New Font("MS Reference Sans Serif", 26.8000011F, FontStyle.Bold)
        Label2.Location = New Point(16, 70)
        Label2.Name = "Label2"
        Label2.Size = New Size(1238, 55)
        Label2.TabIndex = 9
        Label2.Text = "-----------------------------------------"
        Label2.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lblInfo
        ' 
        lblInfo.Font = New Font("MS Reference Sans Serif", 10.2F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        lblInfo.Location = New Point(833, 628)
        lblInfo.Name = "lblInfo"
        lblInfo.Size = New Size(421, 36)
        lblInfo.TabIndex = 10
        lblInfo.Text = "*Solo se aceptan credenciales de un gerente"
        lblInfo.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lblUsuario
        ' 
        lblUsuario.Font = New Font("MS Reference Sans Serif", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblUsuario.Location = New Point(491, 176)
        lblUsuario.Name = "lblUsuario"
        lblUsuario.Size = New Size(245, 51)
        lblUsuario.TabIndex = 11
        lblUsuario.Text = "Usuario"
        lblUsuario.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' tbUsuario
        ' 
        tbUsuario.Font = New Font("MS Reference Sans Serif", 19.8000011F, FontStyle.Bold)
        tbUsuario.Location = New Point(415, 230)
        tbUsuario.Name = "tbUsuario"
        tbUsuario.Size = New Size(401, 48)
        tbUsuario.TabIndex = 12
        ' 
        ' tbContrasenia
        ' 
        tbContrasenia.Font = New Font("MS Reference Sans Serif", 19.8000011F, FontStyle.Bold)
        tbContrasenia.Location = New Point(415, 379)
        tbContrasenia.Name = "tbContrasenia"
        tbContrasenia.PasswordChar = "*"c
        tbContrasenia.Size = New Size(401, 48)
        tbContrasenia.TabIndex = 14
        ' 
        ' lblcontrasenia
        ' 
        lblcontrasenia.Font = New Font("MS Reference Sans Serif", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblcontrasenia.Location = New Point(491, 325)
        lblcontrasenia.Name = "lblcontrasenia"
        lblcontrasenia.Size = New Size(245, 51)
        lblcontrasenia.TabIndex = 13
        lblcontrasenia.Text = "Contraseña"
        lblcontrasenia.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' btRegistrar
        ' 
        btRegistrar.BackColor = SystemColors.ActiveCaption
        btRegistrar.Cursor = Cursors.Hand
        btRegistrar.Font = New Font("MS Reference Sans Serif", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btRegistrar.Location = New Point(457, 518)
        btRegistrar.Name = "btRegistrar"
        btRegistrar.Size = New Size(326, 93)
        btRegistrar.TabIndex = 15
        btRegistrar.Text = "Iniciar Sesión"
        btRegistrar.UseVisualStyleBackColor = False
        ' 
        ' btVolver
        ' 
        btVolver.BackColor = Color.IndianRed
        btVolver.Cursor = Cursors.Hand
        btVolver.Font = New Font("MS Reference Sans Serif", 11F)
        btVolver.Location = New Point(31, 603)
        btVolver.Name = "btVolver"
        btVolver.Size = New Size(137, 47)
        btVolver.TabIndex = 16
        btVolver.Text = "Volver"
        btVolver.UseVisualStyleBackColor = False
        ' 
        ' CheckBox1
        ' 
        CheckBox1.AutoSize = True
        CheckBox1.Font = New Font("MS Reference Sans Serif", 12F)
        CheckBox1.ForeColor = SystemColors.Desktop
        CheckBox1.Location = New Point(415, 433)
        CheckBox1.Name = "CheckBox1"
        CheckBox1.Size = New Size(233, 30)
        CheckBox1.TabIndex = 17
        CheckBox1.Text = "Mostrar Contraseña"
        CheckBox1.UseVisualStyleBackColor = True
        ' 
        ' InicioAdministrador
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1262, 673)
        Controls.Add(CheckBox1)
        Controls.Add(btVolver)
        Controls.Add(btRegistrar)
        Controls.Add(tbContrasenia)
        Controls.Add(lblcontrasenia)
        Controls.Add(tbUsuario)
        Controls.Add(lblUsuario)
        Controls.Add(lblInfo)
        Controls.Add(lblTitulo)
        Controls.Add(Label2)
        Name = "InicioAdministrador"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Inicio Administrador"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblTitulo As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblInfo As Label
    Friend WithEvents lblUsuario As Label
    Friend WithEvents tbUsuario As TextBox
    Friend WithEvents tbContrasenia As TextBox
    Friend WithEvents lblcontrasenia As Label
    Friend WithEvents btRegistrar As Button
    Friend WithEvents btVolver As Button
    Friend WithEvents CheckBox1 As CheckBox
End Class
