﻿Imports System.Data.SqlClient

Public Class InicioAdministrador

    Private Sub btRegistrar_Click(sender As Object, e As EventArgs) Handles btRegistrar.Click
        Try
            Dim query = "SELECT * FROM Empleados WHERE usuario = '" & tbUsuario.Text & "' AND contrasenia = '" & tbContrasenia.Text & "'"
            Dim adapter As New SqlDataAdapter(query, connection)
            Dim dataSet As New DataSet
            adapter.Fill(dataSet, "Empleado")

            If dataSet.Tables("Empleado").Rows.Count > 0 Then
                If dataSet.Tables("Empleado").Rows(0)("id_rol") = 1 Then
                    MessageBox.Show("Acceso aceptado", "Credenciales Aceptadas", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Dim formAdminMenu As New AdministradorMenu()
                    formAdminMenu.Show()
                    Close()
                Else
                    MessageBox.Show("El usuario no tiene acceso a la terminal", "Fallo de permisos", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                End If
            Else
                MsgBox("Usuario o contraseña incorrectos")
            End If
        Catch ex As Exception
            MsgBox("Error al obtener los empleados: " & ex.Message)
        End Try
    End Sub

    Private Sub btVolver_Click(sender As Object, e As EventArgs) Handles btVolver.Click
        Dim formMenuInicio As New PantallaInicio
        formMenuInicio.Show()
        Me.Close()
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            tbContrasenia.PasswordChar = ""
        Else
            tbContrasenia.PasswordChar = "*"
        End If
    End Sub
End Class