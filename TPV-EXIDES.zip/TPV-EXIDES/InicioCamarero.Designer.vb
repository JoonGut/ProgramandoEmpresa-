﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class InicioCamarero
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btRegistrar = New Button()
        FlowLayoutPanel = New FlowLayoutPanel()
        PanelUsuario = New Panel()
        CheckBox1 = New CheckBox()
        lblTitulo1 = New Label()
        btIniciarSesion = New Button()
        tbContraseniaIniciarSesion = New TextBox()
        Label1 = New Label()
        lblNombreIniciarSesionModal = New Label()
        lblSeparador = New Label()
        lblSeparador2 = New Label()
        btEliminarCamarero = New Button()
        btVolver3 = New Button()
        btVolver = New Button()
        tbUsuarioModal = New TextBox()
        lblNombreModal = New Label()
        lblContrasenia = New Label()
        tbContraseniaModal = New TextBox()
        btVolver2 = New Button()
        lblTitulo2 = New Label()
        Modal = New Panel()
        cbMostrarContrasenia1 = New CheckBox()
        btNuevaSesion = New Button()
        lblTitulo3 = New Label()
        lblTitulo = New Label()
        Label2 = New Label()
        PanelUsuario.SuspendLayout()
        Modal.SuspendLayout()
        SuspendLayout()
        ' 
        ' btRegistrar
        ' 
        btRegistrar.BackColor = SystemColors.ActiveCaption
        btRegistrar.Cursor = Cursors.Hand
        btRegistrar.Font = New Font("MS Reference Sans Serif", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btRegistrar.Location = New Point(405, 494)
        btRegistrar.Name = "btRegistrar"
        btRegistrar.Size = New Size(412, 153)
        btRegistrar.TabIndex = 1
        btRegistrar.Text = "Nueva Sesión"
        btRegistrar.UseVisualStyleBackColor = False
        ' 
        ' FlowLayoutPanel
        ' 
        FlowLayoutPanel.Font = New Font("Segoe UI", 15F)
        FlowLayoutPanel.Location = New Point(30, 184)
        FlowLayoutPanel.Name = "FlowLayoutPanel"
        FlowLayoutPanel.Size = New Size(1198, 263)
        FlowLayoutPanel.TabIndex = 2
        ' 
        ' PanelUsuario
        ' 
        PanelUsuario.BackColor = SystemColors.ScrollBar
        PanelUsuario.Controls.Add(CheckBox1)
        PanelUsuario.Controls.Add(lblTitulo1)
        PanelUsuario.Controls.Add(btIniciarSesion)
        PanelUsuario.Controls.Add(tbContraseniaIniciarSesion)
        PanelUsuario.Controls.Add(Label1)
        PanelUsuario.Controls.Add(lblNombreIniciarSesionModal)
        PanelUsuario.Controls.Add(lblSeparador)
        PanelUsuario.Controls.Add(lblSeparador2)
        PanelUsuario.Controls.Add(btEliminarCamarero)
        PanelUsuario.Controls.Add(btVolver3)
        PanelUsuario.Location = New Point(300, 109)
        PanelUsuario.Name = "PanelUsuario"
        PanelUsuario.Size = New Size(646, 496)
        PanelUsuario.TabIndex = 3
        PanelUsuario.Visible = False
        ' 
        ' CheckBox1
        ' 
        CheckBox1.AutoSize = True
        CheckBox1.Font = New Font("MS Reference Sans Serif", 12F)
        CheckBox1.ForeColor = SystemColors.Desktop
        CheckBox1.Location = New Point(142, 310)
        CheckBox1.Name = "CheckBox1"
        CheckBox1.Size = New Size(233, 30)
        CheckBox1.TabIndex = 9
        CheckBox1.Text = "Mostrar Contraseña"
        CheckBox1.UseVisualStyleBackColor = True
        ' 
        ' lblTitulo1
        ' 
        lblTitulo1.AutoSize = True
        lblTitulo1.Font = New Font("MS Reference Sans Serif", 25.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitulo1.ForeColor = Color.DarkOliveGreen
        lblTitulo1.Location = New Point(151, 39)
        lblTitulo1.Name = "lblTitulo1"
        lblTitulo1.Size = New Size(325, 52)
        lblTitulo1.TabIndex = 8
        lblTitulo1.Text = "Iniciar Sesión"
        ' 
        ' btIniciarSesion
        ' 
        btIniciarSesion.BackColor = Color.FromArgb(CByte(192), CByte(255), CByte(192))
        btIniciarSesion.Cursor = Cursors.Hand
        btIniciarSesion.Font = New Font("MS Reference Sans Serif", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btIniciarSesion.Location = New Point(206, 380)
        btIniciarSesion.Name = "btIniciarSesion"
        btIniciarSesion.Size = New Size(246, 96)
        btIniciarSesion.TabIndex = 7
        btIniciarSesion.Text = "Acceder"
        btIniciarSesion.UseVisualStyleBackColor = False
        ' 
        ' tbContraseniaIniciarSesion
        ' 
        tbContraseniaIniciarSesion.Font = New Font("Segoe UI", 15F)
        tbContraseniaIniciarSesion.Location = New Point(142, 261)
        tbContraseniaIniciarSesion.Name = "tbContraseniaIniciarSesion"
        tbContraseniaIniciarSesion.PasswordChar = "*"c
        tbContraseniaIniciarSesion.Size = New Size(320, 41)
        tbContraseniaIniciarSesion.TabIndex = 6
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("MS Reference Sans Serif", 15F)
        Label1.ForeColor = SystemColors.Desktop
        Label1.Location = New Point(142, 228)
        Label1.Name = "Label1"
        Label1.Size = New Size(157, 32)
        Label1.TabIndex = 5
        Label1.Text = "Contraseña"
        ' 
        ' lblNombreIniciarSesionModal
        ' 
        lblNombreIniciarSesionModal.AutoSize = True
        lblNombreIniciarSesionModal.Font = New Font("MS Reference Sans Serif", 22F)
        lblNombreIniciarSesionModal.Location = New Point(218, 130)
        lblNombreIniciarSesionModal.Name = "lblNombreIniciarSesionModal"
        lblNombreIniciarSesionModal.Size = New Size(0, 46)
        lblNombreIniciarSesionModal.TabIndex = 1
        ' 
        ' lblSeparador
        ' 
        lblSeparador.AutoSize = True
        lblSeparador.Font = New Font("Segoe UI", 28F)
        lblSeparador.Location = New Point(174, 116)
        lblSeparador.Name = "lblSeparador"
        lblSeparador.Size = New Size(38, 62)
        lblSeparador.TabIndex = 2
        lblSeparador.Text = "l"
        ' 
        ' lblSeparador2
        ' 
        lblSeparador2.AutoSize = True
        lblSeparador2.Font = New Font("Segoe UI", 20F)
        lblSeparador2.Location = New Point(174, 146)
        lblSeparador2.Name = "lblSeparador2"
        lblSeparador2.Size = New Size(244, 46)
        lblSeparador2.TabIndex = 4
        lblSeparador2.Text = "________________"
        ' 
        ' btEliminarCamarero
        ' 
        btEliminarCamarero.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(128))
        btEliminarCamarero.Cursor = Cursors.Hand
        btEliminarCamarero.Font = New Font("MS Reference Sans Serif", 12F)
        btEliminarCamarero.Location = New Point(19, 433)
        btEliminarCamarero.Name = "btEliminarCamarero"
        btEliminarCamarero.Size = New Size(117, 43)
        btEliminarCamarero.TabIndex = 3
        btEliminarCamarero.Text = "Eliminar"
        btEliminarCamarero.UseVisualStyleBackColor = False
        ' 
        ' btVolver3
        ' 
        btVolver3.BackColor = Color.DarkRed
        btVolver3.ForeColor = SystemColors.ButtonHighlight
        btVolver3.Location = New Point(19, 17)
        btVolver3.Name = "btVolver3"
        btVolver3.Size = New Size(30, 29)
        btVolver3.TabIndex = 0
        btVolver3.Text = "X"
        btVolver3.UseVisualStyleBackColor = False
        ' 
        ' btVolver
        ' 
        btVolver.BackColor = Color.IndianRed
        btVolver.Cursor = Cursors.Hand
        btVolver.Font = New Font("MS Reference Sans Serif", 11F)
        btVolver.Location = New Point(54, 577)
        btVolver.Name = "btVolver"
        btVolver.Size = New Size(137, 47)
        btVolver.TabIndex = 4
        btVolver.Text = "Volver"
        btVolver.UseVisualStyleBackColor = False
        ' 
        ' tbUsuarioModal
        ' 
        tbUsuarioModal.Font = New Font("MS Reference Sans Serif", 15F)
        tbUsuarioModal.Location = New Point(144, 170)
        tbUsuarioModal.Name = "tbUsuarioModal"
        tbUsuarioModal.Size = New Size(271, 38)
        tbUsuarioModal.TabIndex = 0
        ' 
        ' lblNombreModal
        ' 
        lblNombreModal.AutoSize = True
        lblNombreModal.Font = New Font("MS Reference Sans Serif", 15F)
        lblNombreModal.ForeColor = SystemColors.ButtonHighlight
        lblNombreModal.Location = New Point(143, 132)
        lblNombreModal.Name = "lblNombreModal"
        lblNombreModal.Size = New Size(108, 32)
        lblNombreModal.TabIndex = 1
        lblNombreModal.Text = "Usuario"
        ' 
        ' lblContrasenia
        ' 
        lblContrasenia.AutoSize = True
        lblContrasenia.Font = New Font("MS Reference Sans Serif", 15F)
        lblContrasenia.ForeColor = SystemColors.ButtonHighlight
        lblContrasenia.Location = New Point(144, 227)
        lblContrasenia.Name = "lblContrasenia"
        lblContrasenia.Size = New Size(157, 32)
        lblContrasenia.TabIndex = 2
        lblContrasenia.Text = "Contraseña"
        ' 
        ' tbContraseniaModal
        ' 
        tbContraseniaModal.Font = New Font("MS Reference Sans Serif", 15F)
        tbContraseniaModal.Location = New Point(148, 269)
        tbContraseniaModal.Name = "tbContraseniaModal"
        tbContraseniaModal.PasswordChar = "*"c
        tbContraseniaModal.Size = New Size(271, 38)
        tbContraseniaModal.TabIndex = 3
        ' 
        ' btVolver2
        ' 
        btVolver2.BackColor = Color.DarkRed
        btVolver2.ForeColor = SystemColors.ButtonHighlight
        btVolver2.Location = New Point(12, 13)
        btVolver2.Name = "btVolver2"
        btVolver2.Size = New Size(30, 29)
        btVolver2.TabIndex = 1
        btVolver2.Text = "X"
        btVolver2.UseVisualStyleBackColor = False
        ' 
        ' lblTitulo2
        ' 
        lblTitulo2.AutoSize = True
        lblTitulo2.Font = New Font("MS Reference Sans Serif", 25.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitulo2.ForeColor = SystemColors.ActiveCaption
        lblTitulo2.Location = New Point(126, 45)
        lblTitulo2.Name = "lblTitulo2"
        lblTitulo2.Size = New Size(322, 52)
        lblTitulo2.TabIndex = 4
        lblTitulo2.Text = "Nueva Sesión"
        ' 
        ' Modal
        ' 
        Modal.BackColor = SystemColors.WindowFrame
        Modal.Controls.Add(cbMostrarContrasenia1)
        Modal.Controls.Add(btNuevaSesion)
        Modal.Controls.Add(lblTitulo2)
        Modal.Controls.Add(btVolver2)
        Modal.Controls.Add(tbContraseniaModal)
        Modal.Controls.Add(lblContrasenia)
        Modal.Controls.Add(lblNombreModal)
        Modal.Controls.Add(tbUsuarioModal)
        Modal.Location = New Point(339, 103)
        Modal.Name = "Modal"
        Modal.Size = New Size(563, 482)
        Modal.TabIndex = 0
        Modal.Visible = False
        ' 
        ' cbMostrarContrasenia1
        ' 
        cbMostrarContrasenia1.AutoSize = True
        cbMostrarContrasenia1.Font = New Font("MS Reference Sans Serif", 12F)
        cbMostrarContrasenia1.ForeColor = SystemColors.ButtonHighlight
        cbMostrarContrasenia1.Location = New Point(148, 314)
        cbMostrarContrasenia1.Name = "cbMostrarContrasenia1"
        cbMostrarContrasenia1.Size = New Size(233, 30)
        cbMostrarContrasenia1.TabIndex = 6
        cbMostrarContrasenia1.Text = "Mostrar Contraseña"
        cbMostrarContrasenia1.UseVisualStyleBackColor = True
        ' 
        ' btNuevaSesion
        ' 
        btNuevaSesion.Cursor = Cursors.Hand
        btNuevaSesion.Font = New Font("MS Reference Sans Serif", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btNuevaSesion.Location = New Point(167, 370)
        btNuevaSesion.Name = "btNuevaSesion"
        btNuevaSesion.Size = New Size(235, 85)
        btNuevaSesion.TabIndex = 5
        btNuevaSesion.Text = "Acceder"
        btNuevaSesion.UseVisualStyleBackColor = True
        ' 
        ' lblTitulo3
        ' 
        lblTitulo3.AutoSize = True
        lblTitulo3.Font = New Font("MS Reference Sans Serif", 21.8000011F, FontStyle.Bold)
        lblTitulo3.Location = New Point(30, 135)
        lblTitulo3.Name = "lblTitulo3"
        lblTitulo3.Size = New Size(364, 46)
        lblTitulo3.TabIndex = 5
        lblTitulo3.Text = "Accesos Directos:"
        ' 
        ' lblTitulo
        ' 
        lblTitulo.Font = New Font("MS Reference Sans Serif", 26.8000011F, FontStyle.Bold)
        lblTitulo.Location = New Point(12, 22)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(1238, 55)
        lblTitulo.TabIndex = 6
        lblTitulo.Text = "Iniciar Sesión (Camarero)"
        lblTitulo.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label2
        ' 
        Label2.Font = New Font("MS Reference Sans Serif", 26.8000011F, FontStyle.Bold)
        Label2.Location = New Point(12, 62)
        Label2.Name = "Label2"
        Label2.Size = New Size(1238, 55)
        Label2.TabIndex = 7
        Label2.Text = "-----------------------------------------"
        Label2.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' InicioCamarero
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1262, 673)
        Controls.Add(Modal)
        Controls.Add(PanelUsuario)
        Controls.Add(btVolver)
        Controls.Add(FlowLayoutPanel)
        Controls.Add(btRegistrar)
        Controls.Add(lblTitulo3)
        Controls.Add(lblTitulo)
        Controls.Add(Label2)
        Name = "InicioCamarero"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Inicio Camarero"
        PanelUsuario.ResumeLayout(False)
        PanelUsuario.PerformLayout()
        Modal.ResumeLayout(False)
        Modal.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents btRegistrar As Button
    Friend WithEvents FlowLayoutPanel As FlowLayoutPanel
    Friend WithEvents PanelUsuario As Panel
    Friend WithEvents btVolver3 As Button
    Friend WithEvents btEliminarCamarero As Button
    Friend WithEvents lblSeparador As Label
    Friend WithEvents lblNombreIniciarSesionModal As Label
    Friend WithEvents lblSeparador2 As Label
    Friend WithEvents btIniciarSesion As Button
    Friend WithEvents tbContraseniaIniciarSesion As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btVolver As Button
    Friend WithEvents lblTitulo1 As Label
    Friend WithEvents tbUsuarioModal As TextBox
    Friend WithEvents lblNombreModal As Label
    Friend WithEvents lblContrasenia As Label
    Friend WithEvents tbContraseniaModal As TextBox
    Friend WithEvents btVolver2 As Button
    Friend WithEvents lblTitulo2 As Label
    Friend WithEvents Modal As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents btNuevaSesion As Button
    Friend WithEvents lblTitulo3 As Label
    Friend WithEvents cbMostrarContrasenia1 As CheckBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents lblTitulo As Label
    Friend WithEvents Label2 As Label
End Class
