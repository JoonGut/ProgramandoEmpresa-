﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar

Public Class InicioCamarero
    Private usuariosRegistrados As New List(Of String)
    Private botonSeleccionado As Button

    Private Sub InicioCamarero_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CargarUsuarios()
    End Sub

    Private Sub btRegistrar_Click(sender As Object, e As EventArgs) Handles btRegistrar.Click
        tbContraseniaModal.Text = ""
        tbUsuarioModal.Text = ""
        Modal.Visible = True
        btRegistrar.Enabled = False
    End Sub

    Private Sub btFinalizar_Click(sender As Object, e As EventArgs) Handles Button1.Click, btNuevaSesion.Click
        Try
            Dim query = "SELECT * FROM Empleados WHERE usuario = '" & tbUsuarioModal.Text & "' AND contrasenia = '" & tbContraseniaModal.Text & "'"
            Dim adapter As New SqlDataAdapter(query, connection)
            Dim dataSet As New DataSet

            adapter.Fill(dataSet, "Empleado")
            If dataSet.Tables("Empleado").Rows.Count > 0 Then
                Dim idRol = Convert.ToInt32(dataSet.Tables("Empleado").Rows(0)("id_rol"))

                If dataSet.Tables("Empleado").Rows(0)("id_rol") = 1 Or dataSet.Tables("Empleado").Rows(0)("id_rol") = 2 Then
                    ComprobacionBotonUsuario(dataSet.Tables("Empleado").Rows(0)("nombre"))
                    MessageBox.Show("Acceso aceptado", "Credenciales Aceptadas", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Dim formCamareroMenu As New CamareroMenu(dataSet.Tables("Empleado").Rows(0)("nombre"))
                    formCamareroMenu.Show()
                    Me.Close()
                Else
                    MessageBox.Show("El usuario no tiene acceso a la terminal", "Fallo de permisos", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                End If
            Else
                MsgBox("Usuario o contraseña incorrectos")
            End If
        Catch ex As Exception
            MsgBox("Error al obtener los empleados: " & ex.Message)
        End Try
    End Sub

    Private Sub ComprobacionBotonUsuario(usuario As String)
        If usuariosRegistrados.Count < 4 Then
            Dim nuevoUsuario As String = tbUsuarioModal.Text
            If Not usuariosRegistrados.Contains(nuevoUsuario) Then
                usuariosRegistrados.Add(nuevoUsuario)
                CrearBotonUsuario(nuevoUsuario)
                GuardarUsuarios()
                tbUsuarioModal.Text = ""
                tbContraseniaModal.Text = ""
            Else
                MessageBox.Show("El usuario ya tiene un acceso directo.", "Acceso Directo", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Else
            MessageBox.Show("Se ha alcanzado el número máximo de accesos directos (4).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
        Modal.Visible = False
        btRegistrar.Enabled = True
    End Sub

    Private Sub CrearBotonUsuario(usuario As String)
        Dim btnUsuario As New Button()
        btnUsuario.Text = usuario
        btnUsuario.Width = 293
        btnUsuario.Height = 160
        btnUsuario.Cursor = Cursors.Hand
        btnUsuario.Font = New Font("MS Reference Sans Serif", 22)
        AddHandler btnUsuario.Click, AddressOf btUsuario_Click
        FlowLayoutPanel.Controls.Add(btnUsuario)
    End Sub

    Private Sub btUsuario_Click(sender As Object, e As EventArgs)
        Dim btnUsuario As Button = CType(sender, Button)
        botonSeleccionado = btnUsuario
        tbContraseniaIniciarSesion.Text = ""
        PanelUsuario.Visible = True
        btRegistrar.Enabled = False
        lblNombreIniciarSesionModal.Text = btnUsuario.Text
    End Sub

    Private Sub GuardarUsuarios()
        File.WriteAllLines("usuarios.txt", usuariosRegistrados)
    End Sub

    Private Sub CargarUsuarios()
        If File.Exists("usuarios.txt") Then
            usuariosRegistrados = File.ReadAllLines("usuarios.txt").ToList()
            For Each usuario As String In usuariosRegistrados
                CrearBotonUsuario(usuario)
            Next
        End If
    End Sub

    Private Sub btVolver_Click(sender As Object, e As EventArgs) Handles btVolver.Click
        Dim formMain As New PantallaInicio()
        formMain.Show()
        Me.Close()
    End Sub

    Private Sub btVolver3_Click(sender As Object, e As EventArgs) Handles btVolver3.Click, btVolver2.Click
        PanelUsuario.Visible = False
        Modal.Visible = False
        btRegistrar.Enabled = True
        tbUsuarioModal.Text = ""
        tbContraseniaModal.Text = ""
        tbContraseniaIniciarSesion.Text = ""
    End Sub

    Private Sub btEliminarCamarero_Click(sender As Object, e As EventArgs) Handles btEliminarCamarero.Click
        Dim res = MessageBox.Show("¿Quieres eliminar el acceso directo?", "Advertencia", MessageBoxButtons.OKCancel)
        If res = DialogResult.OK Then
            If botonSeleccionado IsNot Nothing Then
                FlowLayoutPanel.Controls.Remove(botonSeleccionado)
                Dim usuarioAEliminar As String = botonSeleccionado.Text
                usuariosRegistrados.Remove(usuarioAEliminar)
                GuardarUsuarios()
                PanelUsuario.Visible = False
                botonSeleccionado = Nothing
                MessageBox.Show("Acceso directo con éxito.", "Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("No se ha seleccionado ningún usuario.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
            btRegistrar.Enabled = True
        End If
    End Sub

    Private Sub btIniciarSesion_Click(sender As Object, e As EventArgs) Handles btIniciarSesion.Click
        Try
            Dim query = "SELECT * FROM Empleados WHERE usuario = '" & botonSeleccionado.Text & "' AND contrasenia = '" & tbContraseniaIniciarSesion.Text & "'"
            Dim adapter As New SqlDataAdapter(query, connection)
            Dim dataSet As New DataSet
            adapter.Fill(dataSet, "Empleado")

            If dataSet.Tables("Empleado").Rows.Count > 0 Then
                Dim idRol = Convert.ToInt32(dataSet.Tables("Empleado").Rows(0)("id_rol"))

                If dataSet.Tables("Empleado").Rows(0)("id_rol") = 1 Or dataSet.Tables("Empleado").Rows(0)("id_rol") = 2 Then
                    MessageBox.Show("Acceso aceptado", "Credenciales Aceptadas", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Dim formCamareroMenu As New CamareroMenu(dataSet.Tables("Empleado").Rows(0)("nombre"))
                    formCamareroMenu.Show()
                    Close()
                Else
                    MessageBox.Show("Algo no salió bien", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            Else
                MsgBox("Contraseña incorrecta")
            End If
        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try
    End Sub

    'copiado
    'Private Sub btIniciarSesion_Click(sender As Object, e As EventArgs) Handles btIniciarSesion.Click
    '    Try
    '        ' Construir la consulta con parámetros
    '        Dim query = "SELECT * FROM Empleados WHERE usuario = @usuario AND contrasenia = @contrasenia"
    '        Dim adapter As New SqlDataAdapter(query, connection)
    '        adapter.SelectCommand.Parameters.AddWithValue("@usuario", botonSeleccionado.Text)
    '        adapter.SelectCommand.Parameters.AddWithValue("@contrasenia", tbContraseniaIniciarSesion.Text)
    '        MsgBox("query: " + query)

    '        ' Cargar los datos en un DataSet
    '        Dim dataSet As New DataSet
    '        adapter.Fill(dataSet, "Empleado")

    '        ' Verificar si se encontró un empleado
    '        If dataSet.Tables("Empleado").Rows.Count > 0 Then
    '            ' Obtener el rol del empleado
    '            Dim idRol As Integer = Convert.ToInt32(dataSet.Tables("Empleado").Rows(0)("id_rol"))

    '            ' Verificar si el rol es 1 o 2
    '            If idRol = 1 Or idRol = 2 Then
    '                MessageBox.Show("Acceso aceptado", "Credenciales Aceptadas", MessageBoxButtons.OK, MessageBoxIcon.Information)
    '                Dim formCamareroMenu As New CamareroMenu(dataSet.Tables("Empleado").Rows(0)("nombre"))
    '                formCamareroMenu.Show()
    '                Close()
    '            Else
    '                MessageBox.Show("Algo no salió bien", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '            End If
    '        Else
    '            MsgBox("Contraseña incorrecta")
    '        End If
    '    Catch ex As Exception
    '        MsgBox("Error: " & ex.Message & vbCrLf & "Stack Trace: " & ex.StackTrace)
    '    End Try
    'End Sub

    Private Sub cbMostrarContrasenia1_CheckedChanged(sender As Object, e As EventArgs) Handles cbMostrarContrasenia1.CheckedChanged
        If cbMostrarContrasenia1.Checked Then
            tbContraseniaModal.PasswordChar = ""
        Else
            tbContraseniaModal.PasswordChar = "*"
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If cbMostrarContrasenia1.Checked Then
            tbContraseniaIniciarSesion.PasswordChar = ""
        Else
            tbContraseniaIniciarSesion.PasswordChar = "*"
        End If
    End Sub
End Class