﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ModificarArticulo
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        PanelModificar = New Panel()
        ComboFamilia = New ComboBox()
        PictureArticulo = New PictureBox()
        lblFamilia = New Label()
        lblSeparacion = New Label()
        NumericIVA = New NumericUpDown()
        tbURL = New TextBox()
        NumericStock = New NumericUpDown()
        NumericPrecio = New NumericUpDown()
        lblURL = New Label()
        lblIVA = New Label()
        lblTituloModa = New Label()
        lblStock = New Label()
        btGuardar = New Button()
        lblUsuario = New Label()
        btVolver2 = New Button()
        tbNombre = New TextBox()
        lblNombre = New Label()
        lblTitulo = New Label()
        btVolver = New Button()
        DataGridView = New DataGridView()
        PanelModificar.SuspendLayout()
        CType(PictureArticulo, ComponentModel.ISupportInitialize).BeginInit()
        CType(NumericIVA, ComponentModel.ISupportInitialize).BeginInit()
        CType(NumericStock, ComponentModel.ISupportInitialize).BeginInit()
        CType(NumericPrecio, ComponentModel.ISupportInitialize).BeginInit()
        CType(DataGridView, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PanelModificar
        ' 
        PanelModificar.BackColor = SystemColors.ActiveBorder
        PanelModificar.Controls.Add(ComboFamilia)
        PanelModificar.Controls.Add(PictureArticulo)
        PanelModificar.Controls.Add(lblFamilia)
        PanelModificar.Controls.Add(lblSeparacion)
        PanelModificar.Controls.Add(NumericIVA)
        PanelModificar.Controls.Add(tbURL)
        PanelModificar.Controls.Add(NumericStock)
        PanelModificar.Controls.Add(NumericPrecio)
        PanelModificar.Controls.Add(lblURL)
        PanelModificar.Controls.Add(lblIVA)
        PanelModificar.Controls.Add(lblTituloModa)
        PanelModificar.Controls.Add(lblStock)
        PanelModificar.Controls.Add(btGuardar)
        PanelModificar.Controls.Add(lblUsuario)
        PanelModificar.Controls.Add(btVolver2)
        PanelModificar.Controls.Add(tbNombre)
        PanelModificar.Controls.Add(lblNombre)
        PanelModificar.Location = New Point(150, 34)
        PanelModificar.Name = "PanelModificar"
        PanelModificar.Size = New Size(985, 593)
        PanelModificar.TabIndex = 11
        PanelModificar.Visible = False
        ' 
        ' ComboFamilia
        ' 
        ComboFamilia.Font = New Font("MS Reference Sans Serif", 15F)
        ComboFamilia.FormattingEnabled = True
        ComboFamilia.Items.AddRange(New Object() {"Cafes", "Tes", "Refrescos", "Pintxos"})
        ComboFamilia.Location = New Point(259, 421)
        ComboFamilia.Name = "ComboFamilia"
        ComboFamilia.Size = New Size(274, 40)
        ComboFamilia.TabIndex = 46
        ' 
        ' PictureArticulo
        ' 
        PictureArticulo.Location = New Point(614, 138)
        PictureArticulo.Name = "PictureArticulo"
        PictureArticulo.Size = New Size(348, 213)
        PictureArticulo.TabIndex = 49
        PictureArticulo.TabStop = False
        ' 
        ' lblFamilia
        ' 
        lblFamilia.AutoSize = True
        lblFamilia.BackColor = SystemColors.ActiveBorder
        lblFamilia.Font = New Font("MS Reference Sans Serif", 15F)
        lblFamilia.Location = New Point(138, 424)
        lblFamilia.Name = "lblFamilia"
        lblFamilia.Size = New Size(100, 32)
        lblFamilia.TabIndex = 45
        lblFamilia.Text = "Familia"
        ' 
        ' lblSeparacion
        ' 
        lblSeparacion.AutoSize = True
        lblSeparacion.Font = New Font("MS Reference Sans Serif", 14.8000011F, FontStyle.Bold)
        lblSeparacion.Location = New Point(200, 85)
        lblSeparacion.Name = "lblSeparacion"
        lblSeparacion.Size = New Size(578, 32)
        lblSeparacion.TabIndex = 25
        lblSeparacion.Text = "-----------------------------------------------"
        ' 
        ' NumericIVA
        ' 
        NumericIVA.Font = New Font("MS Reference Sans Serif", 15F)
        NumericIVA.Location = New Point(259, 352)
        NumericIVA.Maximum = New Decimal(New Integer() {21, 0, 0, 0})
        NumericIVA.Name = "NumericIVA"
        NumericIVA.Size = New Size(274, 38)
        NumericIVA.TabIndex = 44
        ' 
        ' tbURL
        ' 
        tbURL.Font = New Font("MS Reference Sans Serif", 15F)
        tbURL.Location = New Point(614, 421)
        tbURL.Name = "tbURL"
        tbURL.Size = New Size(348, 38)
        tbURL.TabIndex = 48
        ' 
        ' NumericStock
        ' 
        NumericStock.Font = New Font("MS Reference Sans Serif", 15F)
        NumericStock.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        NumericStock.Location = New Point(259, 284)
        NumericStock.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        NumericStock.Name = "NumericStock"
        NumericStock.Size = New Size(274, 38)
        NumericStock.TabIndex = 43
        ' 
        ' NumericPrecio
        ' 
        NumericPrecio.DecimalPlaces = 2
        NumericPrecio.Font = New Font("MS Reference Sans Serif", 15F)
        NumericPrecio.Increment = New Decimal(New Integer() {5, 0, 0, 65536})
        NumericPrecio.Location = New Point(259, 217)
        NumericPrecio.Name = "NumericPrecio"
        NumericPrecio.Size = New Size(274, 38)
        NumericPrecio.TabIndex = 42
        ' 
        ' lblURL
        ' 
        lblURL.AutoSize = True
        lblURL.Font = New Font("MS Reference Sans Serif", 15F)
        lblURL.Location = New Point(697, 386)
        lblURL.Name = "lblURL"
        lblURL.Size = New Size(168, 32)
        lblURL.TabIndex = 47
        lblURL.Text = "URL Imagen"
        ' 
        ' lblIVA
        ' 
        lblIVA.AutoSize = True
        lblIVA.BackColor = SystemColors.ActiveBorder
        lblIVA.Font = New Font("MS Reference Sans Serif", 15F)
        lblIVA.Location = New Point(138, 354)
        lblIVA.Name = "lblIVA"
        lblIVA.Size = New Size(94, 32)
        lblIVA.TabIndex = 41
        lblIVA.Text = "% IVA"
        ' 
        ' lblTituloModa
        ' 
        lblTituloModa.AutoSize = True
        lblTituloModa.Font = New Font("MS Reference Sans Serif", 21F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTituloModa.Location = New Point(323, 41)
        lblTituloModa.Name = "lblTituloModa"
        lblTituloModa.Size = New Size(338, 44)
        lblTituloModa.TabIndex = 24
        lblTituloModa.Text = "Modificar Articulo"
        ' 
        ' lblStock
        ' 
        lblStock.AutoSize = True
        lblStock.BackColor = SystemColors.ActiveBorder
        lblStock.Font = New Font("MS Reference Sans Serif", 15F)
        lblStock.Location = New Point(148, 286)
        lblStock.Name = "lblStock"
        lblStock.Size = New Size(84, 32)
        lblStock.TabIndex = 40
        lblStock.Text = "Stock"
        ' 
        ' btGuardar
        ' 
        btGuardar.BackColor = SystemColors.ActiveCaption
        btGuardar.Cursor = Cursors.Hand
        btGuardar.Font = New Font("MS Reference Sans Serif", 11F)
        btGuardar.Location = New Point(355, 507)
        btGuardar.Name = "btGuardar"
        btGuardar.Size = New Size(245, 67)
        btGuardar.TabIndex = 8
        btGuardar.Text = "Guardar Cambios"
        btGuardar.UseVisualStyleBackColor = False
        ' 
        ' lblUsuario
        ' 
        lblUsuario.AutoSize = True
        lblUsuario.BackColor = SystemColors.ActiveBorder
        lblUsuario.Font = New Font("MS Reference Sans Serif", 15F)
        lblUsuario.Location = New Point(143, 219)
        lblUsuario.Name = "lblUsuario"
        lblUsuario.Size = New Size(89, 32)
        lblUsuario.TabIndex = 39
        lblUsuario.Text = "Precio"
        ' 
        ' btVolver2
        ' 
        btVolver2.BackColor = Color.DarkRed
        btVolver2.Cursor = Cursors.Hand
        btVolver2.ForeColor = SystemColors.ButtonHighlight
        btVolver2.Location = New Point(22, 20)
        btVolver2.Name = "btVolver2"
        btVolver2.Size = New Size(30, 29)
        btVolver2.TabIndex = 23
        btVolver2.Text = "X"
        btVolver2.UseVisualStyleBackColor = False
        ' 
        ' tbNombre
        ' 
        tbNombre.Font = New Font("MS Reference Sans Serif", 15F)
        tbNombre.Location = New Point(259, 151)
        tbNombre.Name = "tbNombre"
        tbNombre.Size = New Size(270, 38)
        tbNombre.TabIndex = 38
        ' 
        ' lblNombre
        ' 
        lblNombre.AutoSize = True
        lblNombre.BackColor = SystemColors.ActiveBorder
        lblNombre.Font = New Font("MS Reference Sans Serif", 15F)
        lblNombre.Location = New Point(15, 154)
        lblNombre.Name = "lblNombre"
        lblNombre.Size = New Size(217, 32)
        lblNombre.TabIndex = 37
        lblNombre.Text = "Nombre Articulo"
        ' 
        ' lblTitulo
        ' 
        lblTitulo.AutoSize = True
        lblTitulo.Font = New Font("MS Reference Sans Serif", 25.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitulo.ForeColor = SystemColors.Desktop
        lblTitulo.Location = New Point(526, 34)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(224, 55)
        lblTitulo.TabIndex = 10
        lblTitulo.Text = "Articulos"
        ' 
        ' btVolver
        ' 
        btVolver.BackColor = Color.IndianRed
        btVolver.Cursor = Cursors.Hand
        btVolver.Font = New Font("MS Reference Sans Serif", 11F)
        btVolver.Location = New Point(66, 594)
        btVolver.Name = "btVolver"
        btVolver.Size = New Size(137, 47)
        btVolver.TabIndex = 9
        btVolver.Text = "Volver"
        btVolver.UseVisualStyleBackColor = False
        ' 
        ' DataGridView
        ' 
        DataGridView.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        DataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        DataGridView.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells
        DataGridView.BackgroundColor = SystemColors.ButtonFace
        DataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView.Cursor = Cursors.Hand
        DataGridView.Location = New Point(150, 104)
        DataGridView.Name = "DataGridView"
        DataGridView.RowHeadersVisible = False
        DataGridView.RowHeadersWidth = 51
        DataGridView.Size = New Size(985, 455)
        DataGridView.TabIndex = 8
        ' 
        ' ModificarArticulo
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1262, 673)
        Controls.Add(PanelModificar)
        Controls.Add(lblTitulo)
        Controls.Add(btVolver)
        Controls.Add(DataGridView)
        Name = "ModificarArticulo"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Modificar Articulo"
        PanelModificar.ResumeLayout(False)
        PanelModificar.PerformLayout()
        CType(PictureArticulo, ComponentModel.ISupportInitialize).EndInit()
        CType(NumericIVA, ComponentModel.ISupportInitialize).EndInit()
        CType(NumericStock, ComponentModel.ISupportInitialize).EndInit()
        CType(NumericPrecio, ComponentModel.ISupportInitialize).EndInit()
        CType(DataGridView, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PanelModificar As Panel
    Friend WithEvents lblSeparacion As Label
    Friend WithEvents lblTituloModa As Label
    Friend WithEvents btGuardar As Button
    Friend WithEvents btVolver2 As Button
    Friend WithEvents lblTitulo As Label
    Friend WithEvents btVolver As Button
    Friend WithEvents DataGridView As DataGridView
    Friend WithEvents PictureArticulo As PictureBox
    Friend WithEvents tbURL As TextBox
    Friend WithEvents lblURL As Label
    Friend WithEvents ComboFamilia As ComboBox
    Friend WithEvents lblFamilia As Label
    Friend WithEvents NumericIVA As NumericUpDown
    Friend WithEvents NumericStock As NumericUpDown
    Friend WithEvents NumericPrecio As NumericUpDown
    Friend WithEvents lblIVA As Label
    Friend WithEvents lblStock As Label
    Friend WithEvents lblUsuario As Label
    Friend WithEvents tbNombre As TextBox
    Friend WithEvents lblNombre As Label
End Class
