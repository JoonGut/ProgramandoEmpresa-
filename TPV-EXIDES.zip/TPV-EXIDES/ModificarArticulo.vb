﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class ModificarArticulo
    Dim nombre As String
    Dim precio As Double
    Dim stock As Integer
    Dim iva As Integer
    Dim idFamilia As Integer
    Dim url As String

    Dim stockAnterior As Integer
    Dim idSeleccionado As Integer
    Dim nuevoNombre As String
    Dim nuevoPrecio As Double
    Dim nuevoStock As Integer
    Dim nuevoIVA As Integer
    Dim nuevaFamilia As String
    Dim nuevoIdFamilia As Integer
    Dim nuevaURL As String

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView.CellContentClick
        If e.ColumnIndex = DataGridView.Columns("Eliminar").Index Then
            eliminarArticulo(e)
        ElseIf e.ColumnIndex = DataGridView.Columns("Modificar").Index Then
            mostrarModal(e)
        End If
    End Sub

    Private Sub eliminarArticulo(Data As DataGridViewCellEventArgs)
        Dim diag As DialogResult = MessageBox.Show("Estas seguro que quieres borrar a este Articulo?", "Advertencia", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning)
        If diag = DialogResult.Yes Then
            Dim query As String = "DELETE FROM Articulos WHERE id_articulo = " & DataGridView.Rows(Data.RowIndex).Cells("ID").Value
            Dim command As New SqlClient.SqlCommand(query, connection)
            Try
                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If
                command.ExecuteNonQuery()
                connection.Close()
                MessageBox.Show("Articulo borrado correctamente", "Articulo eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Catch ex As Exception
                MessageBox.Show("El Articulo no se ha podido eliminar: " & ex.Message, "No se ha podido eliminar", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            GetArticulos()
        End If
    End Sub

    Private Sub mostrarModal(Data As DataGridViewCellEventArgs)
        Try
            ComboFamilia.Items.Clear()

            Dim query As String = "SELECT nombre_familia FROM Familias"
            Dim command As New SqlClient.SqlCommand(query, connection)

            If connection.State = ConnectionState.Closed Then
                connection.Open()
            End If

            Using reader As SqlClient.SqlDataReader = command.ExecuteReader()
                While reader.Read()
                    ComboFamilia.Items.Add(reader("nombre_familia").ToString())
                End While
            End Using

            connection.Close()

            PanelModificar.Visible = True
            idSeleccionado = DataGridView.Rows(Data.RowIndex).Cells("ID").Value
            tbNombre.Text = DataGridView.Rows(Data.RowIndex).Cells("Nombre").Value
            NumericPrecio.Text = DataGridView.Rows(Data.RowIndex).Cells("Precio").Value
            NumericIVA.Text = DataGridView.Rows(Data.RowIndex).Cells("IVA").Value
            stockAnterior = DataGridView.Rows(Data.RowIndex).Cells("Stock").Value
            NumericStock.Text = stockAnterior
            ComboFamilia.Text = DataGridView.Rows(Data.RowIndex).Cells("Familia").Value

            Dim urlValue As Object = DataGridView.Rows(Data.RowIndex).Cells("URL").Value
            If IsDBNull(urlValue) OrElse String.IsNullOrEmpty(urlValue.ToString()) Then
                tbURL.Text = ""
            Else
                tbURL.Text = urlValue.ToString()
                cargarURL()
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "No se ha podido cargar el ComboBox", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If connection.State = ConnectionState.Open Then
                connection.Close()
            End If
        End Try
    End Sub

    Private Sub GetArticulos()
        Try
            ' Consulta para obtener los artículos junto con sus nombres de familia usando JOIN
            Dim query As String = "SELECT a.id_articulo AS ID, a.nombre_articulo AS Nombre, a.precio_venta AS Precio, a.cantidad_stock AS Stock, a.IVA, f.nombre_familia AS Familia, a.url AS URL FROM Articulos a LEFT JOIN Familias f ON a.id_familia = f.id_familia"

            Dim adapter As New SqlClient.SqlDataAdapter(query, connection)
            Dim dataSet As New DataSet()

            adapter.Fill(dataSet, "Articulos")
            DataGridView.DataSource = dataSet.Tables("Articulos")

            ' Ocultar la columna URL si no es necesario mostrarla
            DataGridView.Columns("URL").Visible = False
        Catch ex As Exception
            MsgBox("Error al obtener los Articulos: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub AddIconColumns()
        Dim deleteColumn As New DataGridViewImageColumn()
        Try
            deleteColumn.Image = Image.FromFile(Path.GetFullPath("src\delete_icon.png"))
            deleteColumn.Name = "Eliminar"
            DataGridView.Columns.Add(deleteColumn)
        Catch ex As Exception
            MsgBox(ex.Message())
        End Try

        Dim updateColumn As New DataGridViewImageColumn()
        Try
            updateColumn.Image = Image.FromFile(Path.GetFullPath("src/edit_icon.png"))
            updateColumn.Name = "Modificar"
            DataGridView.Columns.Add(updateColumn)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub StyleDataGridView()
        With DataGridView.ColumnHeadersDefaultCellStyle
            .BackColor = Color.DarkSlateGray
            .ForeColor = Color.White
            .Font = New Font(DataGridView.Font, FontStyle.Bold)
        End With

        With DataGridView.DefaultCellStyle
            .BackColor = Color.LightGray
            .ForeColor = Color.Black
            .SelectionBackColor = Color.DarkSlateGray
            .SelectionForeColor = Color.White
            .Font = New Font(DataGridView.Font, FontStyle.Regular)
            .Padding = New Padding(10)
        End With

        With DataGridView.AlternatingRowsDefaultCellStyle
            .BackColor = Color.White
            .ForeColor = Color.Black
        End With

        DataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        DataGridView.AutoResizeColumns()
        DataGridView.AllowUserToAddRows = False
        DataGridView.ReadOnly = True

        DataGridView.RowTemplate.Height = 40
    End Sub

    Private Sub ModificarArticulo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetArticulos()
        AddIconColumns()
        StyleDataGridView()
    End Sub

    Private Sub btVolver_Click(sender As Object, e As EventArgs) Handles btVolver.Click
        Dim formAdministradorMenu As New AdministradorMenu()
        formAdministradorMenu.Show()
        Me.Close()
    End Sub

    Private Sub btVolver2_Click(sender As Object, e As EventArgs) Handles btVolver2.Click
        ResetModal()
    End Sub

    Private Sub cargarURL()
        Try
            Dim request As System.Net.WebRequest = System.Net.WebRequest.Create(tbURL.Text)
            Dim response As System.Net.WebResponse = request.GetResponse()
            Dim stream As System.IO.Stream = response.GetResponseStream()

            Dim originalImage As Image = Image.FromStream(stream)

            Dim ratioX As Double = PictureArticulo.Width / originalImage.Width
            Dim ratioY As Double = PictureArticulo.Height / originalImage.Height
            Dim ratio As Double = Math.Min(ratioX, ratioY)

            Dim newWidth As Integer = CInt(originalImage.Width * ratio)
            Dim newHeight As Integer = CInt(originalImage.Height * ratio)

            Dim newImage As New Bitmap(newWidth, newHeight)

            Using g As Graphics = Graphics.FromImage(newImage)
                g.InterpolationMode = Drawing2D.InterpolationMode.HighQualityBicubic
                g.DrawImage(originalImage, 0, 0, newWidth, newHeight)
            End Using

            PictureArticulo.SizeMode = PictureBoxSizeMode.CenterImage
            PictureArticulo.Image = newImage

            originalImage.Dispose()
        Catch ex As Exception
            PictureArticulo.Image = Image.FromFile(Path.GetFullPath("src/error_icon.png"))
            PictureArticulo.SizeMode = PictureBoxSizeMode.CenterImage

        End Try
    End Sub

    Private Sub ResetModal()
        PanelModificar.Visible = False
        tbNombre.Text = ""
        NumericIVA.Text = ""
        NumericPrecio.Text = ""
        NumericStock.Text = ""
        ComboFamilia.Text = ""
        tbURL.Text = ""
    End Sub

    Private Sub tbURL_TextChanged(sender As Object, e As EventArgs) Handles tbURL.TextChanged
        cargarURL()
    End Sub

    Private Sub btGuardar_Click(sender As Object, e As EventArgs) Handles btGuardar.Click
        Try
            nuevoNombre = tbNombre.Text
            nuevoPrecio = NumericPrecio.Text
            nuevoStock = NumericStock.Text
            nuevoIVA = NumericIVA.Text
            nuevaFamilia = ComboFamilia.Text
            nuevoIdFamilia = getIdFamilia(nuevaFamilia)
            nuevaURL = tbURL.Text
            Dim nuevaModStock As Date = Date.Today

            Dim queryUpdate As String = ""

            If stockAnterior <> nuevoStock Then
                queryUpdate = "UPDATE Articulos SET nombre_articulo = @nuevoNombre, precio_venta = @nuevoPrecio, cantidad_stock = @nuevoStock, ultima_mod_stock = @fechaActual, IVA = @nuevoIVA, id_familia = @nuevoIdFamilia, url = @nuevaURL WHERE id_articulo = @idSeleccionado"
            Else
                queryUpdate = "UPDATE Articulos SET nombre_articulo = @nuevoNombre, precio_venta = @nuevoPrecio, cantidad_stock = @nuevoStock, IVA = @nuevoIVA, id_familia = @nuevoIdFamilia, url = @nuevaURL WHERE id_articulo = @idSeleccionado"
            End If

            Using command As New SqlClient.SqlCommand(queryUpdate, connection)
                command.Parameters.AddWithValue("@nuevoNombre", nuevoNombre)
                command.Parameters.AddWithValue("@nuevoPrecio", nuevoPrecio)
                command.Parameters.AddWithValue("@nuevoStock", nuevoStock)

                If stockAnterior <> nuevoStock Then
                    command.Parameters.AddWithValue("@fechaActual", nuevaModStock)
                End If

                command.Parameters.AddWithValue("@nuevoIVA", nuevoIVA)
                command.Parameters.AddWithValue("@nuevoIdFamilia", nuevoIdFamilia)
                command.Parameters.AddWithValue("@nuevaURL", nuevaURL)
                command.Parameters.AddWithValue("@idSeleccionado", idSeleccionado)

                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If

                command.ExecuteNonQuery()
            End Using

            connection.Close()
            MessageBox.Show("El producto se ha modificado correctamente.", "Producto modificado", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ResetModal()
            GetArticulos()
        Catch ex As Exception
            MsgBox("Error al modificar el producto: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Function getIdFamilia(familiaNombre As String) As Integer
        Dim idFamilia As Integer = 0
        Dim query As String = "SELECT id_familia FROM Familias WHERE nombre_familia = @familiaNombre"

        Try
            Using command As New SqlClient.SqlCommand(query, connection)
                command.Parameters.AddWithValue("@familiaNombre", familiaNombre.Trim())

                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If

                Dim result = command.ExecuteScalar()

                If result IsNot Nothing Then
                    idFamilia = Convert.ToInt32(result)
                Else
                    MsgBox("No se encontró una familia con el nombre: " & familiaNombre, MsgBoxStyle.Information, "Familia no encontrada")
                End If
            End Using
        Catch ex As Exception
            MsgBox("Error en la familia: " & ex.Message, MsgBoxStyle.Critical, "Error")
        Finally
            If connection.State = ConnectionState.Open Then
                connection.Close()
            End If
        End Try
        Return idFamilia
    End Function

End Class