﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ModificarEmpleado
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        DataGridView = New DataGridView()
        btVolver = New Button()
        lblTitulo = New Label()
        PanelModificar = New Panel()
        lblSeparacion = New Label()
        lblTituloModa = New Label()
        btGuardar = New Button()
        btVolver2 = New Button()
        lblPosicion = New Label()
        ComboRol = New ComboBox()
        tbContrasenia = New TextBox()
        lblContrasenia = New Label()
        tbUsuario = New TextBox()
        lblUsuario = New Label()
        tbNombre = New TextBox()
        lblNombre = New Label()
        CType(DataGridView, ComponentModel.ISupportInitialize).BeginInit()
        PanelModificar.SuspendLayout()
        SuspendLayout()
        ' 
        ' DataGridView
        ' 
        DataGridView.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        DataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        DataGridView.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells
        DataGridView.BackgroundColor = SystemColors.ButtonFace
        DataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView.Cursor = Cursors.Hand
        DataGridView.Location = New Point(127, 102)
        DataGridView.Name = "DataGridView"
        DataGridView.RowHeadersVisible = False
        DataGridView.RowHeadersWidth = 51
        DataGridView.Size = New Size(985, 455)
        DataGridView.TabIndex = 0
        ' 
        ' btVolver
        ' 
        btVolver.BackColor = Color.IndianRed
        btVolver.Cursor = Cursors.Hand
        btVolver.Font = New Font("MS Reference Sans Serif", 11F)
        btVolver.Location = New Point(43, 592)
        btVolver.Name = "btVolver"
        btVolver.Size = New Size(137, 47)
        btVolver.TabIndex = 5
        btVolver.Text = "Volver"
        btVolver.UseVisualStyleBackColor = False
        ' 
        ' lblTitulo
        ' 
        lblTitulo.AutoSize = True
        lblTitulo.Font = New Font("MS Reference Sans Serif", 25.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitulo.ForeColor = SystemColors.Desktop
        lblTitulo.Location = New Point(461, 31)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(272, 55)
        lblTitulo.TabIndex = 6
        lblTitulo.Text = "Empleados"
        ' 
        ' PanelModificar
        ' 
        PanelModificar.BackColor = SystemColors.ActiveBorder
        PanelModificar.Controls.Add(lblSeparacion)
        PanelModificar.Controls.Add(lblTituloModa)
        PanelModificar.Controls.Add(btGuardar)
        PanelModificar.Controls.Add(btVolver2)
        PanelModificar.Controls.Add(lblPosicion)
        PanelModificar.Controls.Add(ComboRol)
        PanelModificar.Controls.Add(tbContrasenia)
        PanelModificar.Controls.Add(lblContrasenia)
        PanelModificar.Controls.Add(tbUsuario)
        PanelModificar.Controls.Add(lblUsuario)
        PanelModificar.Controls.Add(tbNombre)
        PanelModificar.Controls.Add(lblNombre)
        PanelModificar.Location = New Point(236, 68)
        PanelModificar.Name = "PanelModificar"
        PanelModificar.Size = New Size(766, 542)
        PanelModificar.TabIndex = 7
        PanelModificar.Visible = False
        ' 
        ' lblSeparacion
        ' 
        lblSeparacion.AutoSize = True
        lblSeparacion.Font = New Font("MS Reference Sans Serif", 14.8000011F, FontStyle.Bold)
        lblSeparacion.Location = New Point(83, 78)
        lblSeparacion.Name = "lblSeparacion"
        lblSeparacion.Size = New Size(578, 32)
        lblSeparacion.TabIndex = 25
        lblSeparacion.Text = "-----------------------------------------------"
        ' 
        ' lblTituloModa
        ' 
        lblTituloModa.AutoSize = True
        lblTituloModa.Font = New Font("MS Reference Sans Serif", 21F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTituloModa.Location = New Point(206, 34)
        lblTituloModa.Name = "lblTituloModa"
        lblTituloModa.Size = New Size(337, 44)
        lblTituloModa.TabIndex = 24
        lblTituloModa.Text = "Modificar Usuario"
        ' 
        ' btGuardar
        ' 
        btGuardar.BackColor = SystemColors.ActiveCaption
        btGuardar.Cursor = Cursors.Hand
        btGuardar.Font = New Font("MS Reference Sans Serif", 11F)
        btGuardar.Location = New Point(236, 459)
        btGuardar.Name = "btGuardar"
        btGuardar.Size = New Size(245, 67)
        btGuardar.TabIndex = 8
        btGuardar.Text = "Guardar Cambios"
        btGuardar.UseVisualStyleBackColor = False
        ' 
        ' btVolver2
        ' 
        btVolver2.BackColor = Color.DarkRed
        btVolver2.Cursor = Cursors.Hand
        btVolver2.ForeColor = SystemColors.ButtonHighlight
        btVolver2.Location = New Point(14, 15)
        btVolver2.Name = "btVolver2"
        btVolver2.Size = New Size(30, 29)
        btVolver2.TabIndex = 23
        btVolver2.Text = "X"
        btVolver2.UseVisualStyleBackColor = False
        ' 
        ' lblPosicion
        ' 
        lblPosicion.AutoSize = True
        lblPosicion.Font = New Font("MS Reference Sans Serif", 15F)
        lblPosicion.Location = New Point(160, 380)
        lblPosicion.Name = "lblPosicion"
        lblPosicion.Size = New Size(113, 32)
        lblPosicion.TabIndex = 22
        lblPosicion.Text = "Posición"
        ' 
        ' ComboRol
        ' 
        ComboRol.Font = New Font("MS Reference Sans Serif", 15F)
        ComboRol.FormattingEnabled = True
        ComboRol.Items.AddRange(New Object() {"Cocinero", "Personal de Barra", "Camarero", "Gerente"})
        ComboRol.Location = New Point(376, 377)
        ComboRol.Name = "ComboRol"
        ComboRol.Size = New Size(270, 40)
        ComboRol.TabIndex = 21
        ' 
        ' tbContrasenia
        ' 
        tbContrasenia.Font = New Font("MS Reference Sans Serif", 15F)
        tbContrasenia.Location = New Point(376, 294)
        tbContrasenia.Name = "tbContrasenia"
        tbContrasenia.Size = New Size(270, 38)
        tbContrasenia.TabIndex = 20
        ' 
        ' lblContrasenia
        ' 
        lblContrasenia.AutoSize = True
        lblContrasenia.Font = New Font("MS Reference Sans Serif", 15F)
        lblContrasenia.Location = New Point(116, 294)
        lblContrasenia.Name = "lblContrasenia"
        lblContrasenia.Size = New Size(157, 32)
        lblContrasenia.TabIndex = 19
        lblContrasenia.Text = "Contraseña"
        ' 
        ' tbUsuario
        ' 
        tbUsuario.Font = New Font("MS Reference Sans Serif", 15F)
        tbUsuario.Location = New Point(376, 210)
        tbUsuario.Name = "tbUsuario"
        tbUsuario.Size = New Size(270, 38)
        tbUsuario.TabIndex = 18
        ' 
        ' lblUsuario
        ' 
        lblUsuario.AutoSize = True
        lblUsuario.Font = New Font("MS Reference Sans Serif", 15F)
        lblUsuario.Location = New Point(165, 213)
        lblUsuario.Name = "lblUsuario"
        lblUsuario.Size = New Size(108, 32)
        lblUsuario.TabIndex = 17
        lblUsuario.Text = "Usuario"
        ' 
        ' tbNombre
        ' 
        tbNombre.Font = New Font("MS Reference Sans Serif", 15F)
        tbNombre.Location = New Point(376, 130)
        tbNombre.Name = "tbNombre"
        tbNombre.Size = New Size(270, 38)
        tbNombre.TabIndex = 16
        ' 
        ' lblNombre
        ' 
        lblNombre.AutoSize = True
        lblNombre.Font = New Font("MS Reference Sans Serif", 15F)
        lblNombre.Location = New Point(159, 133)
        lblNombre.Name = "lblNombre"
        lblNombre.Size = New Size(114, 32)
        lblNombre.TabIndex = 15
        lblNombre.Text = "Nombre"
        ' 
        ' ModificarEmpleado
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1262, 673)
        Controls.Add(PanelModificar)
        Controls.Add(lblTitulo)
        Controls.Add(btVolver)
        Controls.Add(DataGridView)
        Name = "ModificarEmpleado"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Modificar Empleado"
        CType(DataGridView, ComponentModel.ISupportInitialize).EndInit()
        PanelModificar.ResumeLayout(False)
        PanelModificar.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents DataGridView As DataGridView
    Friend WithEvents btVolver As Button
    Friend WithEvents lblTitulo As Label
    Friend WithEvents PanelModificar As Panel
    Friend WithEvents lblPosicion As Label
    Friend WithEvents ComboRol As ComboBox
    Friend WithEvents tbContrasenia As TextBox
    Friend WithEvents lblContrasenia As Label
    Friend WithEvents tbUsuario As TextBox
    Friend WithEvents lblUsuario As Label
    Friend WithEvents tbNombre As TextBox
    Friend WithEvents lblNombre As Label
    Friend WithEvents btVolver2 As Button
    Friend WithEvents lblTituloModa As Label
    Friend WithEvents btGuardar As Button
    Friend WithEvents lblSeparacion As Label
End Class
