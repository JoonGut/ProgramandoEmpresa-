﻿Imports System.IO
Imports System.Data.SqlClient
Imports System.Data.Common

Public Class ModificarEmpleado

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView.CellContentClick
        If e.ColumnIndex = DataGridView.Columns("Eliminar").Index Then
            EliminarEmpleado(e)
        ElseIf e.ColumnIndex = DataGridView.Columns("Modificar").Index Then
            mostrarModal(e)
        End If
    End Sub

    Private Sub mostrarModal(Data As DataGridViewCellEventArgs)
        PanelModificar.Visible = True
        tbNombre.Text = DataGridView.Rows(Data.RowIndex).Cells("Nombre").Value
        tbUsuario.Text = DataGridView.Rows(Data.RowIndex).Cells("Usuario").Value
        tbContrasenia.Text = DataGridView.Rows(Data.RowIndex).Cells("Contraseña").Value
        ComboRol.Text = DataGridView.Rows(Data.RowIndex).Cells("Rol").Value
    End Sub

    Private Sub btGuardar_Click(sender As Object, e As EventArgs) Handles btGuardar.Click
        Try
            Dim nuevoUsuario As String = tbUsuario.Text
            Dim contrasenia As String = tbContrasenia.Text
            Dim nombre As String = tbNombre.Text
            Dim idRol As Integer
            If ComboRol.Text = "Camarero" Then
                idRol = 2
            ElseIf ComboRol.Text = "Gerente" Then
                idRol = 1
            ElseIf ComboRol.Text = "Personal de Barra" Then
                idRol = 3
            ElseIf ComboRol.Text = "Cocinero" Then
                idRol = 4
            Else
                MessageBox.Show("Por favor selecciona el rol antes de continuar.", "Campos sin rellenar", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If
            Dim usuarioActual As String = DataGridView.Rows(DataGridView.CurrentRow.Index).Cells("Usuario").Value.ToString()

            Dim queryUpdate As String = "UPDATE Empleados SET usuario = @nuevoUsuario, contrasenia = @contrasenia, nombre = @nombre, id_rol = @idRol WHERE usuario = @usuarioActual"
            Using command As New SqlClient.SqlCommand(queryUpdate, connection)
                command.Parameters.AddWithValue("@nuevoUsuario", nuevoUsuario)
                command.Parameters.AddWithValue("@contrasenia", contrasenia)
                command.Parameters.AddWithValue("@nombre", nombre)
                command.Parameters.AddWithValue("@idRol", idRol)
                command.Parameters.AddWithValue("@usuarioActual", usuarioActual)

                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If

                command.ExecuteNonQuery()
            End Using

            connection.Close()
            MessageBox.Show("El empleado se ha modificado correctamente.", "Empleado modificado", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ResetModal()
            GetEmpleados()
        Catch ex As Exception
            MsgBox("Error al modificar el empleado: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub EliminarEmpleado(Data As DataGridViewCellEventArgs)
        Dim diag As DialogResult = MessageBox.Show("Estas seguro que quieres borrar a este empleado?", "Advertencia", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning)
        If diag = DialogResult.Yes Then
            Dim query As String = "DELETE FROM Empleados WHERE usuario = '" & DataGridView.Rows(Data.RowIndex).Cells("Usuario").Value & "'"
            Dim command As New SqlClient.SqlCommand(query, connection)
            Try
                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If
                command.ExecuteNonQuery()
                connection.Close()
                MessageBox.Show("Empleado borrado correctamente", "Empleado eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Catch ex As Exception
                MessageBox.Show("El empleado no se ha podido eliminar: " & ex.Message, "No se ha podido eliminar", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            GetEmpleados()
        End If
    End Sub

    Private Sub GetEmpleados()
        Try
            Dim query As String = "SELECT usuario AS Usuario, contrasenia AS Contraseña, nombre AS Nombre, " &
                "CASE id_rol " &
                "WHEN 1 THEN 'Gerente' " &
                "WHEN 2 THEN 'Camarero' " &
                "WHEN 3 THEN 'Personal de barra' " &
                "WHEN 4 THEN 'Cocinero' " &
                "END AS Rol " &
                "FROM Empleados"
            Dim adapter As New SqlClient.SqlDataAdapter(query, connection)
            Dim dataSet As New DataSet()
            adapter.Fill(dataSet, "Empleados")
            DataGridView.DataSource = dataSet.Tables("Empleados")

        Catch ex As Exception
            MsgBox("Error al obtener los empleados: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub AddIconColumns()
        Dim deleteColumn As New DataGridViewImageColumn()
        Try
            deleteColumn.Image = Image.FromFile(Path.GetFullPath("src\delete_icon.png"))
            deleteColumn.Name = "Eliminar"
            DataGridView.Columns.Add(deleteColumn)
        Catch ex As Exception
            MsgBox(ex.Message())
        End Try

        Dim updateColumn As New DataGridViewImageColumn()
        Try
            updateColumn.Image = Image.FromFile(Path.GetFullPath("src/edit_icon.png"))
            updateColumn.Name = "Modificar"
            DataGridView.Columns.Add(updateColumn)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub StyleDataGridView()
        With DataGridView.ColumnHeadersDefaultCellStyle
            .BackColor = Color.DarkSlateGray
            .ForeColor = Color.White
            .Font = New Font(DataGridView.Font, FontStyle.Bold)
        End With
        With DataGridView.DefaultCellStyle
            .BackColor = Color.LightGray
            .ForeColor = Color.Black
            .SelectionBackColor = Color.DarkSlateGray
            .SelectionForeColor = Color.White
            .Font = New Font(DataGridView.Font, FontStyle.Regular)
            .Padding = New Padding(10)
        End With
        With DataGridView.AlternatingRowsDefaultCellStyle
            .BackColor = Color.White
            .ForeColor = Color.Black
        End With
        DataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        DataGridView.AutoResizeColumns()
        DataGridView.AllowUserToAddRows = False
        DataGridView.ReadOnly = True
        DataGridView.RowTemplate.Height = 40
    End Sub

    Private Sub ModificarEmpleado_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetEmpleados()
        AddIconColumns()
        StyleDataGridView()
    End Sub

    Private Sub btVolver_Click(sender As Object, e As EventArgs) Handles btVolver.Click
        Dim formAdministradorMenu As New AdministradorMenu()
        formAdministradorMenu.Show()
        Me.Close()
    End Sub

    Private Sub btVolver2_Click(sender As Object, e As EventArgs) Handles btVolver2.Click
        ResetModal()
    End Sub

    Private Sub ResetModal()
        PanelModificar.Visible = False
        tbNombre.Text = ""
        tbUsuario.Text = ""
        tbContrasenia.Text = ""
        ComboRol.Text = ""
    End Sub
End Class