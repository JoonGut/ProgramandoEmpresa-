﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ModificarFamilia
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        PanelModificar = New Panel()
        lblSeparacion = New Label()
        lblTituloModal = New Label()
        btGuardar = New Button()
        btVolver2 = New Button()
        tbNombre = New TextBox()
        lblNombre = New Label()
        lblTitulo = New Label()
        btVolver = New Button()
        DataGridView = New DataGridView()
        PanelModificar.SuspendLayout()
        CType(DataGridView, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PanelModificar
        ' 
        PanelModificar.BackColor = SystemColors.ActiveBorder
        PanelModificar.Controls.Add(lblSeparacion)
        PanelModificar.Controls.Add(lblTituloModal)
        PanelModificar.Controls.Add(btGuardar)
        PanelModificar.Controls.Add(btVolver2)
        PanelModificar.Controls.Add(tbNombre)
        PanelModificar.Controls.Add(lblNombre)
        PanelModificar.Location = New Point(242, 46)
        PanelModificar.Name = "PanelModificar"
        PanelModificar.Size = New Size(801, 461)
        PanelModificar.TabIndex = 15
        PanelModificar.Visible = False
        ' 
        ' lblSeparacion
        ' 
        lblSeparacion.AutoSize = True
        lblSeparacion.Font = New Font("MS Reference Sans Serif", 14.8000011F, FontStyle.Bold)
        lblSeparacion.Location = New Point(108, 88)
        lblSeparacion.Name = "lblSeparacion"
        lblSeparacion.Size = New Size(578, 32)
        lblSeparacion.TabIndex = 25
        lblSeparacion.Text = "-----------------------------------------------"
        ' 
        ' lblTituloModal
        ' 
        lblTituloModal.AutoSize = True
        lblTituloModal.Font = New Font("MS Reference Sans Serif", 21F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTituloModal.Location = New Point(231, 44)
        lblTituloModal.Name = "lblTituloModal"
        lblTituloModal.Size = New Size(328, 44)
        lblTituloModal.TabIndex = 24
        lblTituloModal.Text = "Modificar Familia"
        ' 
        ' btGuardar
        ' 
        btGuardar.BackColor = SystemColors.ActiveCaption
        btGuardar.Cursor = Cursors.Hand
        btGuardar.Font = New Font("MS Reference Sans Serif", 11F)
        btGuardar.Location = New Point(251, 318)
        btGuardar.Name = "btGuardar"
        btGuardar.Size = New Size(245, 67)
        btGuardar.TabIndex = 8
        btGuardar.Text = "Guardar Cambios"
        btGuardar.UseVisualStyleBackColor = False
        ' 
        ' btVolver2
        ' 
        btVolver2.BackColor = Color.DarkRed
        btVolver2.Cursor = Cursors.Hand
        btVolver2.ForeColor = SystemColors.ButtonHighlight
        btVolver2.Location = New Point(22, 20)
        btVolver2.Name = "btVolver2"
        btVolver2.Size = New Size(30, 29)
        btVolver2.TabIndex = 23
        btVolver2.Text = "X"
        btVolver2.UseVisualStyleBackColor = False
        ' 
        ' tbNombre
        ' 
        tbNombre.Font = New Font("MS Reference Sans Serif", 15F)
        tbNombre.Location = New Point(383, 204)
        tbNombre.Name = "tbNombre"
        tbNombre.Size = New Size(270, 38)
        tbNombre.TabIndex = 38
        ' 
        ' lblNombre
        ' 
        lblNombre.AutoSize = True
        lblNombre.BackColor = SystemColors.ActiveBorder
        lblNombre.Font = New Font("MS Reference Sans Serif", 15F)
        lblNombre.Location = New Point(139, 207)
        lblNombre.Name = "lblNombre"
        lblNombre.Size = New Size(209, 32)
        lblNombre.TabIndex = 37
        lblNombre.Text = "Nombre Familia"
        ' 
        ' lblTitulo
        ' 
        lblTitulo.AutoSize = True
        lblTitulo.Font = New Font("MS Reference Sans Serif", 25.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitulo.ForeColor = SystemColors.Desktop
        lblTitulo.Location = New Point(524, 37)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(211, 55)
        lblTitulo.TabIndex = 14
        lblTitulo.Text = "Familias"
        ' 
        ' btVolver
        ' 
        btVolver.BackColor = Color.IndianRed
        btVolver.Cursor = Cursors.Hand
        btVolver.Font = New Font("MS Reference Sans Serif", 11F)
        btVolver.Location = New Point(64, 597)
        btVolver.Name = "btVolver"
        btVolver.Size = New Size(137, 47)
        btVolver.TabIndex = 13
        btVolver.Text = "Volver"
        btVolver.UseVisualStyleBackColor = False
        ' 
        ' DataGridView
        ' 
        DataGridView.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        DataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        DataGridView.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells
        DataGridView.BackgroundColor = SystemColors.ButtonFace
        DataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView.Cursor = Cursors.Hand
        DataGridView.Location = New Point(397, 95)
        DataGridView.Name = "DataGridView"
        DataGridView.RowHeadersVisible = False
        DataGridView.RowHeadersWidth = 51
        DataGridView.Size = New Size(464, 455)
        DataGridView.TabIndex = 12
        ' 
        ' ModificarFamilia
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1262, 673)
        Controls.Add(PanelModificar)
        Controls.Add(lblTitulo)
        Controls.Add(btVolver)
        Controls.Add(DataGridView)
        Name = "ModificarFamilia"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Modificar Familia"
        PanelModificar.ResumeLayout(False)
        PanelModificar.PerformLayout()
        CType(DataGridView, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PanelModificar As Panel
    Friend WithEvents ComboFamilia As ComboBox
    Friend WithEvents PictureArticulo As PictureBox
    Friend WithEvents lblFamilia As Label
    Friend WithEvents lblSeparacion As Label
    Friend WithEvents NumericIVA As NumericUpDown
    Friend WithEvents tbURL As TextBox
    Friend WithEvents NumericStock As NumericUpDown
    Friend WithEvents NumericPrecio As NumericUpDown
    Friend WithEvents lblURL As Label
    Friend WithEvents lblIVA As Label
    Friend WithEvents lblTituloModa As Label
    Friend WithEvents lblStock As Label
    Friend WithEvents btGuardar As Button
    Friend WithEvents lblUsuario As Label
    Friend WithEvents btVolver2 As Button
    Friend WithEvents tbNombre As TextBox
    Friend WithEvents lblNombre As Label
    Friend WithEvents lblTitulo As Label
    Friend WithEvents btVolver As Button
    Friend WithEvents DataGridView As DataGridView
    Friend WithEvents lblTituloModal As Label
End Class
