﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class ModificarFamilia

    Dim nuevoNombre As String
    Dim nombreSeleccionado As String

    Private Sub ModificarFamilia_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetFamilias()
        AddIconColumns()
        StyleDataGridView()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView.CellContentClick
        If e.ColumnIndex = DataGridView.Columns("Eliminar").Index Then
            eliminarFamilia(e)
        ElseIf e.ColumnIndex = DataGridView.Columns("Modificar").Index Then
            mostrarModal(e)
        End If
    End Sub

    Private Sub mostrarModal(Data As DataGridViewCellEventArgs)
        PanelModificar.Visible = True
        tbNombre.Text = DataGridView.Rows(Data.RowIndex).Cells("Nombre").Value
    End Sub

    Private Sub eliminarFamilia(Data As DataGridViewCellEventArgs)
        Dim diag As DialogResult = MessageBox.Show("Estas seguro que quieres borrar a esta familia?", "Advertencia", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning)
        If diag = DialogResult.Yes Then
            Dim query As String = "DELETE FROM Familias WHERE nombre_familia = '" & DataGridView.Rows(Data.RowIndex).Cells("Nombre").Value & "'"
            Dim command As New SqlClient.SqlCommand(query, connection)
            Try
                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If
                command.ExecuteNonQuery()
                connection.Close()
                MessageBox.Show("Familia borrada correctamente", "Familia eliminada", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Catch ex As Exception
                MessageBox.Show("La Familia no se ha podido eliminar: " & ex.Message, "No se ha podido eliminar", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            GetFamilias()
        End If
    End Sub

    Private Sub GetFamilias()
        Try
            Dim query As String = "SELECT id_familia AS ID, nombre_familia AS Nombre FROM Familias"
            Dim adapter As New SqlClient.SqlDataAdapter(query, connection)
            Dim dataSet As New DataSet()
            adapter.Fill(dataSet, "Familias")
            DataGridView.DataSource = dataSet.Tables("Familias")
        Catch ex As Exception
            MsgBox("Error al obtener las Familias: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub AddIconColumns()
        Dim deleteColumn As New DataGridViewImageColumn()
        Try
            deleteColumn.Image = Image.FromFile(Path.GetFullPath("src\delete_icon.png"))
            deleteColumn.Name = "Eliminar"
            DataGridView.Columns.Add(deleteColumn)
        Catch ex As Exception
            MsgBox(ex.Message())
        End Try

        Dim updateColumn As New DataGridViewImageColumn()
        Try
            updateColumn.Image = Image.FromFile(Path.GetFullPath("src/edit_icon.png"))
            updateColumn.Name = "Modificar"
            DataGridView.Columns.Add(updateColumn)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub StyleDataGridView()
        With DataGridView.ColumnHeadersDefaultCellStyle
            .BackColor = Color.DarkSlateGray
            .ForeColor = Color.White
            .Font = New Font(DataGridView.Font, FontStyle.Bold)
        End With

        With DataGridView.DefaultCellStyle
            .BackColor = Color.LightGray
            .ForeColor = Color.Black
            .SelectionBackColor = Color.DarkSlateGray
            .SelectionForeColor = Color.White
            .Font = New Font(DataGridView.Font, FontStyle.Regular)
            .Padding = New Padding(10)
        End With

        With DataGridView.AlternatingRowsDefaultCellStyle
            .BackColor = Color.White
            .ForeColor = Color.Black
        End With

        DataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        DataGridView.AutoResizeColumns()
        DataGridView.AllowUserToAddRows = False
        DataGridView.ReadOnly = True

        DataGridView.RowTemplate.Height = 40
    End Sub

    Private Sub btGuardar_Click(sender As Object, e As EventArgs) Handles btGuardar.Click
        Try
            nuevoNombre = tbNombre.Text
            nombreSeleccionado = DataGridView.Rows(DataGridView.CurrentRow.Index).Cells("Nombre").Value.ToString()

            Dim queryUpdate As String = "UPDATE Familias SET nombre_familia = @nuevoNombre WHERE nombre_familia = @nombreSeleccionado"
            Using command As New SqlClient.SqlCommand(queryUpdate, connection)
                command.Parameters.AddWithValue("@nuevoNombre", nuevoNombre)
                command.Parameters.AddWithValue("@nombreSeleccionado", nombreSeleccionado)

                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If

                command.ExecuteNonQuery()
            End Using

            connection.Close()
            MessageBox.Show("La familia se ha modificado correctamente.", "Familia modificada", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ResetModal()
            GetFamilias()
        Catch ex As Exception
            MessageBox.Show("Error al modificar la familia, comprueba que no haya articulos en esta familia -- " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btVolver_Click(sender As Object, e As EventArgs) Handles btVolver.Click
        Dim formAdministradorMenu As New AdministradorMenu()
        formAdministradorMenu.Show()
        Me.Close()
    End Sub

    Private Sub btVolver2_Click(sender As Object, e As EventArgs) Handles btVolver2.Click
        ResetModal()
    End Sub

    Private Sub ResetModal()
        PanelModificar.Visible = False
        tbNombre.Text = ""
    End Sub
End Class