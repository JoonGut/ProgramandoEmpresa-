﻿Imports System.Data.SqlClient
Imports System.IO

Public Class MostrarComandas
    Dim nombreCamarero As String
    Dim idComandaActual As Integer
    Dim listaArticulos As New List(Of ArticuloComanda)
    Private idComandaSeleccionada As Integer


    Public Sub New(nombre As String)
        InitializeComponent()
        lblTitulo.Text = "Comandas de " + nombre
        nombreCamarero = nombre
    End Sub

    Private Sub MostrarComandas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetComandas()
        AddIconColumns(DataGridView)
        StyleDataGridView(DataGridView)
    End Sub

    Private Sub GetComandas()
        Try
            Dim query As String = "
            SELECT id_comanda AS ID, usuario AS Camarero, fecha AS Fecha, CASE WHEN numero_mesa = 0 THEN '0 (Barra)' ELSE CAST(numero_mesa AS VARCHAR) END AS Mesa, costo_total AS 'Costo Total' FROM Comandas c WHERE usuario = @usuario"
            Dim adapter As New SqlClient.SqlDataAdapter(query, connection)
            adapter.SelectCommand.Parameters.AddWithValue("@usuario", nombreCamarero)

            Dim dataSet As New DataSet()
            adapter.Fill(dataSet, "Comandas")

            DataGridView.DataSource = dataSet.Tables("Comandas")
        Catch ex As Exception
            MsgBox("Error al obtener las Comandas: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub AddIconColumns(ByRef dgv As DataGridView)
        Dim deleteColumn As New DataGridViewImageColumn()
        Try
            deleteColumn.Image = Image.FromFile(Path.GetFullPath("src\delete_icon.png"))
            deleteColumn.Name = "Eliminar"
            dgv.Columns.Add(deleteColumn)
        Catch ex As Exception
            MsgBox(ex.Message())
        End Try

    End Sub

    Private Sub StyleDataGridView(ByRef dgv As DataGridView)
        With dgv.ColumnHeadersDefaultCellStyle
            .BackColor = Color.DarkBlue
            .ForeColor = Color.White
            .Font = New Font(dgv.Font, FontStyle.Bold)
            .Alignment = DataGridViewContentAlignment.MiddleCenter
        End With
        With dgv.DefaultCellStyle
            .BackColor = Color.WhiteSmoke
            .ForeColor = Color.Black
            .SelectionBackColor = Color.SteelBlue
            .SelectionForeColor = Color.White
            .Font = New Font(dgv.Font, FontStyle.Regular)
            .Padding = New Padding(5)
        End With
        With dgv.AlternatingRowsDefaultCellStyle
            .BackColor = Color.LightGray
            .ForeColor = Color.Black
        End With
        dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgv.AutoResizeColumns()
        dgv.AllowUserToAddRows = False
        dgv.ReadOnly = True
        dgv.RowTemplate.Height = 40
        dgv.RowHeadersVisible = False
    End Sub


    Private Sub DataGridView_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView.CellClick
        Try
            If e.ColumnIndex = DataGridView.Columns("Eliminar").Index AndAlso e.RowIndex >= 0 Then
                Dim idComanda As Integer = Convert.ToInt32(DataGridView.Rows(e.RowIndex).Cells("ID").Value)
                Dim confirmResult As DialogResult = MessageBox.Show($"¿Está seguro de que desea eliminar la comanda con ID {idComanda}?", "Confirmar eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If confirmResult = DialogResult.Yes Then
                    EliminarComanda(idComanda)
                End If
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub EliminarComanda(idComanda As Integer)
        Dim queryEliminarComanda As String = "DELETE FROM Comandas WHERE id_comanda = @idComanda"
        Dim queryEliminarInfoComandas As String = "DELETE FROM Infocomandas WHERE id_comanda = @idComanda"

        Try
            If connection.State = ConnectionState.Closed Then
                connection.Open()
            End If

            Using commandInfoComandas As New SqlCommand(queryEliminarInfoComandas, connection)
                commandInfoComandas.Parameters.AddWithValue("@idComanda", idComanda)
                commandInfoComandas.ExecuteNonQuery()
            End Using

            Using commandComanda As New SqlCommand(queryEliminarComanda, connection)
                commandComanda.Parameters.AddWithValue("@idComanda", idComanda)
                commandComanda.ExecuteNonQuery()
            End Using

            MessageBox.Show($"La comanda con ID {idComanda} ha sido eliminada correctamente.", "Comanda eliminada", MessageBoxButtons.OK, MessageBoxIcon.Information)

            GetComandas()
        Catch ex As Exception
            MessageBox.Show($"Error al eliminar la comanda: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If connection.State = ConnectionState.Open Then
                connection.Close()
            End If
        End Try
    End Sub

    Private Sub btVolver_Click(sender As Object, e As EventArgs) Handles btVolver.Click
        Dim formMenu As New CamareroMenu(nombreCamarero)
        formMenu.Show()
        Close()
    End Sub
End Class

Public Class ArticuloComanda
    Public Property IdArticulo As Integer
    Public Property Nombre As String
    Public Property Cantidad As Integer
    Public Property Precio As Double
End Class

