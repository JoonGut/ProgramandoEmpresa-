﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MostrarInforme
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblTitulo = New Label()
        DataGridView = New DataGridView()
        DateTimePicker = New DateTimePicker()
        lblCajaTotal = New Label()
        btVolver = New Button()
        CType(DataGridView, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblTitulo
        ' 
        lblTitulo.Font = New Font("MS Reference Sans Serif", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitulo.ForeColor = SystemColors.Desktop
        lblTitulo.Location = New Point(12, 34)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(452, 60)
        lblTitulo.TabIndex = 16
        lblTitulo.Text = "Informe Diario del: "
        lblTitulo.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' DataGridView
        ' 
        DataGridView.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        DataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        DataGridView.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells
        DataGridView.BackgroundColor = SystemColors.ButtonFace
        DataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView.Cursor = Cursors.Hand
        DataGridView.Location = New Point(46, 96)
        DataGridView.Name = "DataGridView"
        DataGridView.RowHeadersVisible = False
        DataGridView.RowHeadersWidth = 51
        DataGridView.Size = New Size(706, 273)
        DataGridView.TabIndex = 15
        ' 
        ' DateTimePicker
        ' 
        DateTimePicker.Font = New Font("MS Reference Sans Serif", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        DateTimePicker.Format = DateTimePickerFormat.Short
        DateTimePicker.Location = New Point(481, 38)
        DateTimePicker.Name = "DateTimePicker"
        DateTimePicker.Size = New Size(271, 48)
        DateTimePicker.TabIndex = 17
        ' 
        ' lblCajaTotal
        ' 
        lblCajaTotal.Font = New Font("MS Reference Sans Serif", 13.8F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        lblCajaTotal.ForeColor = SystemColors.Desktop
        lblCajaTotal.Location = New Point(145, 372)
        lblCajaTotal.Name = "lblCajaTotal"
        lblCajaTotal.Size = New Size(607, 60)
        lblCajaTotal.TabIndex = 18
        lblCajaTotal.Text = "Caja total del"
        lblCajaTotal.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' btVolver
        ' 
        btVolver.BackColor = Color.IndianRed
        btVolver.Cursor = Cursors.Hand
        btVolver.Font = New Font("MS Reference Sans Serif", 11F)
        btVolver.Location = New Point(21, 396)
        btVolver.Name = "btVolver"
        btVolver.Size = New Size(118, 42)
        btVolver.TabIndex = 19
        btVolver.Text = "Volver"
        btVolver.UseVisualStyleBackColor = False
        ' 
        ' MostrarInforme
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(btVolver)
        Controls.Add(lblCajaTotal)
        Controls.Add(DateTimePicker)
        Controls.Add(lblTitulo)
        Controls.Add(DataGridView)
        Name = "MostrarInforme"
        StartPosition = FormStartPosition.CenterScreen
        Text = "MostrarInforme"
        CType(DataGridView, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents lblTitulo As Label
    Friend WithEvents DataGridView As DataGridView
    Friend WithEvents DateTimePicker As DateTimePicker
    Friend WithEvents lblCajaTotal As Label
    Friend WithEvents btVolver As Button
End Class
