﻿Imports System.Data.SqlClient

Public Class MostrarInforme
    Private Sub MostrarInforme_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MostrarComandasPorFecha()
        StyleDataGridViewComandas()
    End Sub

    Private Sub btVolver_Click(sender As Object, e As EventArgs) Handles btVolver.Click
        Me.Close()
    End Sub

    Private Sub MostrarComandasPorFecha()
        Dim fechaSeleccionada As Date = DateTimePicker.Value.Date

        Dim query As String = "SELECT id_comanda AS ID, usuario AS Camarero, fecha AS Fecha, numero_mesa AS Mesa, costo_total AS Total FROM Comandas WHERE CAST(fecha AS DATE) = @fechaSeleccionada"

        Try
            Dim adapter As New SqlDataAdapter(query, connection)
            Dim dataSet As New DataSet()
            adapter.SelectCommand.Parameters.AddWithValue("@fechaSeleccionada", fechaSeleccionada)
            adapter.Fill(dataSet, "Comandas")
            DataGridView.DataSource = dataSet.Tables("Comandas")
            Dim totalCaja As Double = 0
            For Each row As DataRow In dataSet.Tables("Comandas").Rows
                totalCaja += Convert.ToDouble(row("Total"))
            Next
            lblCajaTotal.Text = $"Caja total del {fechaSeleccionada:dd/MM/yyyy}: {totalCaja:C}"
            If dataSet.Tables("Comandas").Rows.Count = 0 Then
                MessageBox.Show("No se encontraron comandas para la fecha seleccionada.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception
            MessageBox.Show("Error al obtener las comandas: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub StyleDataGridViewComandas()
        With DataGridView.ColumnHeadersDefaultCellStyle
            .BackColor = Color.DarkBlue
            .ForeColor = Color.White
            .Font = New Font(DataGridView.Font, FontStyle.Bold)
            .Alignment = DataGridViewContentAlignment.MiddleCenter
        End With

        With DataGridView.DefaultCellStyle
            .BackColor = Color.WhiteSmoke
            .ForeColor = Color.Black
            .SelectionBackColor = Color.SteelBlue
            .SelectionForeColor = Color.White
            .Font = New Font(DataGridView.Font, FontStyle.Regular)
            .Padding = New Padding(5)
        End With

        With DataGridView.AlternatingRowsDefaultCellStyle
            .BackColor = Color.LightGray
            .ForeColor = Color.Black
        End With

        DataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        DataGridView.AutoResizeColumns()
        DataGridView.AllowUserToAddRows = False
        DataGridView.ReadOnly = True

        DataGridView.RowTemplate.Height = 40
        DataGridView.RowHeadersVisible = False
    End Sub

    Private Sub DateTimePicker_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker.ValueChanged
        MostrarComandasPorFecha()
    End Sub
End Class