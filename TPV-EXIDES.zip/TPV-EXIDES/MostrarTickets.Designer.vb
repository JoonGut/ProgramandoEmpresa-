﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MostrarTickets
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        tabla = New DataGridView()
        lblTitulo = New Label()
        btVolver = New Button()
        lblPregunta = New Label()
        cbOpciones = New ComboBox()
        cbCamareros = New ComboBox()
        cbTickets = New ComboBox()
        CType(tabla, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' tabla
        ' 
        tabla.AllowUserToAddRows = False
        tabla.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        tabla.Location = New Point(213, 174)
        tabla.Name = "tabla"
        tabla.RowHeadersWidth = 51
        tabla.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        tabla.Size = New Size(545, 344)
        tabla.TabIndex = 0
        ' 
        ' lblTitulo
        ' 
        lblTitulo.AutoSize = True
        lblTitulo.Font = New Font("MS Reference Sans Serif", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblTitulo.Location = New Point(355, 39)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(313, 38)
        lblTitulo.TabIndex = 1
        lblTitulo.Text = "Tickets y Productos"
        ' 
        ' btVolver
        ' 
        btVolver.BackColor = Color.IndianRed
        btVolver.Font = New Font("MS Reference Sans Serif", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btVolver.Location = New Point(32, 551)
        btVolver.Name = "btVolver"
        btVolver.Size = New Size(129, 44)
        btVolver.TabIndex = 2
        btVolver.Text = "Volver"
        btVolver.UseVisualStyleBackColor = False
        ' 
        ' lblPregunta
        ' 
        lblPregunta.AutoSize = True
        lblPregunta.Font = New Font("MS Reference Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblPregunta.Location = New Point(165, 115)
        lblPregunta.Name = "lblPregunta"
        lblPregunta.Size = New Size(244, 26)
        lblPregunta.TabIndex = 3
        lblPregunta.Text = "¿Qué desea visualizar?"
        ' 
        ' cbOpciones
        ' 
        cbOpciones.FormattingEnabled = True
        cbOpciones.Location = New Point(455, 113)
        cbOpciones.Name = "cbOpciones"
        cbOpciones.Size = New Size(151, 28)
        cbOpciones.TabIndex = 4
        ' 
        ' cbCamareros
        ' 
        cbCamareros.FormattingEnabled = True
        cbCamareros.Location = New Point(667, 113)
        cbCamareros.Name = "cbCamareros"
        cbCamareros.Size = New Size(122, 28)
        cbCamareros.TabIndex = 6
        cbCamareros.Visible = False
        ' 
        ' cbTickets
        ' 
        cbTickets.FormattingEnabled = True
        cbTickets.Location = New Point(826, 113)
        cbTickets.Name = "cbTickets"
        cbTickets.Size = New Size(203, 28)
        cbTickets.TabIndex = 7
        cbTickets.Visible = False
        ' 
        ' MostrarTickets
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1085, 626)
        Controls.Add(cbTickets)
        Controls.Add(cbCamareros)
        Controls.Add(cbOpciones)
        Controls.Add(lblPregunta)
        Controls.Add(btVolver)
        Controls.Add(lblTitulo)
        Controls.Add(tabla)
        Name = "MostrarTickets"
        Text = "MostrarTickets"
        CType(tabla, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents tabla As DataGridView
    Friend WithEvents lblTitulo As Label
    Friend WithEvents btVolver As Button
    Friend WithEvents lblPregunta As Label
    Friend WithEvents cbOpciones As ComboBox
    Friend WithEvents cbCamareros As ComboBox
    Friend WithEvents cbTickets As ComboBox
End Class
