﻿Imports System.Data.SqlClient
Imports System.Globalization
Imports System.IO
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class MostrarTickets
    Private Sub MostrarTickets_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.CenterToParent()
        limpiarTabla()
        formatoTabla()
        cargarTabla()
        cargarComboCamareros()

        cbOpciones.Items.Clear()

        cbOpciones.Items.Add("Productos Nuevos")
        cbOpciones.Items.Add("Tickets De Compra")
    End Sub

    Private Sub formatoTabla()
        tabla.Columns.Add("articuo", "Articulo")
        tabla.Columns.Add("cantidad", "Cantidad")
        tabla.Columns.Add("precio", "Precio")

        tabla.Columns(0).Width = tabla.Width * 0.4
        tabla.Columns(1).Width = tabla.Width * 0.23
        tabla.Columns(2).Width = tabla.Width * 0.23
    End Sub

    Private Sub limpiarTabla()
        tabla.Rows.Clear()
        tabla.Columns.Clear()
    End Sub

    Private Sub cargarTabla()
        Dim rutaArchivo As String = "Modificacion_de_Productos.txt"
        Dim productos As New List(Of Tuple(Of String, Integer, Decimal))()

        Try
            Dim lines As String() = File.ReadAllLines(rutaArchivo)
            For i As Integer = 0 To lines.Length - 1
                If lines(i).StartsWith("artículo:") Then
                    Dim nombreArticulo As String = lines(i).Split(":")(1).Trim()

                    Dim cantidadProducto As String = lines(i + 1).Trim()
                    Dim precioProducto As String = lines(i + 2).Trim()
                    Dim cantidad As Integer = CInt(cantidadProducto.Split(":")(1))
                    Dim precio_unitario As Decimal = Decimal.Parse(precioProducto.Split(":")(1), CultureInfo.InvariantCulture)  'sin esto da error 'CultureInfo.InvariantCulture' hay datos como 1,50 y no lo admite

                    productos.Add(Tuple.Create(nombreArticulo, cantidad, precio_unitario))
                    i += 2 'ya hemos cogido los datos de precio y cantidad que equivadlrian a las dos siguientes lienas
                End If
            Next
        Catch ex As Exception
            MsgBox("Error al leer el archivo: ")
        End Try

        For Each producto In productos
            tabla.Rows.Add(producto.Item1, producto.Item2, producto.Item3.ToString())
        Next
    End Sub

    Private Sub btVolver_Click(sender As Object, e As EventArgs) Handles btVolver.Click
        Dim frm As New PantallaInicio()
        frm.Show()
        Me.Close()
    End Sub

    Private Sub cbOpciones_SelectedValueChanged(sender As Object, e As EventArgs) Handles cbOpciones.SelectedValueChanged
        Dim opcion As String = cbOpciones.SelectedItem.ToString()

        Select Case opcion
            Case "Productos Nuevos"
                limpiarTabla()
                formatoTabla()
                cargarTabla()
                cbCamareros.Visible = False
                cbTickets.Visible = False
                tabla.Visible = True
            Case "Tickets De Compra"
                cbCamareros.Visible = True
                cbTickets.Visible = True
                tabla.Visible = False
                'seleccioanmos por defecto el primre camarero para que no de erroer de null pointer exception
                If cbCamareros.SelectedItem IsNot Nothing Then
                    cargarTicketsDelCamarero(cbCamareros.SelectedItem.ToString())
                Else
                    'Msgbox("Por favor, selecciona un camarero")
                End If
        End Select
    End Sub

    Private Sub cargarComboCamareros()
        cbCamareros.Items.Clear()
        Dim query As String = "select nombre from Empleados where id_rol=1 or id_rol=2"

        Try
            Using command As New SqlCommand(query, connection)
                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If

                Using v As SqlDataReader = command.ExecuteReader()
                    While v.Read()
                        If Not v("nombre").trim().toLower().ToString().Equals("Zeus".Trim().ToLower()) Then 'zeus tiene id 1 pero no puede hacer comandas luego no tendrá tickets
                            cbCamareros.Items.Add(v("nombre").ToString())
                        End If
                    End While
                End Using
            End Using
        Catch ex As Exception
            MsgBox("ERROR: " + ex.Message)
        End Try
    End Sub

    Private Sub cargarTicketsDelCamarero(nombreCamarero As String)
        If String.IsNullOrEmpty(nombreCamarero) Then
            MessageBox.Show("Debe seleccionar UN CAMARERO")
            Return
        End If
        cbTickets.Items.Clear()

        Dim query As String = "select idXML, fechaTicket from Tickets where 
                nombreCamarero = @nombreCamarero"

        Try
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@nombreCamarero", nombreCamarero)

                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If

                Using reader As SqlDataReader = command.ExecuteReader()
                    'ponemos en el combobox que no tienes tickets
                    If Not reader.HasRows Then
                        cbTickets.Items.Add("No hay Tickets")
                        Return
                    End If
                    While reader.Read()
                        'formatemaos para quitarle hora del ticket 
                        Dim fechaTicket As DateTime = Convert.ToDateTime(reader("fechaTicket"))
                        Dim fechaFormateada As String = fechaTicket.ToString("dd/MM/yyyy")

                        'añadimso al combo el id y la fecha del ticket
                        cbTickets.Items.Add(CStr(reader("idXML")) + "   ||   " + fechaFormateada)

                    End While
                End Using
            End Using
        Catch ex As Exception
            MsgBox("ERROR: " + ex.Message)
        End Try
    End Sub

    Private Sub cbCamareros_SelectedValueChanged(sender As Object, e As EventArgs) Handles cbCamareros.SelectedValueChanged
        If cbCamareros.SelectedItem IsNot Nothing Then
            Dim nombreCamarero As String = cbCamareros.SelectedItem.ToString()

            cargarTicketsDelCamarero(nombreCamarero)
        End If
    End Sub

    Private Sub cbTickets_SelectedValueChanged(sender As Object, e As EventArgs) Handles cbTickets.SelectedValueChanged
        If cbTickets.SelectedItem IsNot Nothing Then
            Dim ticketSeleccionado As String = cbTickets.SelectedItem.ToString()
            If ticketSeleccionado.Trim().ToLower() = "No hay Tickets".Trim().ToLower() Then
                Return
            End If

            Dim partes() As String = ticketSeleccionado.Split("   ||   ")

                If partes.Length > 0 Then
                    Try
                        Dim idXML As Integer = CInt(partes(0))
                        MostrarXML(idXML)
                    Catch ex As Exception
                        MsgBox("ERROR no se pueden mostarr datos")
                    End Try
                End If
            End If
    End Sub

    Private Sub MostrarXML(idXML As Integer)
        Dim query As String = "SELECT ticket FROM Tickets WHERE idXML = @idXML"
        Dim xmlString As String

        Try
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@idXML", idXML)

                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If

                Using reader As SqlDataReader = command.ExecuteReader()
                    If reader.Read() Then
                        xmlString = reader("ticket").ToString()
                    End If
                End Using
            End Using
        Catch ex As Exception
            MsgBox("ERROR al recuperar el XML: " + ex.Message)
            Return
        End Try

        Dim rutaArchivo As String = "TicketMostrar.xml"
        Try
            File.WriteAllText(rutaArchivo, xmlString)

            If File.Exists(rutaArchivo) Then
                Process.Start(New ProcessStartInfo With {
                    .FileName = rutaArchivo,
                    .UseShellExecute = True
                })
            Else
                MsgBox("El archivo XML no pudo ser creado.")
            End If
        Catch ex As Exception
            MsgBox("ERROR al guardar el archivo XML: " + ex.Message)
        End Try
    End Sub
End Class