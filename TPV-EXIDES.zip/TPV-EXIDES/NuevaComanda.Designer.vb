﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NuevaComanda
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btVolver = New Button()
        FlowLayoutFamilias = New FlowLayoutPanel()
        FlowLayoutArticulos = New FlowLayoutPanel()
        FlowLayoutComanda = New FlowLayoutPanel()
        PanelDescuentos = New Panel()
        bt30 = New Button()
        bt20 = New Button()
        bt10 = New Button()
        btDescuento = New Button()
        btFinalizar = New Button()
        lblTitulo = New Label()
        FlowLayoutPanel1 = New FlowLayoutPanel()
        lblPrecioTotal = New Label()
        PanelDescuentos.SuspendLayout()
        FlowLayoutPanel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' btVolver
        ' 
        btVolver.BackColor = Color.IndianRed
        btVolver.Cursor = Cursors.Hand
        btVolver.Font = New Font("MS Reference Sans Serif", 11F)
        btVolver.Location = New Point(1090, 599)
        btVolver.Name = "btVolver"
        btVolver.Size = New Size(122, 44)
        btVolver.TabIndex = 6
        btVolver.Text = "Volver"
        btVolver.UseVisualStyleBackColor = False
        ' 
        ' FlowLayoutFamilias
        ' 
        FlowLayoutFamilias.AutoScroll = True
        FlowLayoutFamilias.Location = New Point(1041, 34)
        FlowLayoutFamilias.Name = "FlowLayoutFamilias"
        FlowLayoutFamilias.Size = New Size(209, 543)
        FlowLayoutFamilias.TabIndex = 9
        ' 
        ' FlowLayoutArticulos
        ' 
        FlowLayoutArticulos.AutoScroll = True
        FlowLayoutArticulos.Location = New Point(408, 34)
        FlowLayoutArticulos.Name = "FlowLayoutArticulos"
        FlowLayoutArticulos.Size = New Size(595, 609)
        FlowLayoutArticulos.TabIndex = 10
        ' 
        ' FlowLayoutComanda
        ' 
        FlowLayoutComanda.AutoScroll = True
        FlowLayoutComanda.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(192))
        FlowLayoutComanda.Location = New Point(28, 81)
        FlowLayoutComanda.Name = "FlowLayoutComanda"
        FlowLayoutComanda.Size = New Size(341, 414)
        FlowLayoutComanda.TabIndex = 11
        ' 
        ' PanelDescuentos
        ' 
        PanelDescuentos.BackColor = Color.FromArgb(CByte(224), CByte(224), CByte(224))
        PanelDescuentos.Controls.Add(bt30)
        PanelDescuentos.Controls.Add(bt20)
        PanelDescuentos.Controls.Add(bt10)
        PanelDescuentos.Location = New Point(25, 70)
        PanelDescuentos.Name = "PanelDescuentos"
        PanelDescuentos.Size = New Size(350, 415)
        PanelDescuentos.TabIndex = 15
        PanelDescuentos.Visible = False
        ' 
        ' bt30
        ' 
        bt30.BackColor = Color.DarkOrange
        bt30.Cursor = Cursors.Hand
        bt30.Font = New Font("MS Reference Sans Serif", 11F)
        bt30.Location = New Point(80, 292)
        bt30.Name = "bt30"
        bt30.Size = New Size(178, 76)
        bt30.TabIndex = 18
        bt30.Text = "30%"
        bt30.UseVisualStyleBackColor = False
        ' 
        ' bt20
        ' 
        bt20.BackColor = Color.Coral
        bt20.Cursor = Cursors.Hand
        bt20.Font = New Font("MS Reference Sans Serif", 11F)
        bt20.Location = New Point(80, 170)
        bt20.Name = "bt20"
        bt20.Size = New Size(178, 76)
        bt20.TabIndex = 17
        bt20.Text = "20%"
        bt20.UseVisualStyleBackColor = False
        ' 
        ' bt10
        ' 
        bt10.BackColor = Color.SandyBrown
        bt10.Cursor = Cursors.Hand
        bt10.Font = New Font("MS Reference Sans Serif", 11F)
        bt10.Location = New Point(80, 47)
        bt10.Name = "bt10"
        bt10.Size = New Size(178, 76)
        bt10.TabIndex = 16
        bt10.Text = "10%"
        bt10.UseVisualStyleBackColor = False
        ' 
        ' btDescuento
        ' 
        btDescuento.BackColor = SystemColors.ActiveCaption
        btDescuento.Cursor = Cursors.Hand
        btDescuento.Font = New Font("MS Reference Sans Serif", 11F)
        btDescuento.Location = New Point(28, 561)
        btDescuento.Name = "btDescuento"
        btDescuento.Size = New Size(121, 61)
        btDescuento.TabIndex = 12
        btDescuento.Text = "% Descuento"
        btDescuento.UseVisualStyleBackColor = False
        ' 
        ' btFinalizar
        ' 
        btFinalizar.BackColor = Color.PaleGreen
        btFinalizar.Cursor = Cursors.Hand
        btFinalizar.Font = New Font("MS Reference Sans Serif", 11F)
        btFinalizar.Location = New Point(190, 561)
        btFinalizar.Name = "btFinalizar"
        btFinalizar.Size = New Size(185, 86)
        btFinalizar.TabIndex = 13
        btFinalizar.Text = "Finalizar"
        btFinalizar.UseVisualStyleBackColor = False
        ' 
        ' lblTitulo
        ' 
        lblTitulo.AutoSize = True
        lblTitulo.Font = New Font("MS Reference Sans Serif", 20F)
        lblTitulo.Location = New Point(95, 34)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(188, 42)
        lblTitulo.TabIndex = 14
        lblTitulo.Text = "Productos"
        ' 
        ' FlowLayoutPanel1
        ' 
        FlowLayoutPanel1.AutoScroll = True
        FlowLayoutPanel1.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(192))
        FlowLayoutPanel1.Controls.Add(lblPrecioTotal)
        FlowLayoutPanel1.FlowDirection = FlowDirection.RightToLeft
        FlowLayoutPanel1.Location = New Point(118, 501)
        FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        FlowLayoutPanel1.Size = New Size(251, 54)
        FlowLayoutPanel1.TabIndex = 12
        ' 
        ' lblPrecioTotal
        ' 
        lblPrecioTotal.Font = New Font("MS Reference Sans Serif", 11F)
        lblPrecioTotal.Location = New Point(7, 0)
        lblPrecioTotal.Name = "lblPrecioTotal"
        lblPrecioTotal.Size = New Size(241, 54)
        lblPrecioTotal.TabIndex = 0
        lblPrecioTotal.Text = "0,00 €"
        lblPrecioTotal.TextAlign = ContentAlignment.MiddleRight
        ' 
        ' NuevaComanda
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.Window
        ClientSize = New Size(1262, 673)
        Controls.Add(PanelDescuentos)
        Controls.Add(FlowLayoutPanel1)
        Controls.Add(lblTitulo)
        Controls.Add(btFinalizar)
        Controls.Add(btDescuento)
        Controls.Add(FlowLayoutComanda)
        Controls.Add(FlowLayoutArticulos)
        Controls.Add(FlowLayoutFamilias)
        Controls.Add(btVolver)
        Name = "NuevaComanda"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Nueva Comanda"
        PanelDescuentos.ResumeLayout(False)
        FlowLayoutPanel1.ResumeLayout(False)
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btVolver As Button
    Friend WithEvents FlowLayoutFamilias As FlowLayoutPanel
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents FlowLayoutArticulos As FlowLayoutPanel
    Friend WithEvents FlowLayoutComanda As FlowLayoutPanel
    Friend WithEvents btDescuento As Button
    Friend WithEvents btFinalizar As Button
    Friend WithEvents lblTitulo As Label
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents lblPrecioTotal As Label
    Friend WithEvents PanelDescuentos As Panel
    Friend WithEvents bt20 As Button
    Friend WithEvents bt10 As Button
    Friend WithEvents bt30 As Button
End Class
