﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Net
Imports System.Xml.Linq
Imports System.Runtime.InteropServices.JavaScript.JSType

Imports System.Xml
Imports System.Text

'ADMIN:  Faker y contra: faker
Public Class NuevaComanda
    Dim listaArticulosComanda As List(Of String) = New List(Of String)
    Dim listaCantidadComanda As List(Of Integer) = New List(Of Integer)
    Dim precioTotal As Double = 0
    Dim descuento As Double = 0


    Dim nombreFamiliaSeleccionada As String
    Dim nombreCamarero As String

    Public Sub New(nombre As String)
        InitializeComponent()
        nombreCamarero = nombre
    End Sub

    Private Sub btVolver_Click(sender As Object, e As EventArgs) Handles btVolver.Click
        Dim res = MessageBox.Show("¿Seguro que quieres regresar?, se eliminará la comanda", "Advertencia", MessageBoxButtons.OKCancel)
        If res = DialogResult.OK Then
            Dim formMenuCamarero As New CamareroMenu(nombreCamarero)
            formMenuCamarero.Show()
            Me.Close()
        End If
    End Sub

    Private Sub NuevaComanda_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim listaFamilias = cargarFamilias()
        setearBotonesFamilias(listaFamilias)

    End Sub

    Private Function cargarArticulos(familia As String) As List(Of Articulo)
        Dim idFamilia As Integer = getIdFamilia(familia)
        If idFamilia = 0 Then
            MessageBox.Show("No se encontró la familia con el nombre especificado", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return Nothing
        End If
        Dim query As String = "SELECT nombre_articulo, url FROM Articulos WHERE id_familia = @idFamilia"
        Dim command As New SqlClient.SqlCommand(query, connection)
        Try
            If connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            command.Parameters.AddWithValue("@idFamilia", idFamilia)
            Dim reader As SqlClient.SqlDataReader = command.ExecuteReader()
            Dim articulos As New List(Of Articulo)
            While reader.Read()
                Dim articulo As New Articulo() With {
                .Nombre = reader("nombre_articulo").ToString(),
                .UrlImagen = reader("url").ToString()
            }
                articulos.Add(articulo)
            End While
            reader.Close()
            connection.Close()
            Return articulos
        Catch ex As Exception
            MessageBox.Show("Error al obtener los articulos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return Nothing
        End Try
    End Function


    Private Function getIdFamilia(familiaNombre As String) As Integer
        Dim idFamilia As Integer = 0
        Dim query As String = "SELECT id_familia FROM Familias WHERE nombre_familia = @familiaNombre"

        Try
            Using command As New SqlClient.SqlCommand(query, connection)
                command.Parameters.AddWithValue("@familiaNombre", familiaNombre.Trim())

                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If

                Dim result = command.ExecuteScalar()

                If result IsNot Nothing Then
                    idFamilia = Convert.ToInt32(result)
                Else
                    MsgBox("No se encontró una familia con el nombre: " & familiaNombre, MsgBoxStyle.Information, "Familia no encontrada")
                End If
            End Using
        Catch ex As Exception
            MsgBox("Error al modificar el producto: " & ex.Message, MsgBoxStyle.Critical, "Error")
        Finally
            If connection.State = ConnectionState.Open Then
                connection.Close()
            End If
        End Try
        Return idFamilia
    End Function

    Private Sub setearBotonesArticulos(listaArticulos As List(Of Articulo))
        For Each articulo In listaArticulos
            CrearBotonArticulo(articulo)
        Next
    End Sub
    Private Sub CrearBotonArticulo(articulo As Articulo)
        Dim btArticulo As New Button()
        btArticulo.Text = articulo.Nombre
        btArticulo.Width = 140
        btArticulo.Height = 130
        btArticulo.Cursor = Cursors.Hand
        btArticulo.Font = New Font("MS Reference Sans Serif", 10)
        btArticulo.TextImageRelation = TextImageRelation.ImageAboveText
        btArticulo.ImageAlign = ContentAlignment.TopCenter
        btArticulo.TextAlign = ContentAlignment.BottomCenter
        Try
            Dim request As WebRequest = WebRequest.Create(articulo.UrlImagen)
            Using response As WebResponse = request.GetResponse()
                Using stream As Stream = response.GetResponseStream()
                    Dim originalImage As Image = Image.FromStream(stream)
                    btArticulo.Image = New Bitmap(originalImage, New Size(btArticulo.Width - 20, btArticulo.Height - 60))
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("el articulo " & articulo.Nombre & " no tiene imagen", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Try
        AddHandler btArticulo.Click, AddressOf btArticulo_Click
        FlowLayoutArticulos.Controls.Add(btArticulo)
    End Sub

    Private Sub btArticulo_Click(sender As Object, e As EventArgs)
        Dim botoncin As Button = CType(sender, Button)
        Dim nombre As String = botoncin.Text
        Dim precio As Double = getPrecioArticulo(nombre)

        precioTotal += precio
        actualizarPrecioTotal()

        If listaArticulosComanda.Contains(nombre) Then
            Dim index As Integer = listaArticulosComanda.IndexOf(nombre)
            listaCantidadComanda(index) += 1
            Dim nuevaCantidad As Integer = listaCantidadComanda(index)
            Dim nuevoPrecioTotalArticulo As Double = nuevaCantidad * precio

            ActualizarLabelRegistro(nuevaCantidad - 1, nuevaCantidad, nombre, precio)
        Else
            listaArticulosComanda.Add(nombre)
            listaCantidadComanda.Add(1)
            CrearLabelRegistro(1, nombre, precio)
        End If
    End Sub

    Private Sub CrearLabelRegistro(cantidad As Integer, articulo As String, precio As Double)
        Dim labelRegistro As New Label()
        Dim labelRegistroEspaciador As New Label()

        labelRegistro.Width = FlowLayoutComanda.Width - 20
        labelRegistro.Font = New Font("MS Reference Sans Serif", 11)
        labelRegistro.Text = $"{articulo} - x{cantidad} - {precio:F2}€"

        AddHandler labelRegistro.MouseEnter, Sub(sender, e) labelRegistro.ForeColor = Color.Red
        AddHandler labelRegistro.MouseLeave, Sub(sender, e) labelRegistro.ForeColor = Color.Black
        AddHandler labelRegistro.Click, Sub(sender, e) ReducirCantidadArticulo(labelRegistro, labelRegistroEspaciador, articulo, precio)

        labelRegistroEspaciador.Font = New Font("MS Reference Sans Serif", 1)

        FlowLayoutComanda.Controls.Add(labelRegistro)
        FlowLayoutComanda.Controls.Add(labelRegistroEspaciador)
    End Sub


    Private Sub ReducirCantidadArticulo(labelRegistro As Label, labelEspaciador As Label, articulo As String, precio As Double)
        Dim index As Integer = listaArticulosComanda.IndexOf(articulo)
        If index = -1 Then Return

        listaCantidadComanda(index) -= 1
        Dim nuevaCantidad As Integer = listaCantidadComanda(index)
        Dim nuevoPrecioTotalArticulo As Double = nuevaCantidad * precio

        If nuevaCantidad = 0 Then
            listaArticulosComanda.RemoveAt(index)
            listaCantidadComanda.RemoveAt(index)
            FlowLayoutComanda.Controls.Remove(labelRegistro)
            FlowLayoutComanda.Controls.Remove(labelEspaciador)
        Else
            labelRegistro.Text = $"{articulo} - x{nuevaCantidad} - {nuevoPrecioTotalArticulo:F2}€"
        End If

        precioTotal -= precio
        actualizarPrecioTotal()
    End Sub

    Private Sub ActualizarLabelRegistro(cantidadAnterior As Integer, cantidad As Integer, articulo As String, precio As Double)
        Dim precioActual As Double = cantidad * precio
        Dim buscarTexto As String = $"{articulo} - x{cantidadAnterior} - {cantidadAnterior * precio:F2}€"

        For Each label In FlowLayoutComanda.Controls
            Dim label1 As Label = TryCast(label, Label)
            If label1 IsNot Nothing AndAlso label1.Text = buscarTexto Then
                label1.Text = $"{articulo} - x{cantidad} - {precioActual:F2}€"
                Exit For
            End If
        Next
    End Sub

    Private Function cargarFamilias()
        Dim query As String = "SELECT nombre_familia FROM Familias"
        Dim command As New SqlClient.SqlCommand(query, connection)
        Try
            If connection.State = ConnectionState.Closed Then
                connection.Open()
            End If
            Dim reader As SqlClient.SqlDataReader = command.ExecuteReader()
            Dim nombres As New List(Of String)
            While reader.Read()
                nombres.Add(reader("nombre_familia").ToString())
            End While
            reader.Close()
            connection.Close()
            Return nombres
        Catch ex As Exception
            MessageBox.Show("Error al obtener las familias", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return Nothing
        End Try
    End Function

    Private Sub CrearBotonFamilia(familia As String)
        Dim btFamilia As New Button()
        btFamilia.Text = familia
        btFamilia.Width = 170
        btFamilia.Height = 100
        btFamilia.Cursor = Cursors.Hand
        btFamilia.Font = New Font("MS Reference Sans Serif", 16)
        AddHandler btFamilia.Click, AddressOf btFamilia_Click
        FlowLayoutFamilias.Controls.Add(btFamilia)
    End Sub

    Private Sub btFamilia_Click(sender As Object, e As EventArgs)
        If FlowLayoutArticulos.Controls.Count > 0 Then
            FlowLayoutArticulos.Controls.Clear()
        End If
        Dim botonPulsado As Button = CType(sender, Button)
        For Each control As Control In FlowLayoutFamilias.Controls
            Dim boton As Button = CType(control, Button)
            If boton Is botonPulsado Then
                boton.BackColor = Color.LightGreen
                nombreFamiliaSeleccionada = boton.Text
                Dim listaArticulos = cargarArticulos(nombreFamiliaSeleccionada)
                setearBotonesArticulos(listaArticulos)
            Else
                boton.BackColor = Color.LightBlue
            End If
        Next
    End Sub

    Private Sub setearBotonesFamilias(listaFamilias As List(Of String))
        For Each familia As String In listaFamilias
            CrearBotonFamilia(familia)
        Next
        If FlowLayoutFamilias.Controls.Count > 0 Then
            Dim primerBoton As Button = CType(FlowLayoutFamilias.Controls(0), Button)
            primerBoton.PerformClick()
        End If
    End Sub

    'me actualiza el lbl del precio total
    Private Sub actualizarPrecioTotal()
        'math.abs devuelve un valor positivo
        If Math.Abs(precioTotal) < 0.01 Then
            precioTotal = 0
        End If

        Dim precioConDescuento As Double = precioTotal * (1 - descuento)

        If descuento > 0 Then
            lblPrecioTotal.Text = $"({descuento * 100}%)  -  {precioConDescuento:F2} €"
        Else
            lblPrecioTotal.Text = $"{precioTotal:F2} €"
        End If
    End Sub

    Private Sub Descuento_Click(sender As Object, e As EventArgs) Handles btDescuento.Click
        If PanelDescuentos.Visible Then
            PanelDescuentos.Visible = False
        Else
            PanelDescuentos.Visible = True
        End If
    End Sub

    Private Sub bt10_Click(sender As Object, e As EventArgs) Handles bt10.Click
        descuento = 0.1
        actualizarPrecioTotal()
        PanelDescuentos.Visible = False
    End Sub

    Private Sub bt20_Click(sender As Object, e As EventArgs) Handles bt20.Click
        descuento = 0.2
        actualizarPrecioTotal()
        PanelDescuentos.Visible = False
    End Sub

    Private Sub bt30_Click(sender As Object, e As EventArgs) Handles bt30.Click
        descuento = 0.3
        actualizarPrecioTotal()
        PanelDescuentos.Visible = False
    End Sub

    Private Sub btFinalizar_Click(sender As Object, e As EventArgs) Handles btFinalizar.Click
        Dim idComanda As Integer = ObtenerIdComanda()
        If idComanda = -1 Then
            MessageBox.Show("Error al obtener el id de la comanda", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If
        Dim costoTotalConDescuento As Double = precioTotal * (1 - descuento)
        Dim fechaActual As Date = Date.Now
        Dim queryComanda As String = "INSERT INTO Comandas (id_comanda, costo_total, fecha, numero_mesa, usuario) VALUES (@idComanda, @costoTotal, @fecha, @numeroMesa, @usuario)"

        Try
            Using commandComanda As New SqlCommand(queryComanda, connection)
                commandComanda.Parameters.AddWithValue("@idComanda", idComanda)
                commandComanda.Parameters.AddWithValue("@costoTotal", costoTotalConDescuento)
                commandComanda.Parameters.AddWithValue("@fecha", fechaActual)
                commandComanda.Parameters.AddWithValue("@numeroMesa", 0)  '0 'la barra' somo siempre estamos en barra siemore tiene valor 0
                commandComanda.Parameters.AddWithValue("@usuario", nombreCamarero)

                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If

                commandComanda.ExecuteNonQuery()
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al insertar la comanda: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try

        For i As Integer = 0 To listaArticulosComanda.Count - 1
            Dim nombreArticulo As String = listaArticulosComanda(i)
            Dim cantidadArticulo As Integer = listaCantidadComanda(i)
            Dim precioArticulo As Double = getPrecioArticulo(nombreArticulo)
            Dim cantidadDinero As Double = cantidadArticulo * precioArticulo

            Dim idArticulo As Integer = ObtenerIdArticulo(nombreArticulo)

            If idArticulo = -1 Then
                MessageBox.Show("Error al obtener el id del artículo: " & nombreArticulo, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If

            Dim queryInfocomandas As String = "INSERT INTO Infocomandas (id_comanda, id_articulo, cantidad_articulo, cantidad_dinero) " & "VALUES (@idComanda, @idArticulo, @cantidadArticulo, @cantidadDinero)"

            Try
                Using commandInfocomandas As New SqlCommand(queryInfocomandas, connection)
                    commandInfocomandas.Parameters.AddWithValue("@idComanda", idComanda)
                    commandInfocomandas.Parameters.AddWithValue("@idArticulo", idArticulo)
                    commandInfocomandas.Parameters.AddWithValue("@cantidadArticulo", cantidadArticulo)
                    commandInfocomandas.Parameters.AddWithValue("@cantidadDinero", cantidadDinero)

                    commandInfocomandas.ExecuteNonQuery()
                End Using
            Catch ex As Exception
                MessageBox.Show("Error al insertar en Infocomandas: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End Try
        Next

        generarTicket(idComanda, nombreCamarero, listaArticulosComanda,
                      listaCantidadComanda, costoTotalConDescuento, descuento, fechaActual)

        'MessageBox.Show("Comanda finalizada correctamente", "Comanda Finalizada", MessageBoxButtons.OK, MessageBoxIcon.Information)
        LimpiarComanda()
    End Sub

    Private Sub generarTicket(idComanda As Integer, nombreCamarero As String, listaArticulosComanda As List(Of String), listaCantidadComanda As List(Of Integer), precioTotal As Double, descuento As Double, fechaActual As Date)
        Try
            ' Crear la lista de artículos
            Dim articulos As New List(Of XElement)
            For i As Integer = 0 To listaArticulosComanda.Count - 1
                articulos.Add(New XElement("articulo",
                New XElement("nombre", listaArticulosComanda(i)),
                New XElement("cantidad", listaCantidadComanda(i).ToString()),
                New XElement("precio", getPrecioArticulo2(listaArticulosComanda(i)).ToString("F2"))
            ))
            Next

            'creamos el xml junto a todos los articulos
            Dim ticketXML As New XDocument(
            New XElement("ticket",
                New XElement("camarero", nombreCamarero),
                New XElement("fecha", fechaActual.ToString("yyyy-MM-dd HH:mm:ss")),
                New XElement("numeroFactura", idComanda.ToString()),
                New XElement("emisor",
                    New XElement("nombre", "EXIDES Enterprise"),
                    New XElement("NIF", "12843590E"),
                    New XElement("domicilio", "Centro Formación Somorrostro")
                ),
                New XElement("articulos", articulos),
                New XElement("precioTotal", precioTotal.ToString("F2")),
                New XElement("descuento", If(descuento > 0, (descuento * 100).ToString() + "%", "0%")),
                New XElement("impuestos",
                    New XElement("tipoImpositivo", "21%"),
                    New XElement("cuotaTributaria", (precioTotal * 0.21).ToString("F2"))
                )
            )
        )

            'guaradamso el xml en el explocrador de archivos para que el usuario pueda verlo al finalizar la comanda
            Dim rutaArchivo As String = "Ticket.xml"
            ticketXML.Save(rutaArchivo)


            ' Guardar el XML en un StringWriter con codificación UTF-8
            Dim sb As New StringBuilder()
            Using sw As New StringWriter(sb)
                Using xmlWriter As XmlWriter = XmlWriter.Create(sw, New XmlWriterSettings With {.Encoding = Encoding.UTF8})
                    ticketXML.Save(xmlWriter)
                End Using
            End Using

            'convertimos el xml a string para guardarlo
            Dim xmlString As String = sb.ToString()

            guardarEnBaseDeDatos(nombreCamarero, xmlString)

            Dim result As DialogResult = MessageBox.Show("¿Deseas ver su ticket?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If result = DialogResult.Yes Then
                MostrarXml()
            End If

        Catch ex As Exception
            MessageBox.Show("Error al generar el ticket: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub guardarEnBaseDeDatos(nombreCamarero As String, xmlString As String)
        Dim queryXML As String = "insert into Tickets (nombreCamarero, ticket, fechaTicket) values (@nombre, @ticket, @fecha)"
        Try
            Using commandXML As New SqlCommand(queryXML, connection)
                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If
                commandXML.Parameters.AddWithValue("@nombre", nombreCamarero)
                commandXML.Parameters.AddWithValue("@ticket", xmlString)
                commandXML.Parameters.AddWithValue("@fecha", DateTime.Now)

                commandXML.ExecuteNonQuery()
            End Using
        Catch ex As Exception
            MsgBox("ERROR: " & ex.Message)
        End Try
    End Sub

    ' Funcion para mostrar XML
    Sub MostrarXML()
        Dim ruta As String = "Ticket.xml"
        If File.Exists(ruta) Then
            Process.Start(New ProcessStartInfo With {
                .FileName = ruta,
                .UseShellExecute = True
            })
        End If
    End Sub

    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    'DOCU PONER FUNCION ELIMIANAR TICKET


    ' Función para obtener el precio de un artículo (esto debe conectarse a tu base de datos)
    Private Function getPrecioArticulo(nombreArticulo As String) As Double
        ' Aquí deberías hacer una consulta a la base de datos o tener algún medio para obtener el precio
        Return 10.0 ' Solo un ejemplo, deberías implementar la lógica adecuada
    End Function

    Public Function getPrecioArticulo2(nombreArticulo As String) As Double
        Dim precio As Double = 0
        Dim query As String = "Select precio_venta from Articulos where nombre_articulo ='" + nombreArticulo + "'"

        Try
            Using command As New SqlCommand(query, connection)
                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If

                precio = Convert.ToDouble(command.ExecuteScalar())
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al obtener el precio del artículo: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        Return precio
    End Function

    Private Function ObtenerIdComanda() As Integer
        Dim query As String = "SELECT MAX(id_comanda) FROM Comandas"
        Try
            Using command As New SqlCommand(query, connection)
                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If

                Dim result As Object = command.ExecuteScalar()
                If result IsNot DBNull.Value Then
                    Return Convert.ToInt32(result) + 1
                Else
                    Return 1
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al obtener el id de la comanda: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return -1
        End Try
    End Function

    Private Sub obtenerArticulos()
        Dim query As String = "select nombre_articulo from Articulos"
        Try
            Using command As New SqlCommand(query, connection)
                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If

                Dim result As Object = command.ExecuteScalar()
                If result IsNot DBNull.Value Then

                Else
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al obtener el id de la comanda: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try
    End Sub

    Private Function ObtenerIdArticulo(nombreArticulo As String) As Integer
        Dim query As String = "SELECT id_articulo FROM Articulos WHERE nombre_articulo = @nombre"
        Try
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@nombre", nombreArticulo)

                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If

                Dim result As Object = command.ExecuteScalar()
                If result IsNot DBNull.Value Then
                    Return Convert.ToInt32(result)
                Else
                    Return -1
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al obtener el id del artículo: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return -1
        End Try
    End Function

    Private Sub LimpiarComanda()
        listaArticulosComanda.Clear()
        listaCantidadComanda.Clear()
        precioTotal = 0
        descuento = 0
        actualizarPrecioTotal()
        FlowLayoutComanda.Controls.Clear()
    End Sub
End Class

Public Class Articulo
    Public Property Nombre As String
    Public Property UrlImagen As String
End Class
