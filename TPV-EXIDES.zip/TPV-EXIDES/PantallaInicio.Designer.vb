﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class PantallaInicio
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PantallaInicio))
        lbCamarero = New Label()
        lbAdministrador = New Label()
        btSalir = New Button()
        pbCamarero = New PictureBox()
        pbAdministrador = New PictureBox()
        CType(pbCamarero, ComponentModel.ISupportInitialize).BeginInit()
        CType(pbAdministrador, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lbCamarero
        ' 
        lbCamarero.AutoSize = True
        lbCamarero.Font = New Font("MS Reference Sans Serif", 25.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lbCamarero.Location = New Point(261, 131)
        lbCamarero.Name = "lbCamarero"
        lbCamarero.Size = New Size(228, 52)
        lbCamarero.TabIndex = 1
        lbCamarero.Text = "Camarero"
        ' 
        ' lbAdministrador
        ' 
        lbAdministrador.AutoSize = True
        lbAdministrador.Font = New Font("MS Reference Sans Serif", 25F)
        lbAdministrador.Location = New Point(683, 131)
        lbAdministrador.Name = "lbAdministrador"
        lbAdministrador.Size = New Size(320, 52)
        lbAdministrador.TabIndex = 6
        lbAdministrador.Text = "Administrador"
        ' 
        ' btSalir
        ' 
        btSalir.BackColor = Color.Firebrick
        btSalir.Cursor = Cursors.Hand
        btSalir.Font = New Font("MS Reference Sans Serif", 20F)
        btSalir.ForeColor = SystemColors.ButtonHighlight
        btSalir.Location = New Point(7, 12)
        btSalir.Name = "btSalir"
        btSalir.Size = New Size(185, 91)
        btSalir.TabIndex = 13
        btSalir.Text = "Salir"
        btSalir.UseVisualStyleBackColor = False
        ' 
        ' pbCamarero
        ' 
        pbCamarero.Cursor = Cursors.Hand
        pbCamarero.Image = CType(resources.GetObject("pbCamarero.Image"), Image)
        pbCamarero.Location = New Point(226, 186)
        pbCamarero.Name = "pbCamarero"
        pbCamarero.Size = New Size(320, 326)
        pbCamarero.TabIndex = 14
        pbCamarero.TabStop = False
        ' 
        ' pbAdministrador
        ' 
        pbAdministrador.Cursor = Cursors.Hand
        pbAdministrador.Image = CType(resources.GetObject("pbAdministrador.Image"), Image)
        pbAdministrador.Location = New Point(683, 186)
        pbAdministrador.Name = "pbAdministrador"
        pbAdministrador.Size = New Size(320, 326)
        pbAdministrador.TabIndex = 15
        pbAdministrador.TabStop = False
        ' 
        ' PantallaInicio
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1262, 673)
        Controls.Add(pbAdministrador)
        Controls.Add(pbCamarero)
        Controls.Add(btSalir)
        Controls.Add(lbAdministrador)
        Controls.Add(lbCamarero)
        Name = "PantallaInicio"
        RightToLeft = RightToLeft.Yes
        StartPosition = FormStartPosition.CenterScreen
        Text = "Menú Principal"
        CType(pbCamarero, ComponentModel.ISupportInitialize).EndInit()
        CType(pbAdministrador, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents lbCamarero As Label
    Friend WithEvents lbAdministrador As Label
    Friend WithEvents btSalir As Button
    Friend WithEvents pbCamarero As PictureBox
    Friend WithEvents pbAdministrador As PictureBox

End Class
