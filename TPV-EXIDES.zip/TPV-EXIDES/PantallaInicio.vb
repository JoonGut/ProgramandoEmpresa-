﻿Imports System.Data.SqlClient
Imports System.Globalization
Imports System.IO

Public Class PantallaInicio
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles pbCamarero.Click
        Dim formInicioCamarero As New InicioCamarero()
        formInicioCamarero.Show()
        Me.Hide()
    End Sub
    Private Sub lbCamarero_Click(sender As Object, e As EventArgs) Handles lbCamarero.Click
        Dim formInicioCamarero As New InicioCamarero()
        formInicioCamarero.Show()
        Me.Hide()
    End Sub

    Private Sub btSalir_Click(sender As Object, e As EventArgs) Handles btSalir.Click
        Me.Close()
    End Sub

    Private Sub pbAdministrador_Click(sender As Object, e As EventArgs) Handles pbAdministrador.Click
        Dim formInicioAdmin As New InicioAdministrador()
        formInicioAdmin.Show()
        Me.Hide()
    End Sub
    Private Sub lbAdministrador_Click(sender As Object, e As EventArgs) Handles lbAdministrador.Click
        Dim formInicioAdmin As New InicioAdministrador()
        formInicioAdmin.Show()
        Me.Hide()
    End Sub

    Public Sub ActualizarDatosDesdeArchivo(rutaArchivo As String, conexionString As String)
        ' Abrir el archivo
        Dim lineas() As String = File.ReadAllLines(rutaArchivo)

        ' Variables para almacenar los datos
        Dim articulo As String = ""
        Dim cantidad As Integer = 0
        Dim precioUnitario As Decimal = 0
        Dim observaciones As String = ""

        ' Iterar por las líneas del archivo
        For Each linea As String In lineas
            ' Limpiar espacios extraños
            linea = linea.Trim()

            ' Verificar si la línea tiene el formato adecuado
            If linea.StartsWith("artículo:") Then
                ' Guardar el artículo
                articulo = linea.Replace("artículo:", "").Trim()

            ElseIf linea.StartsWith("cantidad:") Then
                ' Guardar la cantidad
                cantidad = Convert.ToInt32(linea.Replace("cantidad:", "").Trim())

            ElseIf linea.StartsWith("precio_unitario:") Then
                ' Guardar el precio unitario
                precioUnitario = Convert.ToDecimal(linea.Replace("precio_unitario:", "").Trim())

            ElseIf linea.StartsWith("observaciones:") Then
                ' Guardar las observaciones (si existen)
                observaciones = linea.Replace("observaciones:", "").Trim()

                ' Ahora que tenemos todos los datos, actualizamos la base de datos
                ActualizarBaseDeDatos(articulo, cantidad, precioUnitario, observaciones, conexionString)
            End If
        Next
    End Sub

    ' Función para actualizar la base de datos
    Private Sub ActualizarBaseDeDatos(articulo As String, cantidad As Integer, precioUnitario As Decimal, observaciones As String, conexionString As String)
        Using conexion As New SqlConnection(conexionString)
            Try
                conexion.Open()

                ' SQL para actualizar los datos en la tabla de artículos
                Dim query As String = "UPDATE Articulos " &
                                      "SET Cantidad = @Cantidad, PrecioUnitario = @PrecioUnitario, Observaciones = @Observaciones " &
                                      "WHERE Articulo = @Articulo"

                Using cmd As New SqlCommand(query, conexion)
                    ' Definir los parámetros del query
                    cmd.Parameters.AddWithValue("@Articulo", articulo)
                    cmd.Parameters.AddWithValue("@Cantidad", cantidad)
                    cmd.Parameters.AddWithValue("@PrecioUnitario", precioUnitario)

                    ' Si las observaciones están vacías, pasar DBNull
                    If String.IsNullOrEmpty(observaciones) Then
                        cmd.Parameters.AddWithValue("@Observaciones", DBNull.Value)
                    Else
                        cmd.Parameters.AddWithValue("@Observaciones", observaciones)
                    End If

                    ' Ejecutar la actualización
                    cmd.ExecuteNonQuery()
                End Using
            Catch ex As Exception
                Console.WriteLine("Error al actualizar la base de datos: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub PantallaInicio_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        eliminarTicketsAntiguos()
        actualizarStock()
    End Sub

    Public Sub eliminarTicketsAntiguos()
        Dim queryDelete As String = "delete from Tickets where fechaTicket < @fechaBorrado"

        Try
            Using commandDelete As New SqlCommand(queryDelete, connection)
                If connection.State = ConnectionState.Closed Then
                    connection.Open()
                End If

                Dim fechaLimite As DateTime = DateTime.Now.AddDays(-14)
                commandDelete.Parameters.AddWithValue("@fechaBorrado", fechaLimite)

                Dim filasAfectadas As Integer = commandDelete.ExecuteNonQuery()
                'MsgBox(filasAfectadas.ToString())
            End Using
        Catch ex As Exception
            MsgBox("ERROR: " & ex.Message)
        End Try
    End Sub

    Private Sub actualizarStock()
        Dim rutaArchivo As String = "Modificacion_de_Productos.txt"
        Dim productos As New List(Of Tuple(Of String, Integer, Decimal))()

        Try
            Dim lines As String() = File.ReadAllLines(rutaArchivo)

            For i As Integer = 0 To lines.Length - 1
                If lines(i).StartsWith("artículo:") Then
                    Dim nombreArticulo As String = lines(i).Split(":")(1).Trim()
                    Dim cantidadProducto As String = lines(i + 1).Trim()
                    Dim precioProducto As String = lines(i + 2).Trim()
                    Dim cantidad As Integer = CInt(cantidadProducto.Split(":")(1))
                    Dim precio_unitario As Decimal = Decimal.Parse(precioProducto.Split(":")(1), CultureInfo.InvariantCulture) ''CultureInfo.InvariantCulture' quitamos el error que si pone 1,50 no de error y lea 1.50 con el punto y no con la coma

                    productos.Add(Tuple.Create(nombreArticulo, cantidad, precio_unitario))
                    i += 2 'saltamos las líneas de cantidad y precio ya que las hemos cogido en el if con i+1/2
                End If
            Next
        Catch ex As Exception
            MsgBox("Error al leer el archivo: " & ex.Message)
            Exit Sub
        End Try

        Const DATABASE_NAME = "Exides_Base_Datos"
        Const DATABASE_SERVER = "PORTATIL_ASIER"
        Const CONNECTION_STRING = "Data Source=" & DATABASE_SERVER & ";Initial Catalog=" &
            DATABASE_NAME & ";Integrated Security=True;MultipleActiveResultSets=True"

        Using connection As New SqlConnection(CONNECTION_STRING)
            Try
                connection.Open()
                For Each item In productos
                    Dim nombreArticulo As String = item.Item1
                    Dim cantidad As Integer = item.Item2
                    Dim precio_unitario As Decimal = item.Item3

                    'si no hay productos productos nuevos saltamos al siguiente
                    If cantidad = 0 Then
                        Continue For
                    End If

                    'actualizamos el precio de ser necesario
                    Dim querySelect As String = "select precio_venta from Articulos where nombre_articulo = @nombreArticulo"
                    Using commandSelect As New SqlCommand(querySelect, connection)
                        commandSelect.Parameters.AddWithValue("@nombreArticulo", nombreArticulo)

                        Using reader As SqlDataReader = commandSelect.ExecuteReader()
                            If reader.Read() Then
                                Dim precioProveedor As Decimal = Convert.ToDecimal(reader("precio_venta"))
                                Dim precioMinimoVenta As Decimal = precio_unitario + 0.25D

                                'si el precio de la Base De Datos es menor que el precio minimo de venta actualizamos
                                If precioProveedor < precioMinimoVenta Then
                                    Dim queryUpdatePrecio As String = "update Articulos set precio_venta = @nuevoPrecio 
                                                                where nombre_articulo = @nombreArticulo"
                                    Using commandUpdatePrecio As New SqlCommand(queryUpdatePrecio, connection)
                                        commandUpdatePrecio.Parameters.AddWithValue("@nuevoPrecio", Math.Round(precioMinimoVenta, 2)) 'nos aseguramso de que tenga solo dos deciamles asi no salen los datos distintos
                                        commandUpdatePrecio.Parameters.AddWithValue("@nombreArticulo", nombreArticulo)
                                        commandUpdatePrecio.ExecuteNonQuery()
                                    End Using
                                End If
                            End If
                        End Using
                    End Using

                    'actualziamos el propio stock
                    Dim queryStock As String = "UPDATE Articulos SET cantidad_stock = cantidad_stock + 
                        @cantidad WHERE nombre_articulo = @nombreArticulo"
                    Using commandUpdateStock As New SqlCommand(queryStock, connection)
                        commandUpdateStock.Parameters.AddWithValue("@cantidad", cantidad)
                        commandUpdateStock.Parameters.AddWithValue("@nombreArticulo", nombreArticulo)
                        commandUpdateStock.ExecuteNonQuery()
                    End Using
                Next
                'MsgBox("Los datos se actualizaron CON ÉXITO")
            Catch ex As Exception
                MsgBox("ERROR al actualizar precios o stock: " & ex.Message)
            End Try
        End Using
    End Sub
End Class